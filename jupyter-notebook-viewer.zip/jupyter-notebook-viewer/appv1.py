import os
import json
import nbformat
import requests
from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename

app = Flask(__name__, static_folder='static', template_folder='templates')
CORS(app)
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload
app.config['JUPYTER_SERVER_URL'] = 'http://localhost:8888'
app.config['JUPYTER_API_TOKEN'] = 'cf787daf5a798c28ec739fd1357638db0cbb5e0a467136e0'  # Set your Jupyter token here

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Utility functions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() == 'ipynb'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/static/<path:path>')
def serve_static(path):
    return send_from_directory('static', path)

@app.route('/api/upload', methods=['POST'])
def upload_notebook():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        try:
            # Parse the notebook
            with open(filepath, 'r', encoding='utf-8') as f:
                notebook_content = json.load(f)
                
            # Return notebook data and a reference ID
            return jsonify({
                'success': True,
                'filename': filename,
                'notebook': notebook_content
            })
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    return jsonify({'error': 'File type not allowed'}), 400

@app.route('/api/notebooks/<filename>', methods=['GET'])
def get_notebook(filename):
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(filename))
    
    if not os.path.exists(filepath):
        return jsonify({'error': 'Notebook not found'}), 404
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            notebook_content = json.load(f)
        
        return jsonify({
            'success': True,
            'notebook': notebook_content
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/execute_cell', methods=['POST'])
def execute_cell():
    data = request.json
    if not data or 'code' not in data:
        return jsonify({'error': 'No code provided'}), 400
    
    code = data['code']
    
    # Connect to Jupyter server to execute the code
    headers = {
        'Content-Type': 'application/json',
    }
    
    if app.config['JUPYTER_API_TOKEN']:
        headers['Authorization'] = f"Token {app.config['JUPYTER_API_TOKEN']}"
    
    # Create a new session if session_id is not provided
    session_id = data.get('session_id')
    kernel_id = data.get('kernel_id')
    
    if not session_id or not kernel_id:
        # Start a new kernel session
        response = requests.post(
            f"{app.config['JUPYTER_SERVER_URL']}/api/kernels",
            headers=headers
        )
        
        if response.status_code != 201:
            return jsonify({'error': 'Failed to start kernel'}), 500
        
        kernel_data = response.json()
        kernel_id = kernel_data['id']
    
    # Execute the code
    execution_url = f"{app.config['JUPYTER_SERVER_URL']}/api/kernels/{kernel_id}/execute"
    execution_payload = {
        'code': code,
        'silent': False,
        'store_history': True,
        'user_expressions': {},
        'allow_stdin': False
    }
    
    try:
        response = requests.post(
            execution_url,
            headers=headers,
            json=execution_payload
        )
        
        if response.status_code != 200:
            return jsonify({'error': 'Code execution failed'}), 500
        
        # Get the execution results
        msg_id = response.json()['msg_id']
        
        # Poll for results (simplified - in production you'd use websockets)
        # For demo purposes, we'll just return a success message
        return jsonify({
            'success': True,
            'kernel_id': kernel_id,
            'msg_id': msg_id,
            'output': {
                'text/plain': 'Code executed successfully. In a production environment, you would receive the actual output here.'
            }
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
