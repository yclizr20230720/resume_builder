import os
import json
import time
import logging
import sys
import nbformat
import requests
from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename
from jupyter_bridge import JupyterClient  # Updated import

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)

app = Flask(__name__, static_folder='static', template_folder='templates')
CORS(app)
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload
app.config['JUPYTER_SERVER_URL'] = 'http://localhost:8888'
app.config['JUPYTER_API_TOKEN'] = 'cf787daf5a798c28ec739fd1357638db0cbb5e0a467136e0'  # Set your Jupyter token here (without the ?token= part)


# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Get a logger for this application
logger = logging.getLogger('jupyter-notebook-viewer')

# Create a Jupyter client instance
jupyter_client = None

# Add this function to check token validity
def verify_jupyter_token():
    """Verify that the configured Jupyter token is valid"""
    token = app.config['JUPYTER_API_TOKEN']
    
    if not token:
        logger.warning("No Jupyter token configured. Cell execution will likely fail.")
        logger.warning("Please update app.config['JUPYTER_API_TOKEN'] with your Jupyter token.")
        logger.warning("Run python find_token.py to automatically find your token.")
        return False
    
    # Test the token by making a request to the kernelspecs endpoint
    headers = {'Content-Type': 'application/json'}
    if token:
        headers['Authorization'] = f'Token {token}'
    
    try:
        response = requests.get(
            f"{app.config['JUPYTER_SERVER_URL']}/api/kernelspecs", 
            headers=headers
        )
        
        if 'text/html' in response.headers.get('Content-Type', ''):
            logger.error("Authentication failed. Received HTML instead of JSON.")
            logger.error("Your Jupyter token is likely incorrect.")
            logger.error("Run python find_token.py to find the correct token.")
            return False
        
        if response.status_code == 200:
            kernelspecs = response.json()
            logger.info(f"Jupyter token verified. Available kernels: {list(kernelspecs['kernelspecs'].keys())}")
            return True
        else:
            logger.error(f"Token verification failed. Status code: {response.status_code}")
            return False
    except Exception as e:
        logger.error(f"Error verifying token: {str(e)}")
        return False

def fix_notebook_structure(notebook_data):
    """
    Ensure notebook data is properly structured for the frontend.
    This fixes issues with displaying source code line by line.
    """
    # If we have a NotebookNode object, convert to dict
    if hasattr(notebook_data, 'cells'):
        notebook_dict = notebook_data.dict()
    else:
        notebook_dict = notebook_data
    
    # Ensure cells exist
    if 'cells' not in notebook_dict:
        notebook_dict['cells'] = []
    
    # Process each cell to ensure source is properly formatted
    for cell in notebook_dict['cells']:
        # Ensure source is a list of strings for line-by-line display
        if 'source' in cell and isinstance(cell['source'], str):
            cell['source'] = cell['source'].splitlines()
        
        # Handle code cell outputs
        if cell.get('cell_type') == 'code' and 'outputs' in cell:
            # Ensure outputs are properly formatted
            for output in cell['outputs']:
                # Handle text output
                if 'text' in output and isinstance(output['text'], str):
                    output['text'] = output['text'].splitlines()
    
    return notebook_dict

# Utility functions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() == 'ipynb'

@app.route('/')
def index():
    logger.info("Rendering index page")
    return render_template('index.html')

@app.route('/static/<path:path>')
def serve_static(path):
    return send_from_directory('static', path)

@app.route('/api/upload', methods=['POST'])
def upload_notebook():
    logger.info("Handling notebook upload request")
    if 'file' not in request.files:
        logger.warning("No file part in the request")
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        logger.warning("No selected file")
        return jsonify({'error': 'No selected file'}), 400
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        logger.info(f"Saved uploaded file: {filename}")
        
        try:
            # Try to parse using nbformat first
            try:
                notebook = nbformat.read(filepath, as_version=4)
                notebook_data = notebook
            except:
                # Fall back to JSON parsing
                with open(filepath, 'r', encoding='utf-8') as f:
                    notebook_data = json.load(f)
            
            # Fix the notebook structure for proper display
            fixed_notebook = fix_notebook_structure(notebook_data)
            
            # Return notebook data and a reference ID
            logger.info(f"Successfully parsed notebook: {filename}")
            return jsonify({
                'success': True,
                'filename': filename,
                'notebook': fixed_notebook
            })
        except Exception as e:
            logger.error(f"Error parsing notebook: {str(e)}")
            return jsonify({'error': str(e)}), 500
    
    logger.warning(f"File type not allowed: {file.filename}")
    return jsonify({'error': 'File type not allowed'}), 400

@app.route('/api/notebooks/<filename>', methods=['GET'])
def get_notebook(filename):
    logger.info(f"Getting notebook: {filename}")
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(filename))
    
    if not os.path.exists(filepath):
        logger.warning(f"Notebook not found: {filename}")
        return jsonify({'error': 'Notebook not found'}), 404
    
    try:
        # Try to parse using nbformat first
        try:
            notebook = nbformat.read(filepath, as_version=4)
            notebook_data = notebook
        except:
            # Fall back to JSON parsing
            with open(filepath, 'r', encoding='utf-8') as f:
                notebook_data = json.load(f)
        
        # Fix the notebook structure for proper display
        fixed_notebook = fix_notebook_structure(notebook_data)
        
        logger.info(f"Successfully retrieved notebook: {filename}")
        return jsonify({
            'success': True,
            'notebook': fixed_notebook
        })
    except Exception as e:
        logger.error(f"Error retrieving notebook: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/execute_cell', methods=['POST'])
def execute_cell():
    global jupyter_client
    
    data = request.json
    if not data or 'code' not in data:
        logger.warning("No code provided in execution request")
        return jsonify({'error': 'No code provided'}), 400
    
    code = data['code']
    logger.info(f"Executing cell with code: {code[:50]}...")
    
    # Check if token is in URL format or direct token
    jupyter_url = app.config['JUPYTER_SERVER_URL']
    jupyter_token = app.config['JUPYTER_API_TOKEN']
    
    # If the token contains '?token=', extract just the token part
    if '?token=' in jupyter_token:
        jupyter_token = jupyter_token.split('?token=')[1]
    
    # Initialize Jupyter client if needed
    if jupyter_client is None:
        jupyter_client = JupyterClient(jupyter_url, jupyter_token)
    
    # Get kernel ID from request or create a new one
    kernel_id = data.get('kernel_id')
    
    try:
        if not kernel_id:
            # Create a new kernel
            logger.info("Creating a new kernel")
            try:
                kernel_id = jupyter_client.create_kernel()
                logger.info(f"Created new kernel with ID: {kernel_id}")
            except Exception as e:
                if "HTML" in str(e):
                    error_msg = "Authentication failed. Please check your Jupyter token."
                    logger.error(f"{error_msg}: {str(e)}")
                    return jsonify({
                        'success': False,
                        'error': error_msg,
                        'details': "Your Jupyter token is incorrect or missing. Check the token in app.py and restart."
                    }), 401
                else:
                    logger.error(f"Failed to create kernel: {str(e)}")
                    return jsonify({
                        'success': False,
                        'error': f"Failed to create kernel: {str(e)}",
                        'details': "Make sure Jupyter server is running and accessible."
                    }), 500
            
            # Connect to websocket for this kernel
            ws_connected = jupyter_client.connect_websocket(kernel_id)
            if not ws_connected:
                logger.warning(f"Failed to establish WebSocket connection to kernel {kernel_id}")
        
        # Execute the code
        logger.info(f"Executing code with kernel ID: {kernel_id}")
        
        try:
            # Execute the code and get the results
            execution_results = jupyter_client.execute_code(kernel_id, code)
            
            if execution_results['error']:
                # Return error information
                logger.warning(f"Execution error: {execution_results['error']['ename']}: {execution_results['error']['evalue']}")
                return jsonify({
                    'success': False,
                    'kernel_id': kernel_id,
                    'error': execution_results['error']
                })
            
            # Process outputs to a format suitable for the frontend
            formatted_output = {}
            
            for output in execution_results['outputs']:
                output_type = output.get('output_type')
                
                if output_type == 'stream':
                    if 'text/plain' not in formatted_output:
                        formatted_output['text/plain'] = ''
                    formatted_output['text/plain'] += output.get('text', '')
                
                elif output_type == 'execute_result' or output_type == 'display_data':
                    data = output.get('data', {})
                    for mime_type, content in data.items():
                        formatted_output[mime_type] = content
                
                elif output_type == 'error':
                    error_text = f"{output.get('ename', 'Error')}: {output.get('evalue', '')}"
                    if 'text/plain' not in formatted_output:
                        formatted_output['text/plain'] = ''
                    formatted_output['text/plain'] += error_text
                    if output.get('traceback'):
                        formatted_output['text/plain'] += '\n' + '\n'.join(output.get('traceback', []))
            
            # If we have no output, add a default message
            if not formatted_output:
                formatted_output['text/plain'] = 'Code executed successfully. No output produced.'
            
            logger.info(f"Execution successful. Output types: {list(formatted_output.keys())}")
            
            return jsonify({
                'success': True,
                'kernel_id': kernel_id,
                'output': formatted_output
            })
            
        except Exception as e:
            logger.error(f"Error executing code: {str(e)}")
            return jsonify({
                'success': False,
                'kernel_id': kernel_id,
                'error': {
                    'ename': 'ExecutionError',
                    'evalue': str(e),
                    'traceback': [str(e)]
                }
            })
            
    except Exception as e:
        error_msg = f"Failed to execute cell: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return jsonify({
            'success': False,
            'error': error_msg
        }), 500

if __name__ == '__main__':

    # Verify Jupyter token
    token_valid = verify_jupyter_token()
    if not token_valid:
        logger.warning("*** IMPORTANT: The application will start, but cell execution will fail ***")
        logger.warning("Please update your Jupyter token in app.py and restart the application")
    
    # Initialize Jupyter client
    try:
        jupyter_token = app.config['JUPYTER_API_TOKEN']
        if '?token=' in jupyter_token:
            jupyter_token = jupyter_token.split('?token=')[1]
        
        jupyter_client = JupyterClient(app.config['JUPYTER_SERVER_URL'], jupyter_token)
        logger.info("Created Jupyter client instance")
        
        # Test connection by creating a test kernel
        try:
            kernel_id = jupyter_client.create_kernel()
            logger.info(f"Successfully connected to Jupyter server. Created test kernel: {kernel_id}")
            
            # Clean up test kernel
            headers = {'Content-Type': 'application/json'}
            if jupyter_token:
                headers['Authorization'] = f"Token {jupyter_token}"
            
            # Delete the test kernel
            delete_url = f"{app.config['JUPYTER_SERVER_URL']}/api/kernels/{kernel_id}"
            requests.delete(delete_url, headers=headers)
            logger.info(f"Deleted test kernel: {kernel_id}")
            
        except Exception as e:
            logger.warning(f"Could not create test kernel: {str(e)}")
            logger.warning("The application will start but cell execution may not work correctly.")
            logger.warning("Make sure Jupyter is running and the token is correct.")
    except Exception as e:
        logger.warning(f"Error initializing Jupyter client: {str(e)}")
        logger.warning("The application will start but cell execution may not work.")
    
    try:
        logger.info(f"Starting Flask application on http://localhost:5000")
        app.run(debug=True, port=5000)
    finally:
        # Close the Jupyter client when shutting down
        if jupyter_client:
            jupyter_client.close()
            logger.info("Closed Jupyter client connection")
