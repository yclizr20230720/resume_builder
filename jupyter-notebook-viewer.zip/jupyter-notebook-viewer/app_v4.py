import os
import json
import time
import logging
import sys
import nbformat
import requests
from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename
from jupyter_bridge import JupyterClient  # Import the complete JupyterClient class

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)

app = Flask(__name__, static_folder='static', template_folder='templates')
CORS(app)
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload
app.config['JUPYTER_SERVER_URL'] = 'http://localhost:8888'
# *** IMPORTANT: Set your Jupyter token here ***
# You can find this token in the Jupyter server output when it starts
# It looks like: http://localhost:8888/?token=abcdef1234567890abcdef1234567890
# Extract the part after "token=" and paste it here
app.config['JUPYTER_API_TOKEN'] = 'cf787daf5a798c28ec739fd1357638db0cbb5e0a467136e0'  # <-- PUT YOUR TOKEN HERE

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Get a logger for this application
logger = logging.getLogger('jupyter-notebook-viewer')

# Create a Jupyter client instance
jupyter_client = None

def fix_notebook_structure(notebook_data):
    """
    Ensure notebook data is properly structured for the frontend.
    This fixes issues with displaying source code line by line.
    """
    # If we have a NotebookNode object, convert to dict
    if hasattr(notebook_data, 'cells'):
        notebook_dict = notebook_data.dict()
    else:
        notebook_dict = notebook_data
    
    # Ensure cells exist
    if 'cells' not in notebook_dict:
        notebook_dict['cells'] = []
    
    # Process each cell to ensure source is properly formatted
    for cell in notebook_dict['cells']:
        # Ensure source is a list of strings for line-by-line display
        if 'source' in cell and isinstance(cell['source'], str):
            cell['source'] = cell['source'].splitlines()
        
        # Handle code cell outputs
        if cell.get('cell_type') == 'code' and 'outputs' in cell:
            # Ensure outputs are properly formatted
            for output in cell['outputs']:
                # Handle text output
                if 'text' in output and isinstance(output['text'], str):
                    output['text'] = output['text'].splitlines()
    
    return notebook_dict

# Utility functions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() == 'ipynb'

@app.route('/')
def index():
    logger.info("Rendering index page")
    return render_template('index.html')

@app.route('/static/<path:path>')
def serve_static(path):
    return send_from_directory('static', path)

@app.route('/api/upload', methods=['POST'])
def upload_notebook():
    logger.info("Handling notebook upload request")
    if 'file' not in request.files:
        logger.warning("No file part in the request")
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        logger.warning("No selected file")
        return jsonify({'error': 'No selected file'}), 400
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        logger.info(f"Saved uploaded file: {filename}")
        
        try:
            # Try to parse using nbformat first
            try:
                notebook = nbformat.read(filepath, as_version=4)
                notebook_data = notebook
            except:
                # Fall back to JSON parsing
                with open(filepath, 'r', encoding='utf-8') as f:
                    notebook_data = json.load(f)
            
            # Fix the notebook structure for proper display
            fixed_notebook = fix_notebook_structure(notebook_data)
            
            # Return notebook data and a reference ID
            logger.info(f"Successfully parsed notebook: {filename}")
            return jsonify({
                'success': True,
                'filename': filename,
                'notebook': fixed_notebook
            })
        except Exception as e:
            logger.error(f"Error parsing notebook: {str(e)}")
            return jsonify({'error': str(e)}), 500
    
    logger.warning(f"File type not allowed: {file.filename}")
    return jsonify({'error': 'File type not allowed'}), 400

@app.route('/api/notebooks/<filename>', methods=['GET'])
def get_notebook(filename):
    logger.info(f"Getting notebook: {filename}")
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(filename))
    
    if not os.path.exists(filepath):
        logger.warning(f"Notebook not found: {filename}")
        return jsonify({'error': 'Notebook not found'}), 404
    
    try:
        # Try to parse using nbformat first
        try:
            notebook = nbformat.read(filepath, as_version=4)
            notebook_data = notebook
        except:
            # Fall back to JSON parsing
            with open(filepath, 'r', encoding='utf-8') as f:
                notebook_data = json.load(f)
        
        # Fix the notebook structure for proper display
        fixed_notebook = fix_notebook_structure(notebook_data)
        
        logger.info(f"Successfully retrieved notebook: {filename}")
        return jsonify({
            'success': True,
            'notebook': fixed_notebook
        })
    except Exception as e:
        logger.error(f"Error retrieving notebook: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/execute_cell', methods=['POST'])
def execute_cell():
    global jupyter_client
    
    data = request.json
    if not data or 'code' not in data:
        logger.warning("No code provided in execution request")
        return jsonify({'error': 'No code provided'}), 400
    
    code = data['code']
    logger.info(f"Executing cell with code: {code[:50]}...")
    
    # Get Jupyter token
    jupyter_url = app.config['JUPYTER_SERVER_URL']
    jupyter_token = app.config['JUPYTER_API_TOKEN']
    
    # If the token contains '?token=', extract just the token part
    if '?token=' in jupyter_token:
        jupyter_token = jupyter_token.split('?token=')[1]
    
    # Initialize Jupyter client if needed
    if jupyter_client is None:
        jupyter_client = JupyterClient(jupyter_url, jupyter_token)
    
    # Get kernel ID from request or create a new one
    kernel_id = data.get('kernel_id')
    
    try:
        if not kernel_id:
            # Create a new kernel
            logger.info("Creating a new kernel")
            try:
                kernel_id = jupyter_client.create_kernel()
                logger.info(f"Created new kernel with ID: {kernel_id}")
            except Exception as e:
                if "Authentication failed" in str(e):
                    error_msg = f"Authentication failed: {str(e)}"
                    logger.error(error_msg)
                    return jsonify({
                        'success': False,
                        'error': error_msg,
                        'details': "Make sure your Jupyter token is correct in app.py"
                    }), 401
                else:
                    error_msg = f"Failed to create kernel: {str(e)}"
                    logger.error(error_msg)
                    return jsonify({
                        'success': False,
                        'error': error_msg,
                        'details': "Make sure Jupyter server is running and accessible."
                    }), 500
            
            # Try to connect to websocket for this kernel
            try:
                ws_connected = jupyter_client.connect_websocket(kernel_id)
                if not ws_connected:
                    logger.warning(f"Failed to establish WebSocket connection to kernel {kernel_id}")
            except Exception as e:
                logger.warning(f"WebSocket connection error: {str(e)}")
        
        # Execute the code
        logger.info(f"Executing code with kernel ID: {kernel_id}")
        
        try:
            # Execute the code and get the results - this is where we were having issues
            execution_results = jupyter_client.execute_code(kernel_id, code)
            
            if execution_results['error']:
                # Return error information
                logger.warning(f"Execution error: {execution_results['error']['ename']}: {execution_results['error']['evalue']}")
                return jsonify({
                    'success': False,
                    'kernel_id': kernel_id,
                    'error': execution_results['error']
                })
            
            # Process outputs to a format suitable for the frontend
            formatted_output = {}
            
            for output in execution_results['outputs']:
                output_type = output.get('output_type')
                
                if output_type == 'stream':
                    if 'text/plain' not in formatted_output:
                        formatted_output['text/plain'] = ''
                    formatted_output['text/plain'] += output.get('text', '')
                
                elif output_type == 'execute_result' or output_type == 'display_data':
                    data = output.get('data', {})
                    for mime_type, content in data.items():
                        formatted_output[mime_type] = content
                
                elif output_type == 'error':
                    error_text = f"{output.get('ename', 'Error')}: {output.get('evalue', '')}"
                    if 'text/plain' not in formatted_output:
                        formatted_output['text/plain'] = ''
                    formatted_output['text/plain'] += error_text
                    if output.get('traceback'):
                        formatted_output['text/plain'] += '\n' + '\n'.join(output.get('traceback', []))
            
            # If we have no output, add a default message
            if not formatted_output:
                formatted_output['text/plain'] = 'Code executed successfully. No output produced.'
            
            logger.info(f"Execution successful. Output types: {list(formatted_output.keys())}")
            
            return jsonify({
                'success': True,
                'kernel_id': kernel_id,
                'output': formatted_output
            })
            
        except Exception as e:
            error_msg = f"Error executing code: {str(e)}"
            logger.error(error_msg)
            
            if "Authentication failed" in str(e):
                # Handle authentication errors specifically
                return jsonify({
                    'success': False,
                    'kernel_id': kernel_id,
                    'error': {
                        'ename': 'AuthenticationError',
                        'evalue': str(e),
                        'traceback': [
                            "Please check your Jupyter token in app.py",
                            "The token can be found in the Jupyter server output",
                            "It should look like: ?token=abcdef1234567890abcdef1234567890"
                        ]
                    },
                    'details': "Make sure your Jupyter token is correct in app.py"
                }), 401
            else:
                return jsonify({
                    'success': False,
                    'kernel_id': kernel_id,
                    'error': {
                        'ename': 'ExecutionError',
                        'evalue': str(e),
                        'traceback': [str(e)]
                    }
                })
            
    except Exception as e:
        error_msg = f"Failed to execute cell: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return jsonify({
            'success': False,
            'error': error_msg
        }), 500

if __name__ == '__main__':
    # Try to verify Jupyter token before proceeding
    token = app.config['JUPYTER_API_TOKEN']
    if not token:
        logger.warning("❗ IMPORTANT: No Jupyter token configured. Cell execution will fail.")
        logger.warning("Please set your Jupyter token in app.config['JUPYTER_API_TOKEN']")
        logger.warning("You can find your token in the Jupyter server output when it starts")
    else:
        logger.info(f"Using Jupyter token: {token[:4]}...{token[-4:] if len(token) > 8 else ''}")
    
    # Initialize Jupyter client
    try:
        jupyter_token = app.config['JUPYTER_API_TOKEN']
        if '?token=' in jupyter_token:
            jupyter_token = jupyter_token.split('?token=')[1]
        
        jupyter_client = JupyterClient(app.config['JUPYTER_SERVER_URL'], jupyter_token)
        logger.info("Created Jupyter client instance")
        
        # Test connection only if token is provided
        if token:
            try:
                kernel_id = jupyter_client.create_kernel()
                logger.info(f"✅ Successfully connected to Jupyter server. Test kernel created: {kernel_id}")
                
                # Clean up test kernel
                headers = {'Content-Type': 'application/json'}
                if jupyter_token:
                    headers['Authorization'] = f"Token {jupyter_token}"
                
                # Delete the test kernel
                delete_url = f"{app.config['JUPYTER_SERVER_URL']}/api/kernels/{kernel_id}"
                requests.delete(delete_url, headers=headers)
                logger.info(f"✅ Test kernel deleted: {kernel_id}")
                
            except Exception as e:
                logger.error(f"❌ Connection test failed: {str(e)}")
                
                if "Authentication failed" in str(e):
                    logger.error("❗ AUTHENTICATION ERROR: Your Jupyter token is incorrect")
                    logger.error("Please update app.config['JUPYTER_API_TOKEN'] with the correct token")
                    logger.error("The token can be found in the Jupyter server output when it starts")
        
    except Exception as e:
        logger.error(f"❌ Error initializing Jupyter client: {str(e)}")
        logger.error("The application will start but cell execution will not work")
    
    try:
        logger.info(f"Starting Flask application on http://localhost:5000")
        app.run(debug=True, port=5000)
    finally:
        # Close the Jupyter client when shutting down
        if jupyter_client:
            jupyter_client.close()
            logger.info("Closed Jupyter client connection")
