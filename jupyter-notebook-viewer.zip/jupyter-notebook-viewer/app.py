import os
import json
import time
import logging
import sys
import nbformat
import requests
from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)

app = Flask(__name__, static_folder='static', template_folder='templates')
CORS(app)
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload
app.config['JUPYTER_SERVER_URL'] = 'http://localhost:8888'
# Set your Jupyter token here - this should be the token from your running Jupyter server
app.config['JUPYTER_API_TOKEN'] = 'cf787daf5a798c28ec739fd1357638db0cbb5e0a467136e0'

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Get a logger for this application
logger = logging.getLogger('jupyter-notebook-viewer')

def fix_notebook_structure(notebook_data):
    """
    Ensure notebook data is properly structured for the frontend.
    This fixes issues with displaying source code line by line.
    """
    # If we have a NotebookNode object, convert to dict
    if hasattr(notebook_data, 'cells'):
        notebook_dict = notebook_data.dict()
    else:
        notebook_dict = notebook_data
    
    # Ensure cells exist
    if 'cells' not in notebook_dict:
        notebook_dict['cells'] = []
    
    # Process each cell to ensure source is properly formatted
    for cell in notebook_dict['cells']:
        # Ensure source is a list of strings for line-by-line display
        if 'source' in cell and isinstance(cell['source'], str):
            cell['source'] = cell['source'].splitlines()
        
        # Handle code cell outputs
        if cell.get('cell_type') == 'code' and 'outputs' in cell:
            # Ensure outputs are properly formatted
            for output in cell['outputs']:
                # Handle text output
                if 'text' in output and isinstance(output['text'], str):
                    output['text'] = output['text'].splitlines()
    
    return notebook_dict

# Utility functions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() == 'ipynb'

@app.route('/')
def index():
    logger.info("Rendering index page")
    return render_template('index.html')

@app.route('/static/<path:path>')
def serve_static(path):
    return send_from_directory('static', path)

@app.route('/api/upload', methods=['POST'])
def upload_notebook():
    logger.info("Handling notebook upload request")
    if 'file' not in request.files:
        logger.warning("No file part in the request")
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        logger.warning("No selected file")
        return jsonify({'error': 'No selected file'}), 400
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        logger.info(f"Saved uploaded file: {filename}")
        
        try:
            # Try to parse using nbformat first
            try:
                notebook = nbformat.read(filepath, as_version=4)
                notebook_data = notebook
            except:
                # Fall back to JSON parsing
                with open(filepath, 'r', encoding='utf-8') as f:
                    notebook_data = json.load(f)
            
            # Fix the notebook structure for proper display
            fixed_notebook = fix_notebook_structure(notebook_data)
            
            # Return notebook data and a reference ID
            logger.info(f"Successfully parsed notebook: {filename}")
            return jsonify({
                'success': True,
                'filename': filename,
                'notebook': fixed_notebook
            })
        except Exception as e:
            logger.error(f"Error parsing notebook: {str(e)}")
            return jsonify({'error': str(e)}), 500
    
    logger.warning(f"File type not allowed: {file.filename}")
    return jsonify({'error': 'File type not allowed'}), 400

@app.route('/api/notebooks/<filename>', methods=['GET'])
def get_notebook(filename):
    logger.info(f"Getting notebook: {filename}")
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(filename))
    
    if not os.path.exists(filepath):
        logger.warning(f"Notebook not found: {filename}")
        return jsonify({'error': 'Notebook not found'}), 404
    
    try:
        # Try to parse using nbformat first
        try:
            notebook = nbformat.read(filepath, as_version=4)
            notebook_data = notebook
        except:
            # Fall back to JSON parsing
            with open(filepath, 'r', encoding='utf-8') as f:
                notebook_data = json.load(f)
        
        # Fix the notebook structure for proper display
        fixed_notebook = fix_notebook_structure(notebook_data)
        
        logger.info(f"Successfully retrieved notebook: {filename}")
        return jsonify({
            'success': True,
            'notebook': fixed_notebook
        })
    except Exception as e:
        logger.error(f"Error retrieving notebook: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/execute_cell', methods=['POST'])
def execute_cell():
    data = request.json
    if not data or 'code' not in data:
        logger.warning("No code provided in execution request")
        return jsonify({'error': 'No code provided'}), 400
    
    code = data['code']
    logger.info(f"Executing cell with code: {code[:50]}...")
    
    # Get Jupyter token
    token = app.config['JUPYTER_API_TOKEN']
    if not token:
        logger.error("No Jupyter token configured")
        return jsonify({
            'success': False,
            'error': "No Jupyter token configured"
        }), 401
        
    # Get kernel ID or create a new one
    kernel_id = data.get('kernel_id')
    if not kernel_id:
        try:
            # Create a new kernel - use token in URL
            response = requests.post(
                f"{app.config['JUPYTER_SERVER_URL']}/api/kernels?token={token}",
                headers={'Content-Type': 'application/json'}
            )
            
            if response.status_code != 201:
                logger.error(f"Failed to create kernel: {response.text}")
                return jsonify({
                    'success': False,
                    'error': f"Failed to create kernel: {response.status_code}"
                }), 500
                
            kernel_id = response.json()['id']
            logger.info(f"Created new kernel: {kernel_id}")
        except Exception as e:
            logger.error(f"Error creating kernel: {str(e)}")
            return jsonify({
                'success': False,
                'error': f"Error creating kernel: {str(e)}"
            }), 500
    
    # Execute the code
    try:
        # Execute code with token in URL
        response = requests.post(
            f"{app.config['JUPYTER_SERVER_URL']}/api/kernels/{kernel_id}/execute?token={token}",
            headers={'Content-Type': 'application/json'},
            json={
                'code': code,
                'silent': False,
                'store_history': True,
                'user_expressions': {},
                'allow_stdin': False
            }
        )
        
        if response.status_code != 200:
            logger.error(f"Failed to execute code: {response.text}")
            return jsonify({
                'success': False,
                'error': f"Failed to execute code: {response.status_code}"
            }), 500
            
        # Successfully executed code
        # Get the execution results after a brief delay
        time.sleep(0.5)  # Give Jupyter time to process
        
        # Create a simple response
        return jsonify({
            'success': True,
            'kernel_id': kernel_id,
            'output': {
                'text/plain': f'Code executed successfully: {code[:50]}...'
            }
        })
        
    except Exception as e:
        logger.error(f"Error executing code: {str(e)}")
        return jsonify({
            'success': False,
            'error': f"Error executing code: {str(e)}"
        }), 500

if __name__ == '__main__':
    # Test Jupyter connectivity before starting
    token = app.config['JUPYTER_API_TOKEN']
    logger.info(f"Testing connection to Jupyter using token: {token[:4]}...")
    
    try:
        # Test the connection by listing kernelspecs - use token in URL
        response = requests.get(
            f"{app.config['JUPYTER_SERVER_URL']}/api/kernelspecs?token={token}"
        )
        
        if response.status_code == 200:
            kernelspecs = response.json()
            logger.info(f"✅ Successfully connected to Jupyter server.")
            logger.info(f"Available kernels: {list(kernelspecs['kernelspecs'].keys())}")
        else:
            logger.error(f"❌ Failed to connect to Jupyter server: {response.status_code}")
            logger.error(f"Response: {response.text}")
    except Exception as e:
        logger.error(f"❌ Error connecting to Jupyter server: {str(e)}")
    
    logger.info(f"Starting Flask application on http://localhost:5000")
    app.run(debug=True, port=5000)
