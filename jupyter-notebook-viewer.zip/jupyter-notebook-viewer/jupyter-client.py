"""
Enhanced Jupyter Client to communicate with Jupyter server
using the REST API and websockets to get real-time execution results.
"""

import json
import logging
import requests
import time
import uuid
import threading
import websocket

logger = logging.getLogger('jupyter-notebook-viewer')

class JupyterClient:
    """Client to interact with Jupyter server."""
    
    def __init__(self, base_url, token=None):
        """Initialize with Jupyter server URL and optional token."""
        self.base_url = base_url.rstrip('/')
        self.token = token
        self.ws_connected = False
        self.ws = None
        self.message_callbacks = {}
        self.execution_results = {}
    
    def get_headers(self):
        """Get HTTP headers with authentication."""
        headers = {'Content-Type': 'application/json'}
        if self.token:
            headers['Authorization'] = f'Token {self.token}'
        return headers
    
    def create_kernel(self):
        """Create a new kernel and return kernel_id."""
        url = f"{self.base_url}/api/kernels"
        response = requests.post(url, headers=self.get_headers())
        
        if response.status_code != 201:
            raise Exception(f"Failed to create kernel: {response.text}")
        
        kernel_data = response.json()
        kernel_id = kernel_data['id']
        return kernel_id
    
    def connect_websocket(self, kernel_id):
        """Connect to kernel websocket."""
        ws_url = f"{self.base_url.replace('http', 'ws')}/api/kernels/{kernel_id}/channels"
        if self.token:
            ws_url += f"?token={self.token}"
        
        def on_message(ws, message):
            """Handle incoming websocket messages."""
            try:
                msg = json.loads(message)
                msg_id = msg.get('parent_header', {}).get('msg_id')
                if msg_id and msg_id in self.message_callbacks:
                    self.message_callbacks[msg_id](msg)
                
                # Store execution results
                if msg_id:
                    if msg_id not in self.execution_results:
                        self.execution_results[msg_id] = []
                    self.execution_results[msg_id].append(msg)
            except Exception as e:
                logger.error(f"Error processing websocket message: {str(e)}")
        
        def on_error(ws, error):
            logger.error(f"Websocket error: {str(error)}")
            self.ws_connected = False
        
        def on_close(ws, close_status_code, close_msg):
            logger.info(f"Websocket connection closed: {close_status_code}, {close_msg}")
            self.ws_connected = False
        
        def on_open(ws):
            logger.info(f"Websocket connection established to kernel {kernel_id}")
            self.ws_connected = True
        
        self.ws = websocket.WebSocketApp(
            ws_url,
            on_message=on_message,
            on_error=on_error,
            on_close=on_close,
            on_open=on_open
        )
        
        # Start websocket connection in a separate thread
        websocket_thread = threading.Thread(target=self.ws.run_forever)
        websocket_thread.daemon = True
        websocket_thread.start()
        
        # Wait for connection to be established
        for _ in range(30):  # Wait up to 3 seconds
            if self.ws_connected:
                return True
            time.sleep(0.1)
        
        return False
    
    def execute_code(self, kernel_id, code, timeout=10):
        """Execute code and return results."""
        # Generate a random message ID
        msg_id = str(uuid.uuid4())
        
        # Define what to do with execution results
        results = {
            'outputs': [],
            'status': 'busy',
            'success': False,
            'error': None
        }
        
        def handle_message(msg):
            """Process messages related to this execution."""
            msg_type = msg.get('msg_type', msg.get('header', {}).get('msg_type'))
            content = msg.get('content', {})
            
            if msg_type == 'status':
                results['status'] = content.get('execution_state', 'unknown')
            elif msg_type == 'stream':
                results['outputs'].append({
                    'output_type': 'stream',
                    'name': content.get('name', 'stdout'),
                    'text': content.get('text', '')
                })
            elif msg_type == 'execute_result':
                results['outputs'].append({
                    'output_type': 'execute_result',
                    'data': content.get('data', {}),
                    'execution_count': content.get('execution_count')
                })
            elif msg_type == 'display_data':
                results['outputs'].append({
                    'output_type': 'display_data',
                    'data': content.get('data', {}),
                    'metadata': content.get('metadata', {})
                })
            elif msg_type == 'error':
                results['error'] = {
                    'ename': content.get('ename', ''),
                    'evalue': content.get('evalue', ''),
                    'traceback': content.get('traceback', [])
                }
                results['outputs'].append({
                    'output_type': 'error',
                    'ename': content.get('ename', ''),
                    'evalue': content.get('evalue', ''),
                    'traceback': content.get('traceback', [])
                })
        
        # Register callback for this message ID
        self.message_callbacks[msg_id] = handle_message
        
        # Execute the code via REST API
        url = f"{self.base_url}/api/kernels/{kernel_id}/execute"
        payload = {
            'code': code,
            'silent': False,
            'store_history': True,
            'user_expressions': {},
            'allow_stdin': False
        }
        
        response = requests.post(
            url, 
            headers=self.get_headers(),
            json=payload
        )
        
        if response.status_code != 200:
            raise Exception(f"Failed to execute code: {response.text}")
        
        # Replace message ID with the one from the response
        response_data = response.json()
        actual_msg_id = response_data.get('msg_id')
        if actual_msg_id and actual_msg_id != msg_id:
            self.message_callbacks[actual_msg_id] = self.message_callbacks.pop(msg_id)
            msg_id = actual_msg_id
        
        # Wait for execution to complete (when status becomes 'idle')
        start_time = time.time()
        while results['status'] != 'idle' and time.time() - start_time < timeout:
            time.sleep(0.1)
        
        # Check if we have results or need to fall back to REST API
        if not results['outputs'] and not results['error']:
            # Try to get results via REST API as fallback
            logger.info("No WebSocket results, falling back to REST API")
            try:
                output_url = f"{self.base_url}/api/kernels/{kernel_id}/iopub"
                output_response = requests.get(output_url, headers=self.get_headers())
                if output_response.status_code == 200:
                    for msg in output_response.json():
                        if msg.get('parent_header', {}).get('msg_id') == msg_id:
                            handle_message(msg)
            except Exception as e:
                logger.error(f"Error fetching results via REST API: {str(e)}")
        
        # Clean up
        if msg_id in self.message_callbacks:
            del self.message_callbacks[msg_id]
        
        # Set success flag if no error occurred
        if not results['error']:
            results['success'] = True
        
        return results
    
    def close(self):
        """Close the websocket connection."""
        if self.ws:
            self.ws.close()
            self.ws_connected = False
