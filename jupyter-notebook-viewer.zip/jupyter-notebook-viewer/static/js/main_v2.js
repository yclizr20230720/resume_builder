document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const uploadContainer = document.getElementById('uploadContainer');
    const fileInput = document.getElementById('fileInput');
    const browseBtn = document.getElementById('browseBtn');
    const welcomeContainer = document.getElementById('welcomeContainer');
    const notebookContainer = document.getElementById('notebookContainer');
    const notebookCells = document.getElementById('notebookCells');
    const notebookInfo = document.getElementById('notebookInfo');
    const notebookTitle = document.getElementById('notebookTitle');
    const notebookDate = document.getElementById('notebookDate');
    const kernelInfo = document.getElementById('kernelInfo');
    const mainTitle = document.getElementById('mainTitle');
    const runAllBtn = document.getElementById('runAllBtn');
    const clearBtn = document.getElementById('clearBtn');
    const loadingOverlay = document.getElementById('loadingOverlay');
    
    // Templates
    const codeCellTemplate = document.getElementById('codeCellTemplate');
    const markdownCellTemplate = document.getElementById('markdownCellTemplate');
    
    // State
    let currentNotebook = null;
    let currentFilename = null;
    let currentKernelId = null;
    
    // Event Listeners
    browseBtn.addEventListener('click', () => fileInput.click());
    
    uploadContainer.addEventListener('click', () => fileInput.click());
    
    fileInput.addEventListener('change', handleFileSelect);
    
    // Drag and drop handlers
    uploadContainer.addEventListener('dragover', (e) => {
        e.preventDefault();
        e.stopPropagation();
        uploadContainer.classList.add('highlight');
    });
    
    uploadContainer.addEventListener('dragleave', (e) => {
        e.preventDefault();
        e.stopPropagation();
        uploadContainer.classList.remove('highlight');
    });
    
    uploadContainer.addEventListener('drop', (e) => {
        e.preventDefault();
        e.stopPropagation();
        uploadContainer.classList.remove('highlight');
        
        if (e.dataTransfer.files.length) {
            fileInput.files = e.dataTransfer.files;
            handleFileSelect();
        }
    });
    
    runAllBtn.addEventListener('click', runAllCells);
    clearBtn.addEventListener('click', clearAllOutputs);
    
    // Functions
    async function handleFileSelect() {
        if (!fileInput.files.length) return;
        
        const file = fileInput.files[0];
        if (!file.name.endsWith('.ipynb')) {
            alert('Please select a valid Jupyter notebook (.ipynb) file.');
            return;
        }
        
        showLoading(true);
        
        const formData = new FormData();
        formData.append('file', file);
        
        try {
            const response = await fetch('/api/upload', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                currentNotebook = data.notebook;
                currentFilename = data.filename;
                renderNotebook(currentNotebook);
            } else {
                alert(`Error: ${data.error || 'Failed to upload notebook'}`);
            }
        } catch (error) {
            console.error('Error uploading notebook:', error);
            alert('Failed to upload notebook. Please try again.');
        } finally {
            showLoading(false);
        }
    }
    
    function renderNotebook(notebook) {
        // Clear previous cells
        notebookCells.innerHTML = '';
        
        // Update UI
        welcomeContainer.classList.add('hidden');
        notebookContainer.classList.remove('hidden');
        notebookInfo.classList.remove('hidden');
        runAllBtn.classList.remove('hidden');
        clearBtn.classList.remove('hidden');
        
        // Set notebook info
        notebookTitle.textContent = currentFilename || 'Untitled Notebook';
        mainTitle.textContent = currentFilename || 'Untitled Notebook';
        
        // Get notebook metadata
        const metadata = notebook.metadata || {};
        const kernelspec = metadata.kernelspec || {};
        const created = new Date().toLocaleDateString();
        
        notebookDate.textContent = `Last Modified: ${created}`;
        kernelInfo.textContent = `Kernel: ${kernelspec.display_name || kernelspec.name || 'Python'}`;
        
        // Render cells
        const cells = notebook.cells || [];
        
        cells.forEach((cell, index) => {
            renderCell(cell, index);
        });
        
        // Initialize syntax highlighting and markdown rendering
        initSyntaxHighlighting();
        initMarkdownRendering();
    }
    
    function renderCell(cell, index) {
        const cellType = cell.cell_type;
        const source = Array.isArray(cell.source) ? cell.source.join('') : cell.source || '';
        
        if (cellType === 'code') {
            renderCodeCell(cell, index, source);
        } else if (cellType === 'markdown') {
            renderMarkdownCell(cell, index, source);
        }
    }
    
    function renderCodeCell(cell, index, source) {
        const template = codeCellTemplate.content.cloneNode(true);
        const cellElement = template.querySelector('.cell');
        
        cellElement.dataset.index = index;
        cellElement.dataset.cellType = 'code';
        
        const inputCode = cellElement.querySelector('.cell-input-code');
        
        // Format source code with line numbers
        const formattedCode = formatCodeWithLineNumbers(source);
        inputCode.innerHTML = formattedCode;
        
        // Add execution count if available
        const cellType = cellElement.querySelector('.cell-type');
        if (cell.execution_count !== null && cell.execution_count !== undefined) {
            const execCount = document.createElement('span');
            execCount.className = 'exec-count';
            execCount.textContent = ` [${cell.execution_count}]`;
            cellType.appendChild(execCount);
        }
        
        // Handle run button click
        const runBtn = cellElement.querySelector('.run-btn');
        runBtn.addEventListener('click', () => executeCell(cellElement, source));
        
        // Handle output toggle
        const toggleBtn = cellElement.querySelector('.toggle-output-btn');
        const outputContent = cellElement.querySelector('.output-content');
        toggleBtn.addEventListener('click', () => {
            const isHidden = outputContent.style.display === 'none';
            outputContent.style.display = isHidden ? 'block' : 'none';
            toggleBtn.innerHTML = isHidden ? 
                '<i class="fas fa-chevron-up"></i>' : 
                '<i class="fas fa-chevron-down"></i>';
        });
        
        // Show existing outputs if available
        if (cell.outputs && cell.outputs.length > 0) {
            renderCellOutputs(cellElement, cell.outputs);
        }
        
        notebookCells.appendChild(cellElement);
    }
    
    function formatCodeWithLineNumbers(code) {
        // Split the code into lines
        const lines = code.split('\n');
        
        // Create a formatted version with line numbers
        let formattedCode = '<table class="code-with-line-numbers">';
        lines.forEach((line, index) => {
            const lineNumber = index + 1;
            // Apply syntax highlighting to each line
            const processedLine = line
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;');
                
            formattedCode += `
                <tr>
                    <td class="line-number">${lineNumber}</td>
                    <td class="code-line">${processedLine}</td>
                </tr>
            `;
        });
        formattedCode += '</table>';
        
        return formattedCode;
    }
    
    function renderMarkdownCell(cell, index, source) {
        const template = markdownCellTemplate.content.cloneNode(true);
        const cellElement = template.querySelector('.cell');
        
        cellElement.dataset.index = index;
        cellElement.dataset.cellType = 'markdown';
        
        const inputMarkdown = cellElement.querySelector('.cell-input-markdown');
        inputMarkdown.textContent = source;
        
        const outputMarkdown = cellElement.querySelector('.markdown-output');
        outputMarkdown.innerHTML = marked.parse(source);
        
        // Handle edit button click
        const editBtn = cellElement.querySelector('.edit-btn');
        editBtn.addEventListener('click', () => {
            const inputDiv = cellElement.querySelector('.cell-input');
            const outputDiv = cellElement.querySelector('.cell-output');
            
            if (inputDiv.classList.contains('hidden')) {
                // Switch to edit mode
                inputDiv.classList.remove('hidden');
                outputDiv.classList.add('hidden');
                editBtn.innerHTML = '<i class="fas fa-check"></i> Done';
            } else {
                // Switch to view mode and update content
                const newSource = inputMarkdown.textContent;
                outputMarkdown.innerHTML = marked.parse(newSource);
                
                // Update in notebook data
                currentNotebook.cells[index].source = newSource;
                
                inputDiv.classList.add('hidden');
                outputDiv.classList.remove('hidden');
                editBtn.innerHTML = '<i class="fas fa-edit"></i> Edit';
                
                // Re-render KaTeX
                renderMathInElement(outputMarkdown);
            }
        });
        
        notebookCells.appendChild(cellElement);
    }
    
    async function executeCell(cellElement, code) {
        const outputDiv = cellElement.querySelector('.cell-output');
        const outputContent = cellElement.querySelector('.output-content');
        
        // Clear previous outputs
        outputContent.innerHTML = '';
        outputDiv.classList.remove('hidden');
        
        // Show loading indicator
        const loadingEl = document.createElement('div');
        loadingEl.className = 'cell-loading';
        loadingEl.innerHTML = '<div class="spinner small"></div><span>Running...</span>';
        outputContent.appendChild(loadingEl);
        
        try {
            const response = await fetch('/api/execute_cell', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    code: code,
                    kernel_id: currentKernelId
                })
            });
            
            const data = await response.json();
            
            // Store kernel ID for subsequent calls if available
            if (data.kernel_id) {
                currentKernelId = data.kernel_id;
            }
            
            // Remove loading indicator
            outputContent.removeChild(loadingEl);
            
            if (data.success) {
                // Display output
                if (data.output) {
                    // Handle image/png output
                    if (data.output['image/png']) {
                        const imgEl = document.createElement('img');
                        imgEl.src = `data:image/png;base64,${data.output['image/png']}`;
                        imgEl.className = 'output-image';
                        outputContent.appendChild(imgEl);
                    }
                    
                    // Handle text/html output
                    if (data.output['text/html']) {
                        const htmlEl = document.createElement('div');
                        htmlEl.className = 'output-html';
                        htmlEl.innerHTML = Array.isArray(data.output['text/html']) 
                            ? data.output['text/html'].join('') 
                            : data.output['text/html'];
                        outputContent.appendChild(htmlEl);
                    }
                    
                    // Handle text/plain output
                    if (data.output['text/plain']) {
                        const textEl = document.createElement('div');
                        textEl.className = 'output-text';
                        textEl.textContent = Array.isArray(data.output['text/plain']) 
                            ? data.output['text/plain'].join('') 
                            : data.output['text/plain'];
                        outputContent.appendChild(textEl);
                    }
                }
            } else if (data.error) {
                // Display error information
                const errorEl = document.createElement('div');
                errorEl.className = 'output-error';
                
                // Create structured error display
                if (data.error.ename && data.error.evalue) {
                    const errorName = document.createElement('div');
                    errorName.className = 'error-name';
                    errorName.textContent = data.error.ename;
                    
                    const errorValue = document.createElement('div');
                    errorValue.className = 'error-value';
                    errorValue.textContent = data.error.evalue;
                    
                    errorEl.appendChild(errorName);
                    errorEl.appendChild(errorValue);
                    
                    if (data.error.traceback) {
                        const errorTraceback = document.createElement('pre');
                        errorTraceback.className = 'error-traceback';
                        errorTraceback.textContent = Array.isArray(data.error.traceback) 
                            ? data.error.traceback.join('\n') 
                            : data.error.traceback;
                        errorEl.appendChild(errorTraceback);
                    }
                } else {
                    // Simple error message
                    errorEl.textContent = `Error: ${typeof data.error === 'string' ? data.error : 'Execution failed'}`;
                }
                
                outputContent.appendChild(errorEl);
            } else {
                throw new Error('Unknown error during execution');
            }
        } catch (error) {
            console.error('Error executing cell:', error);
            
            // Remove loading indicator if it's still there
            if (loadingEl.parentNode === outputContent) {
                outputContent.removeChild(loadingEl);
            }
            
            // Show error
            const errorEl = document.createElement('div');
            errorEl.className = 'output-error';
            errorEl.textContent = `Error: ${error.message || 'Failed to execute code'}`;
            outputContent.appendChild(errorEl);
        }
    }
    
    function renderCellOutputs(cellElement, outputs) {
        const outputDiv = cellElement.querySelector('.cell-output');
        const outputContent = cellElement.querySelector('.output-content');
        
        outputDiv.classList.remove('hidden');
        outputContent.innerHTML = '';
        
        outputs.forEach(output => {
            if (output.output_type === 'stream') {
                const streamDiv = document.createElement('div');
                streamDiv.className = 'output-stream';
                streamDiv.textContent = Array.isArray(output.text) ? output.text.join('') : output.text;
                outputContent.appendChild(streamDiv);
            }
            else if (output.output_type === 'execute_result' || output.output_type === 'display_data') {
                const data = output.data;
                
                if (data['text/html']) {
                    const htmlDiv = document.createElement('div');
                    htmlDiv.className = 'output-html';
                    htmlDiv.innerHTML = Array.isArray(data['text/html']) ? data['text/html'].join('') : data['text/html'];
                    outputContent.appendChild(htmlDiv);
                }
                else if (data['text/plain']) {
                    const textDiv = document.createElement('div');
                    textDiv.className = 'output-text';
                    textDiv.textContent = Array.isArray(data['text/plain']) ? data['text/plain'].join('') : data['text/plain'];
                    outputContent.appendChild(textDiv);
                }
                
                if (output.execution_count !== null && output.execution_count !== undefined) {
                    const execCount = document.createElement('div');
                    execCount.className = 'output-execution-count';
                    execCount.textContent = `Out[${output.execution_count}]:`;
                    outputContent.insertBefore(execCount, outputContent.firstChild);
                }
            }
            else if (output.output_type === 'error') {
                const errorDiv = document.createElement('div');
                errorDiv.className = 'output-error';
                
                const errorName = document.createElement('div');
                errorName.className = 'error-name';
                errorName.textContent = output.ename;
                
                const errorValue = document.createElement('div');
                errorValue.className = 'error-value';
                errorValue.textContent = output.evalue;
                
                const errorTraceback = document.createElement('pre');
                errorTraceback.className = 'error-traceback';
                errorTraceback.textContent = Array.isArray(output.traceback) ? output.traceback.join('\n') : output.traceback;
                
                errorDiv.appendChild(errorName);
                errorDiv.appendChild(errorValue);
                errorDiv.appendChild(errorTraceback);
                
                outputContent.appendChild(errorDiv);
            }
        });
    }
    
    function runAllCells() {
        const codeCells = document.querySelectorAll('.code-cell');
        
        codeCells.forEach(cell => {
            const runBtn = cell.querySelector('.run-btn');
            if (runBtn) {
                runBtn.click();
            }
        });
    }
    
    function clearAllOutputs() {
        const cells = document.querySelectorAll('.cell');
        
        cells.forEach(cell => {
            const outputDiv = cell.querySelector('.cell-output');
            const outputContent = cell.querySelector('.output-content');
            
            if (outputDiv && !cell.classList.contains('markdown-cell')) {
                outputDiv.classList.add('hidden');
                if (outputContent) {
                    outputContent.innerHTML = '';
                }
            }
        });
    }
    
    function initSyntaxHighlighting() {
        document.querySelectorAll('.cell-input-code').forEach(block => {
            hljs.highlightElement(block);
        });
    }
    
    function initMarkdownRendering() {
        document.querySelectorAll('.markdown-output').forEach(element => {
            renderMathInElement(element);
        });
    }
    
    function renderMathInElement(element) {
        renderMathInElement(element, {
            delimiters: [
                {left: '$$', right: '$$', display: true},
                {left: '$', right: '$', display: false},
                {left: '\\(', right: '\\)', display: false},
                {left: '\\[', right: '\\]', display: true}
            ],
            throwOnError: false
        });
    }
    
    function showLoading(show) {
        if (show) {
            loadingOverlay.classList.remove('hidden');
        } else {
            loadingOverlay.classList.add('hidden');
        }
    }
});
