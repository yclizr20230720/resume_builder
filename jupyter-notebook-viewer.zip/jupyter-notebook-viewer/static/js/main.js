document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const uploadContainer = document.getElementById('uploadContainer');
    const fileInput = document.getElementById('fileInput');
    const browseBtn = document.getElementById('browseBtn');
    const welcomeContainer = document.getElementById('welcomeContainer');
    const notebookContainer = document.getElementById('notebookContainer');
    const notebookCells = document.getElementById('notebookCells');
    const notebookInfo = document.getElementById('notebookInfo');
    const notebookTitle = document.getElementById('notebookTitle');
    const notebookDate = document.getElementById('notebookDate');
    const kernelInfo = document.getElementById('kernelInfo');
    const mainTitle = document.getElementById('mainTitle');
    const runAllBtn = document.getElementById('runAllBtn');
    const clearBtn = document.getElementById('clearBtn');
    const loadingOverlay = document.getElementById('loadingOverlay');
    
    // Templates
    const codeCellTemplate = document.getElementById('codeCellTemplate');
    const markdownCellTemplate = document.getElementById('markdownCellTemplate');
    
    // State
    let currentNotebook = null;
    let currentFilename = null;
    let currentKernelId = null;
    
    // Event Listeners
    browseBtn.addEventListener('click', () => fileInput.click());
    
    uploadContainer.addEventListener('click', () => fileInput.click());
    
    fileInput.addEventListener('change', handleFileSelect);
    
    // Drag and drop handlers
    uploadContainer.addEventListener('dragover', (e) => {
        e.preventDefault();
        e.stopPropagation();
        uploadContainer.classList.add('highlight');
    });
    
    uploadContainer.addEventListener('dragleave', (e) => {
        e.preventDefault();
        e.stopPropagation();
        uploadContainer.classList.remove('highlight');
    });
    
    uploadContainer.addEventListener('drop', (e) => {
        e.preventDefault();
        e.stopPropagation();
        uploadContainer.classList.remove('highlight');
        
        if (e.dataTransfer.files.length) {
            fileInput.files = e.dataTransfer.files;
            handleFileSelect();
        }
    });
    
    runAllBtn.addEventListener('click', runAllCells);
    clearBtn.addEventListener('click', clearAllOutputs);
    
    // Functions
    async function handleFileSelect() {
        if (!fileInput.files.length) return;
        
        const file = fileInput.files[0];
        if (!file.name.endsWith('.ipynb')) {
            alert('Please select a valid Jupyter notebook (.ipynb) file.');
            return;
        }
        
        showLoading(true);
        
        const formData = new FormData();
        formData.append('file', file);
        
        try {
            const response = await fetch('/api/upload', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                currentNotebook = data.notebook;
                currentFilename = data.filename;
                renderNotebook(currentNotebook);
            } else {
                alert(`Error: ${data.error || 'Failed to upload notebook'}`);
            }
        } catch (error) {
            console.error('Error uploading notebook:', error);
            alert('Failed to upload notebook. Please try again.');
        } finally {
            showLoading(false);
        }
    }
    
    function renderNotebook(notebook) {
        // Clear previous cells
        notebookCells.innerHTML = '';
        
        // Update UI
        welcomeContainer.classList.add('hidden');
        notebookContainer.classList.remove('hidden');
        notebookInfo.classList.remove('hidden');
        runAllBtn.classList.remove('hidden');
        clearBtn.classList.remove('hidden');
        
        // Set notebook info
        notebookTitle.textContent = currentFilename || 'Untitled Notebook';
        mainTitle.textContent = currentFilename || 'Untitled Notebook';
        
        // Get notebook metadata
        const metadata = notebook.metadata || {};
        const kernelspec = metadata.kernelspec || {};
        const created = new Date().toLocaleDateString();
        
        notebookDate.textContent = `Last Modified: ${created}`;
        kernelInfo.textContent = `Kernel: ${kernelspec.display_name || kernelspec.name || 'Python'}`;
        
        // Render cells
        const cells = notebook.cells || [];
        
        cells.forEach((cell, index) => {
            renderCell(cell, index);
        });
        
        // Initialize syntax highlighting and markdown rendering
        initSyntaxHighlighting();
        initMarkdownRendering();
    }
    
    function renderCell(cell, index) {
        const cellType = cell.cell_type;
        const source = cell.source;
        
        // Debug log to help trace issues
        console.debug(`Rendering cell ${index}, type: ${cellType}, source type: ${Array.isArray(source) ? 'array' : typeof source}`);
        
        if (cellType === 'code') {
            renderCodeCell(cell, index, source);
        } else if (cellType === 'markdown') {
            renderMarkdownCell(cell, index, source);
        } else {
            console.warn(`Unsupported cell type: ${cellType}`);
        }
    }
    
    function renderCodeCell(cell, index, source) {
        const template = codeCellTemplate.content.cloneNode(true);
        const cellElement = template.querySelector('.cell');
        
        cellElement.dataset.index = index;
        cellElement.dataset.cellType = 'code';
        
        const inputCode = cellElement.querySelector('.cell-input-code');
        
        // Format source code with line numbers
        // Handle source being either a string or array
        let lines = Array.isArray(source) ? source : source.split('\n');
        
        // Create table with line numbers
        let formattedCode = '<table class="code-with-line-numbers" width="100%">';
        
        lines.forEach((line, i) => {
            // Ensure line is a string
            const lineStr = typeof line === 'string' ? line : String(line);
            
            // Escape HTML special characters
            const escapedLine = lineStr
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;');
                
            formattedCode += `
                <tr>
                    <td class="line-number">${i + 1}</td>
                    <td class="code-line"><pre class="no-margin">${escapedLine}</pre></td>
                </tr>
            `;
        });
        
        formattedCode += '</table>';
        inputCode.innerHTML = formattedCode;
        
        // Add execution count if available
        const cellType = cellElement.querySelector('.cell-type');
        if (cell.execution_count !== null && cell.execution_count !== undefined) {
            const execCount = document.createElement('span');
            execCount.className = 'exec-count';
            execCount.textContent = ` [${cell.execution_count}]`;
            cellType.appendChild(execCount);
        }
        
        // Prepare the code for execution - joining lines if it's an array
        const codeToExecute = Array.isArray(source) ? source.join('\n') : source;
        
        // Handle run button click
        const runBtn = cellElement.querySelector('.run-btn');
        runBtn.addEventListener('click', () => executeCell(cellElement, codeToExecute));
        
        // Handle output toggle
        const toggleBtn = cellElement.querySelector('.toggle-output-btn');
        const outputContent = cellElement.querySelector('.output-content');
        toggleBtn.addEventListener('click', () => {
            const isHidden = outputContent.style.display === 'none';
            outputContent.style.display = isHidden ? 'block' : 'none';
            toggleBtn.innerHTML = isHidden ? 
                '<i class="fas fa-chevron-up"></i>' : 
                '<i class="fas fa-chevron-down"></i>';
        });
        
        // Show existing outputs if available
        if (cell.outputs && cell.outputs.length > 0) {
            renderCellOutputs(cellElement, cell.outputs);
        }
        
        notebookCells.appendChild(cellElement);
    }
    
    function renderMarkdownCell(cell, index, source) {
        const template = markdownCellTemplate.content.cloneNode(true);
        const cellElement = template.querySelector('.cell');
        
        cellElement.dataset.index = index;
        cellElement.dataset.cellType = 'markdown';
        
        const outputMarkdown = cellElement.querySelector('.markdown-output');
        
        // Convert source to string if it's an array
        const markdownText = Array.isArray(source) ? source.join('\n') : source;
        
        // Render the markdown
        outputMarkdown.innerHTML = marked.parse(markdownText);
        
        notebookCells.appendChild(cellElement);
    }
    
    async function executeCell(cellElement, code) {
        const outputDiv = cellElement.querySelector('.cell-output');
        const outputContent = cellElement.querySelector('.output-content');
        
        // Clear previous outputs
        outputContent.innerHTML = '';
        outputDiv.classList.remove('hidden');
        
        // Show loading indicator
        const loadingEl = document.createElement('div');
        loadingEl.className = 'cell-loading';
        loadingEl.innerHTML = '<div class="spinner small"></div><span>Running...</span>';
        outputContent.appendChild(loadingEl);
        
        try {
            // Make the API call to execute the cell
            console.log(`Executing cell with code: ${code.substring(0, 50)}...`);
            
            const response = await fetch('/api/execute_cell', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    code: code,
                    kernel_id: currentKernelId
                })
            });
            
            // Remove loading indicator
            if (loadingEl.parentNode === outputContent) {
                outputContent.removeChild(loadingEl);
            }
            
            const data = await response.json();
            console.log('Execution response:', data);
            
            // Store kernel ID for subsequent calls
            if (data.kernel_id) {
                currentKernelId = data.kernel_id;
            }
            
            if (data.success) {
                // Handle successful execution with output
                if (data.output && Object.keys(data.output).length > 0) {
                    // Process different output types
                    
                    // Text output
                    if (data.output['text/plain']) {
                        const textEl = document.createElement('div');
                        textEl.className = 'output-text';
                        textEl.textContent = data.output['text/plain'];
                        outputContent.appendChild(textEl);
                    }
                    
                    // HTML output
                    if (data.output['text/html']) {
                        const htmlEl = document.createElement('div');
                        htmlEl.className = 'output-html';
                        htmlEl.innerHTML = data.output['text/html'];
                        outputContent.appendChild(htmlEl);
                    }
                    
                    // Image output
                    if (data.output['image/png']) {
                        const imgEl = document.createElement('img');
                        imgEl.className = 'output-image';
                        imgEl.src = `data:image/png;base64,${data.output['image/png']}`;
                        outputContent.appendChild(imgEl);
                    }
                } else {
                    // No output
                    const msgEl = document.createElement('div');
                    msgEl.className = 'output-message';
                    msgEl.textContent = 'Cell executed successfully with no output.';
                    outputContent.appendChild(msgEl);
                }
            } else if (data.error) {
                // Handle execution errors
                if (typeof data.error === 'string') {
                    // Simple error string
                    const errorEl = document.createElement('div');
                    errorEl.className = 'output-error';
                    errorEl.textContent = `Error: ${data.error}`;
                    outputContent.appendChild(errorEl);
                } else {
                    // Structured error object
                    const errorEl = document.createElement('div');
                    errorEl.className = 'output-error';
                    
                    const errorNameEl = document.createElement('div');
                    errorNameEl.className = 'error-name';
                    errorNameEl.textContent = data.error.ename || 'Error';
                    
                    const errorValueEl = document.createElement('div');
                    errorValueEl.className = 'error-value';
                    errorValueEl.textContent = data.error.evalue || '';
                    
                    errorEl.appendChild(errorNameEl);
                    errorEl.appendChild(errorValueEl);
                    
                    if (data.error.traceback) {
                        const tracebackEl = document.createElement('pre');
                        tracebackEl.className = 'error-traceback';
                        tracebackEl.textContent = Array.isArray(data.error.traceback) 
                            ? data.error.traceback.join('\n') 
                            : data.error.traceback;
                        errorEl.appendChild(tracebackEl);
                    }
                    
                    outputContent.appendChild(errorEl);
                }
                
                // Add details if available
                if (data.details) {
                    const detailsEl = document.createElement('div');
                    detailsEl.className = 'error-details';
                    detailsEl.textContent = data.details;
                    outputContent.appendChild(detailsEl);
                }
            }
        } catch (error) {
            console.error('Error executing cell:', error);
            
            // Remove loading indicator if it's still there
            if (loadingEl.parentNode === outputContent) {
                outputContent.removeChild(loadingEl);
            }
            
            // Show error
            const errorEl = document.createElement('div');
            errorEl.className = 'output-error';
            errorEl.textContent = `Error: ${error.message || 'Failed to execute code'}`;
            outputContent.appendChild(errorEl);
            
            // Add help information
            const helpEl = document.createElement('div');
            helpEl.className = 'error-help';
            helpEl.innerHTML = `
                <p>This might be due to one of the following reasons:</p>
                <ul>
                    <li>Jupyter server is not running at http://localhost:8888</li>
                    <li>Incorrect Jupyter token in app.py configuration</li>
                    <li>Network connectivity issues</li>
                </ul>
                <p>Please check the Flask application logs for more details.</p>
            `;
            outputContent.appendChild(helpEl);
        }
    }
    
    function renderCellOutputs(cellElement, outputs) {
        const outputDiv = cellElement.querySelector('.cell-output');
        const outputContent = cellElement.querySelector('.output-content');
        
        outputDiv.classList.remove('hidden');
        outputContent.innerHTML = '';
        
        outputs.forEach(output => {
            if (output.output_type === 'stream') {
                const streamDiv = document.createElement('div');
                streamDiv.className = 'output-stream';
                const text = Array.isArray(output.text) ? output.text.join('') : output.text;
                streamDiv.textContent = text;
                outputContent.appendChild(streamDiv);
            }
            else if (output.output_type === 'execute_result' || output.output_type === 'display_data') {
                const data = output.data || {};
                
                if (data['text/html']) {
                    const htmlDiv = document.createElement('div');
                    htmlDiv.className = 'output-html';
                    const html = Array.isArray(data['text/html']) ? data['text/html'].join('') : data['text/html'];
                    htmlDiv.innerHTML = html;
                    outputContent.appendChild(htmlDiv);
                }
                else if (data['text/plain']) {
                    const textDiv = document.createElement('div');
                    textDiv.className = 'output-text';
                    const text = Array.isArray(data['text/plain']) ? data['text/plain'].join('') : data['text/plain'];
                    textDiv.textContent = text;
                    outputContent.appendChild(textDiv);
                }
                
                if (data['image/png']) {
                    const imgDiv = document.createElement('div');
                    imgDiv.className = 'output-image-container';
                    const img = document.createElement('img');
                    img.className = 'output-image';
                    img.src = `data:image/png;base64,${data['image/png']}`;
                    imgDiv.appendChild(img);
                    outputContent.appendChild(imgDiv);
                }
                
                if (output.execution_count !== null && output.execution_count !== undefined) {
                    const execCount = document.createElement('div');
                    execCount.className = 'output-execution-count';
                    execCount.textContent = `Out[${output.execution_count}]:`;
                    outputContent.insertBefore(execCount, outputContent.firstChild);
                }
            }
            else if (output.output_type === 'error') {
                const errorDiv = document.createElement('div');
                errorDiv.className = 'output-error';
                
                const errorName = document.createElement('div');
                errorName.className = 'error-name';
                errorName.textContent = output.ename || 'Error';
                
                const errorValue = document.createElement('div');
                errorValue.className = 'error-value';
                errorValue.textContent = output.evalue || '';
                
                const errorTraceback = document.createElement('pre');
                errorTraceback.className = 'error-traceback';
                errorTraceback.textContent = Array.isArray(output.traceback) 
                    ? output.traceback.join('\n') 
                    : (output.traceback || '');
                
                errorDiv.appendChild(errorName);
                errorDiv.appendChild(errorValue);
                errorDiv.appendChild(errorTraceback);
                
                outputContent.appendChild(errorDiv);
            }
        });
    }
    
    function runAllCells() {
        const codeCells = document.querySelectorAll('.code-cell');
        
        codeCells.forEach(cell => {
            const runBtn = cell.querySelector('.run-btn');
            if (runBtn) {
                runBtn.click();
            }
        });
    }
    
    function clearAllOutputs() {
        const cells = document.querySelectorAll('.cell');
        
        cells.forEach(cell => {
            const outputDiv = cell.querySelector('.cell-output');
            const outputContent = cell.querySelector('.output-content');
            
            if (outputDiv && !cell.classList.contains('markdown-cell')) {
                outputDiv.classList.add('hidden');
                if (outputContent) {
                    outputContent.innerHTML = '';
                }
            }
        });
    }
    
    function initSyntaxHighlighting() {
        document.querySelectorAll('.cell-input-code').forEach(block => {
            hljs.highlightElement(block);
        });
    }
    
    function initMarkdownRendering() {
        document.querySelectorAll('.markdown-output').forEach(element => {
            renderMathInElement(element);
        });
    }
    
    function renderMathInElement(element) {
        renderMathInElement(element, {
            delimiters: [
                {left: '$$', right: '$$', display: true},
                {left: '$', right: '$', display: false},
                {left: '\\(', right: '\\)', display: false},
                {left: '\\[', right: '\\]', display: true}
            ],
            throwOnError: false
        });
    }
    
    function showLoading(show) {
        if (show) {
            loadingOverlay.classList.remove('hidden');
        } else {
            loadingOverlay.classList.add('hidden');
        }
    }
});
