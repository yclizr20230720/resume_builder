#!/usr/bin/env python3
"""
Utility to find the Jupyter token from a running server
"""

import os
import re
import json
import subprocess
import requests
from urllib.parse import urlparse, parse_qs

def find_jupyter_token():
    """Try multiple methods to find a Jupyter token"""
    print("Searching for Jupyter token...")
    
    # Method 1: Try to get it from running servers
    token = get_token_from_jupyter_list()
    if token:
        return token
    
    # Method 2: Check for token in ~/.jupyter/jupyter_server_config.json
    token = get_token_from_config()
    if token:
        return token
    
    # Method 3: Access the frontend and try to extract token
    token = get_token_from_frontend()
    if token:
        return token
    
    # No token found
    print("Could not automatically find a Jupyter token.")
    print("You may need to manually copy it from the Jupyter server output.")
    return None

def get_token_from_jupyter_list():
    """Get token by running 'jupyter server list'"""
    try:
        print("Checking running Jupyter servers...")
        output = subprocess.check_output(['jupyter', 'server', 'list'], 
                                        stderr=subprocess.STDOUT, 
                                        universal_newlines=True)
        
        # Look for lines containing http://localhost and token=
        for line in output.split('\n'):
            if 'http://localhost' in line and 'token=' in line:
                # Extract the token
                match = re.search(r'token=([a-f0-9]+)', line)
                if match:
                    token = match.group(1)
                    print(f"Found token from jupyter server list: {token}")
                    return token
        
        print("No token found in jupyter server list output.")
        return None
    except (subprocess.SubprocessError, FileNotFoundError) as e:
        print(f"Error running jupyter server list: {str(e)}")
        return None

def get_token_from_config():
    """Get token from Jupyter config files"""
    try:
        # Check home directory for jupyter config
        print("Checking Jupyter config files...")
        home = os.path.expanduser('~')
        config_paths = [
            os.path.join(home, '.jupyter', 'jupyter_server_config.json'),
            os.path.join(home, '.jupyter', 'jupyter_notebook_config.json')
        ]
        
        for config_path in config_paths:
            if os.path.exists(config_path):
                print(f"Found config file: {config_path}")
                with open(config_path, 'r') as f:
                    config = json.load(f)
                    if 'ServerApp' in config and 'token' in config['ServerApp']:
                        token = config['ServerApp']['token']
                        print(f"Found token in config: {token}")
                        return token
        
        print("No token found in config files.")
        return None
    except Exception as e:
        print(f"Error reading config files: {str(e)}")
        return None

def get_token_from_frontend():
    """Try to access the frontend and extract token from HTML"""
    try:
        print("Trying to access Jupyter frontend...")
        response = requests.get('http://localhost:8888', allow_redirects=True)
        
        # Check if we were redirected to a login page
        if 'login' in response.url:
            # Parse the URL to get the token
            parsed_url = urlparse(response.url)
            query_params = parse_qs(parsed_url.query)
            if 'token' in query_params:
                token = query_params['token'][0]
                print(f"Found token in redirect URL: {token}")
                return token
        
        # Try to extract from HTML
        match = re.search(r'token=([a-f0-9]+)', response.text)
        if match:
            token = match.group(1)
            print(f"Found token in HTML: {token}")
            return token
        
        print("No token found in frontend access.")
        return None
    except Exception as e:
        print(f"Error accessing Jupyter frontend: {str(e)}")
        return None

if __name__ == "__main__":
    token = find_jupyter_token()
    
    if token:
        print("\n" + "="*50)
        print(f"FOUND JUPYTER TOKEN: {token}")
        print("="*50)
        print("\nTo use this token, update the JUPYTER_API_TOKEN in app.py:")
        print(f"app.config['JUPYTER_API_TOKEN'] = '{token}'")
    else:
        print("\nCould not automatically find a token.")
        print("Please check your Jupyter server output and look for a line like:")
        print("    http://localhost:8888/?token=abcdef1234567890abcdef1234567890")
