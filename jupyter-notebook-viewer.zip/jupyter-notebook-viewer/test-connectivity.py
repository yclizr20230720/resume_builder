#!/usr/bin/env python3
"""
Simple test script to check connectivity to the Jupyter server.
Run this before starting the Flask app to verify Jupyter is running correctly.
"""

import requests
import sys
import json

JUPYTER_URL = 'http://localhost:8888'
TOKEN = 'cf787daf5a798c28ec739fd1357638db0cbb5e0a467136e0'  # Enter your Jupyter token here if required

def test_jupyter_connection():
    """Test connection to Jupyter server"""
    print(f"Testing connection to Jupyter server at {JUPYTER_URL}...")
    
    headers = {'Content-Type': 'application/json'}
    if TOKEN:
        headers['Authorization'] = f'Token {TOKEN}'
    
    try:
        # Test 1: Check if Jupyter is running
        response = requests.get(f"{JUPYTER_URL}/api/kernelspecs", headers=headers)
        if response.status_code != 200:
            print(f"ERROR: Could not connect to Jupyter server. Status code: {response.status_code}")
            print(f"Response: {response.text}")
            return False
        
        print("✓ Successfully connected to Jupyter server")
        print(f"Available kernel specs: {list(response.json()['kernelspecs'].keys())}")
        
        # Test 2: Create a test kernel
        print("\nCreating a test kernel...")
        response = requests.post(f"{JUPYTER_URL}/api/kernels", headers=headers)
        
        if response.status_code != 201:
            print(f"ERROR: Could not create a kernel. Status code: {response.status_code}")
            print(f"Response: {response.text}")
            return False
        
        kernel_id = response.json()['id']
        print(f"✓ Successfully created kernel with ID: {kernel_id}")
        
        # Test 3: Execute a simple code in the kernel
        print("\nExecuting a simple code in the kernel...")
        code = 'print("Hello from Jupyter!")'
        
        response = requests.post(
            f"{JUPYTER_URL}/api/kernels/{kernel_id}/execute",
            headers=headers,
            json={
                'code': code,
                'silent': False,
                'store_history': False,
                'user_expressions': {},
                'allow_stdin': False
            }
        )
        
        if response.status_code != 200:
            print(f"ERROR: Could not execute code. Status code: {response.status_code}")
            print(f"Response: {response.text}")
            return False
        
        print(f"✓ Successfully sent code execution request")
        print(f"Message ID: {response.json().get('msg_id')}")
        
        # Test 4: Delete the test kernel
        print("\nDeleting the test kernel...")
        response = requests.delete(f"{JUPYTER_URL}/api/kernels/{kernel_id}", headers=headers)
        
        if response.status_code not in [204, 200]:
            print(f"WARNING: Could not delete kernel. Status code: {response.status_code}")
            print(f"Response: {response.text}")
        else:
            print(f"✓ Successfully deleted kernel")
        
        print("\nAll tests passed! Your Jupyter server is running correctly.")
        return True
        
    except requests.exceptions.ConnectionError:
        print(f"ERROR: Could not connect to Jupyter server at {JUPYTER_URL}")
        print("Make sure Jupyter is running and the URL is correct.")
        return False
    except Exception as e:
        print(f"ERROR: An unexpected error occurred: {str(e)}")
        return False

if __name__ == "__main__":
    success = test_jupyter_connection()
    sys.exit(0 if success else 1)
