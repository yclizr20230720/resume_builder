import os
import json
import time
import nbformat
import requests
from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS
from werkzeug.utils import secure_filename

app = Flask(__name__, static_folder='static', template_folder='templates')
CORS(app)
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload
app.config['JUPYTER_SERVER_URL'] = 'http://localhost:8888'
app.config['JUPYTER_API_TOKEN'] = 'cf787daf5a798c28ec739fd1357638db0cbb5e0a467136e0'  # Set your Jupyter token here

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Utility functions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() == 'ipynb'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/static/<path:path>')
def serve_static(path):
    return send_from_directory('static', path)

@app.route('/api/upload', methods=['POST'])
def upload_notebook():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        try:
            # Parse the notebook
            with open(filepath, 'r', encoding='utf-8') as f:
                notebook_content = json.load(f)
                
            # Return notebook data and a reference ID
            return jsonify({
                'success': True,
                'filename': filename,
                'notebook': notebook_content
            })
        except Exception as e:
            return jsonify({'error': str(e)}), 500
    
    return jsonify({'error': 'File type not allowed'}), 400

@app.route('/api/notebooks/<filename>', methods=['GET'])
def get_notebook(filename):
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(filename))
    
    if not os.path.exists(filepath):
        return jsonify({'error': 'Notebook not found'}), 404
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            notebook_content = json.load(f)
        
        return jsonify({
            'success': True,
            'notebook': notebook_content
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/execute_cell', methods=['POST'])
def execute_cell():
    data = request.json
    if not data or 'code' not in data:
        return jsonify({'error': 'No code provided'}), 400
    
    code = data['code']
    
    # Connect to Jupyter server to execute the code
    headers = {
        'Content-Type': 'application/json',
    }
    
    if app.config['JUPYTER_API_TOKEN']:
        headers['Authorization'] = f"Token {app.config['JUPYTER_API_TOKEN']}"
    
    # Create a new session if session_id is not provided
    session_id = data.get('session_id')
    kernel_id = data.get('kernel_id')
    
    if not session_id or not kernel_id:
        # Start a new kernel session
        response = requests.post(
            f"{app.config['JUPYTER_SERVER_URL']}/api/kernels",
            headers=headers
        )
        
        if response.status_code != 201:
            return jsonify({'error': 'Failed to start kernel'}), 500
        
        kernel_data = response.json()
        kernel_id = kernel_data['id']
    
    # Execute the code
    execution_url = f"{app.config['JUPYTER_SERVER_URL']}/api/kernels/{kernel_id}/execute"
    execution_payload = {
        'code': code,
        'silent': False,
        'store_history': True,
        'user_expressions': {},
        'allow_stdin': False
    }
    
    try:
        response = requests.post(
            execution_url,
            headers=headers,
            json=execution_payload
        )
        
        if response.status_code != 200:
            return jsonify({'error': 'Code execution failed'}), 500
        
        # Get the execution results
        msg_id = response.json()['msg_id']
        
        # Poll for results using the messages endpoint
        messages_url = f"{app.config['JUPYTER_SERVER_URL']}/api/kernels/{kernel_id}/messages"
        
        max_attempts = 30
        attempt = 0
        output_content = {}
        error_content = None
        
        while attempt < max_attempts:
            response = requests.get(messages_url, headers=headers)
            if response.status_code != 200:
                return jsonify({'error': 'Failed to retrieve execution results'}), 500
                
            messages = response.json()
            
            for msg in messages:
                if 'parent_header' in msg and msg['parent_header'].get('msg_id') == msg_id:
                    msg_type = msg.get('msg_type', '')
                    content = msg.get('content', {})
                    
                    if msg_type == 'stream':
                        stream_name = content.get('name', 'stdout')
                        stream_text = content.get('text', '')
                        
                        if 'text/plain' not in output_content:
                            output_content['text/plain'] = ''
                        
                        output_content['text/plain'] += stream_text
                    
                    elif msg_type == 'execute_result':
                        for mime_type, data in content.get('data', {}).items():
                            output_content[mime_type] = data
                    
                    elif msg_type == 'display_data':
                        for mime_type, data in content.get('data', {}).items():
                            output_content[mime_type] = data
                    
                    elif msg_type == 'error':
                        error_content = {
                            'ename': content.get('ename', ''),
                            'evalue': content.get('evalue', ''),
                            'traceback': content.get('traceback', [])
                        }
                    
                    elif msg_type == 'status' and content.get('execution_state') == 'idle':
                        # Execution completed
                        if error_content:
                            return jsonify({
                                'success': False,
                                'kernel_id': kernel_id,
                                'error': error_content
                            })
                        else:
                            return jsonify({
                                'success': True,
                                'kernel_id': kernel_id,
                                'output': output_content
                            })
            
            attempt += 1
            time.sleep(0.1)  # Wait a bit before polling again
        
        # If we've reached this point, we've timed out waiting for results
        return jsonify({
            'success': True,
            'kernel_id': kernel_id,
            'output': output_content if output_content else {'text/plain': 'Execution completed but no output was captured.'}
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
