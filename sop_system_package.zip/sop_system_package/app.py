from flask import Flask, request, jsonify, render_template, redirect, url_for, send_from_directory
import os
import json
import datetime
import logging
from werkzeug.utils import secure_filename
from backend.sop_manager import SopManager
from backend.windows_adapter import WindowsAdapter

# 配置日誌
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='app.log'
)
logger = logging.getLogger('app')

app = Flask(__name__)

# 基礎目錄
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
WINDOWS_ROOT = "D:\\"

# 初始化SOP管理器
sop_manager = SopManager(BASE_DIR, WINDOWS_ROOT)

# 初始化Windows適配器
windows_adapter = WindowsAdapter(BASE_DIR, WINDOWS_ROOT)

# 允許的文件擴展名
ALLOWED_EXTENSIONS = {'md', 'txt', 'ipynb', 'py', 'json', 'doc', 'docx'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# 路由
@app.route('/')
def index():
    """首頁"""
    return render_template('index.html')

@app.route('/sop/list')
def sop_list():
    """SOP列表頁面"""
    # 獲取過濾參數
    fab = request.args.get('fab', '')
    product = request.args.get('product', '')
    
    # 使用SOP管理器列出SOPs
    sops = sop_manager.list_sops(fab if fab else None, product if product else None)
    
    # 提取元數據列表
    metadata_list = [sop.get('metadata', {}) for sop in sops]
    
    return render_template('sop_list.html', sops=metadata_list)

@app.route('/sop/view/<sop_id>')
def sop_view(sop_id):
    """SOP詳情頁面"""
    # 使用SOP管理器獲取SOP
    sop = sop_manager.get_sop(sop_id)
    if not sop:
        return "SOP not found", 404
    
    return render_template('sop_view.html', 
                          metadata=sop.get('metadata', {}), 
                          sop_content=sop.get('content', ''), 
                          notebook_content=sop.get('notebook', {}))

@app.route('/sop/create', methods=['GET', 'POST'])
def sop_create():
    """SOP創建頁面"""
    if request.method == 'GET':
        return render_template('sop_create.html')
    
    # 處理POST請求（創建SOP）
    if request.method == 'POST':
        # 獲取表單數據
        data = request.form
        upload_type = data.get('upload_type', 'file')
        
        # 處理FAB和產品字段
        fab = data.get('fab_custom') if data.get('fab_custom_check') == 'on' else data.get('fab')
        product = data.get('product_custom') if data.get('product_custom_check') == 'on' else data.get('product')
        
        # 創建元數據
        metadata = {
            'title': data.get('title', 'Untitled SOP'),
            'description': data.get('description', ''),
            'author': data.get('author', 'Anonymous'),
            'fab': fab,
            'product': product,
            'status': 'draft'
        }
        
        # 處理文件上傳或內容創建
        if upload_type == 'file':
            # 檢查是否有文件
            if 'file' not in request.files:
                return "No file part", 400
            
            file = request.files['file']
            if file.filename == '':
                return "No selected file", 400
            
            if file and allowed_file(file.filename):
                # 使用SOP管理器創建SOP
                result = sop_manager.create_sop_from_file(file, metadata)
                
                if result.get('success'):
                    return redirect(url_for('sop_view', sop_id=result.get('sop_id')))
                else:
                    return f"Error creating SOP: {result.get('error')}", 400
            else:
                return "File type not allowed", 400
        else:  # 從URL或編輯器創建
            content = data.get('content', '')
            url = data.get('url', '')
            
            if url:
                # 從URL創建SOP
                result = sop_manager.create_sop_from_url(url, metadata)
                
                if result.get('success'):
                    return redirect(url_for('sop_view', sop_id=result.get('sop_id')))
                else:
                    return f"Error creating SOP from URL: {result.get('error')}", 400
            elif content:
                # 使用SOP管理器從內容創建SOP
                result = sop_manager.create_sop_from_content(content, metadata)
                
                if result.get('success'):
                    return redirect(url_for('sop_view', sop_id=result.get('sop_id')))
                else:
                    return f"Error creating SOP: {result.get('error')}", 400
            else:
                return "Content or URL is required", 400

@app.route('/sop/execute/<sop_id>', methods=['GET'])
def sop_execute(sop_id):
    """執行SOP"""
    # 使用SOP管理器執行SOP
    result = sop_manager.execute_sop(sop_id)
    
    if result.get('success'):
        # 重定向到Jupyter頁面
        return render_template('jupyter_view.html', 
                              notebook_url=result.get('notebook_url'),
                              task_id=result.get('task_id'),
                              sop_id=sop_id)
    else:
        return f"Error executing SOP: {result.get('error')}", 400

@app.route('/sop/stop_execution/<task_id>', methods=['POST'])
def stop_execution(task_id):
    """停止SOP執行"""
    # 使用SOP管理器停止SOP執行
    result = sop_manager.stop_sop_execution(task_id)
    
    return jsonify(result)

@app.route('/sop/generate_report/<task_id>/<sop_id>', methods=['POST'])
def generate_report(task_id, sop_id):
    """生成SOP執行報告"""
    # 使用SOP管理器生成報告
    result = sop_manager.generate_report(task_id, sop_id)
    
    if result.get('success'):
        # 重定向到報告頁面
        return redirect(url_for('view_report', report_path=result.get('report_path')))
    else:
        return f"Error generating report: {result.get('error')}", 400

@app.route('/report/<path:report_path>')
def view_report(report_path):
    """查看報告"""
    # 獲取報告目錄
    report_dir = os.path.dirname(os.path.join(BASE_DIR, report_path))
    report_filename = os.path.basename(report_path)
    
    return send_from_directory(report_dir, report_filename)

@app.route('/api/sop/validate', methods=['POST'])
def validate_sop():
    """驗證SOP格式和內容"""
    if 'file' not in request.files:
        return jsonify({'valid': False, 'errors': ['No file provided']}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'valid': False, 'errors': ['Empty filename']}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'valid': False, 'errors': [f'File type not allowed. Allowed types: {", ".join(ALLOWED_EXTENSIONS)}']}), 400
    
    # 讀取文件內容進行驗證
    content = file.read().decode('utf-8')
    file.seek(0)  # 重置文件指針以便後續處理
    
    # 簡單驗證邏輯
    errors = []
    warnings = []
    
    if len(content) < 10:
        errors.append('Content too short')
    
    if '```' not in content and file.filename.endswith('.md'):
        warnings.append('No code blocks found in markdown')
    
    # 返回驗證結果
    valid = len(errors) == 0
    return jsonify({
        'valid': valid,
        'errors': errors,
        'warnings': warnings
    })

@app.route('/api/sop/search', methods=['GET'])
def search_sops():
    """搜索SOP"""
    query = request.args.get('q', '')
    fab = request.args.get('fab', '')
    product = request.args.get('product', '')
    
    # 使用SOP管理器搜索SOPs
    results = sop_manager.search_sops(query, fab if fab else None, product if product else None)
    
    # 提取元數據列表
    metadata_list = [sop.get('metadata', {}) for sop in results]
    
    return jsonify(metadata_list)

@app.route('/api/sop/update/<sop_id>', methods=['POST'])
def update_sop(sop_id):
    """更新SOP內容並創建新版本"""
    # 獲取更新數據
    data = {}
    if 'title' in request.form:
        data['title'] = request.form.get('title')
    
    if 'description' in request.form:
        data['description'] = request.form.get('description')
    
    if 'author' in request.form:
        data['author'] = request.form.get('author')
    
    if 'status' in request.form:
        data['status'] = request.form.get('status')
    
    # 處理更新內容
    if 'file' in request.files:
        file = request.files['file']
        if file.filename != '' and allowed_file(file.filename):
            # 使用SOP管理器更新SOP
            result = sop_manager.update_sop(sop_id, file=file, metadata=data)
            
            if result.get('success'):
                return jsonify({
                    'success': True,
                    'sop_id': sop_id,
                    'version': result.get('version')
                })
            else:
                return jsonify({'error': result.get('error')}), 400
        else:
            return jsonify({'error': 'Invalid file'}), 400
    elif 'content' in request.form:
        content = request.form.get('content')
        
        # 使用SOP管理器更新SOP
        result = sop_manager.update_sop(sop_id, content=content, metadata=data)
        
        if result.get('success'):
            return jsonify({
                'success': True,
                'sop_id': sop_id,
                'version': result.get('version')
            })
        else:
            return jsonify({'error': result.get('error')}), 400
    elif data:
        # 只更新元數據
        result = sop_manager.update_sop(sop_id, metadata=data)
        
        if result.get('success'):
            return jsonify({
                'success': True,
                'sop_id': sop_id,
                'version': result.get('version')
            })
        else:
            return jsonify({'error': result.get('error')}), 400
    else:
        return jsonify({'error': 'No content or metadata provided'}), 400

@app.route('/api/sop/delete/<sop_id>', methods=['DELETE'])
def delete_sop(sop_id):
    """刪除SOP"""
    # 使用SOP管理器刪除SOP
    result = sop_manager.delete_sop(sop_id)
    
    if result:
        return jsonify({'success': True})
    else:
        return jsonify({'error': 'SOP not found or could not be deleted'}), 404

@app.route('/api/fabs', methods=['GET'])
def get_fabs():
    """獲取所有FAB"""
    return jsonify(["FAB12", "FAB14", "FAB15", "FAB18", "ENT", "FOC"])

@app.route('/api/products', methods=['GET'])
def get_products():
    """獲取所有產品"""
    return jsonify(["ELFM", "EMP", "OWMS", "MPCS"])

@app.route('/static/<path:path>')
def serve_static(path):
    """提供靜態文件"""
    return send_from_directory('static', path)

if __name__ == '__main__':
    # 創建Windows目錄結構
    windows_adapter.create_windows_structure()
    
    # 啟動應用
    app.run(host='0.0.0.0', port=5000, debug=True)
