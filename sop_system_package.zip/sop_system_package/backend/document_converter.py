import os
import requests
import logging
import json
import uuid
import datetime
from bs4 import BeautifulSoup
import markdown
import docx
from urllib.parse import urlparse

# 配置日誌
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='document_converter.log'
)
logger = logging.getLogger('document_converter')

class DocumentConverter:
    """文檔轉換器，支持Word到Markdown的轉換和URL內容提取"""
    
    def __init__(self):
        """初始化文檔轉換器"""
        logger.info("初始化文檔轉換器")
    
    def word_to_markdown(self, file_path):
        """將Word文檔轉換為Markdown
        
        Args:
            file_path: Word文檔路徑
            
        Returns:
            Markdown格式的內容
        """
        try:
            # 打開Word文檔
            doc = docx.Document(file_path)
            
            # 提取文本
            markdown_content = []
            
            # 處理段落
            for para in doc.paragraphs:
                # 檢查段落樣式
                if para.style.name.startswith('Heading 1'):
                    markdown_content.append(f"# {para.text}")
                elif para.style.name.startswith('Heading 2'):
                    markdown_content.append(f"## {para.text}")
                elif para.style.name.startswith('Heading 3'):
                    markdown_content.append(f"### {para.text}")
                elif para.style.name.startswith('Heading 4'):
                    markdown_content.append(f"#### {para.text}")
                elif para.style.name.startswith('Heading 5'):
                    markdown_content.append(f"##### {para.text}")
                elif para.style.name.startswith('Heading 6'):
                    markdown_content.append(f"###### {para.text}")
                elif para.style.name.startswith('List Bullet'):
                    markdown_content.append(f"* {para.text}")
                elif para.style.name.startswith('List Number'):
                    markdown_content.append(f"1. {para.text}")
                else:
                    # 處理文本格式
                    text = para.text
                    
                    # 檢查是否有粗體、斜體等格式
                    for run in para.runs:
                        if run.bold:
                            text = text.replace(run.text, f"**{run.text}**")
                        if run.italic:
                            text = text.replace(run.text, f"*{run.text}*")
                        if run.underline:
                            text = text.replace(run.text, f"__{run.text}__")
                    
                    markdown_content.append(text)
            
            # 處理表格
            for table in doc.tables:
                # 表格頭部
                markdown_content.append("|" + "|".join([cell.text for cell in table.rows[0].cells]) + "|")
                markdown_content.append("|" + "|".join(["---" for _ in table.rows[0].cells]) + "|")
                
                # 表格內容
                for row in table.rows[1:]:
                    markdown_content.append("|" + "|".join([cell.text for cell in row.cells]) + "|")
            
            # 合併所有內容
            result = "\n\n".join(markdown_content)
            
            logger.info(f"Word文檔已轉換為Markdown: {file_path}")
            return result
            
        except Exception as e:
            logger.error(f"Word到Markdown轉換失敗: {file_path}, 錯誤: {str(e)}")
            raise
    
    def extract_from_url(self, url):
        """從URL提取內容並轉換為Markdown
        
        Args:
            url: 網頁URL
            
        Returns:
            Markdown格式的內容
        """
        try:
            # 發送請求
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
            response = requests.get(url, headers=headers, timeout=30)
            response.raise_for_status()
            
            # 解析HTML
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 提取標題
            title = soup.title.string if soup.title else "無標題"
            
            # 提取主要內容
            main_content = self._extract_main_content(soup)
            
            # 轉換為Markdown
            markdown_content = self.html_to_markdown(main_content)
            
            # 添加標題和來源
            result = f"# {title}\n\n來源: {url}\n\n{markdown_content}"
            
            logger.info(f"URL內容已提取並轉換為Markdown: {url}")
            return result
            
        except Exception as e:
            logger.error(f"URL內容提取失敗: {url}, 錯誤: {str(e)}")
            raise
    
    def _extract_main_content(self, soup):
        """提取網頁的主要內容
        
        Args:
            soup: BeautifulSoup對象
            
        Returns:
            HTML格式的主要內容
        """
        # 嘗試找到主要內容區域
        main_tags = ['article', 'main', 'div[role="main"]', '.main-content', '#content', '#main']
        
        for tag in main_tags:
            main_content = soup.select(tag)
            if main_content:
                return str(main_content[0])
        
        # 如果找不到主要內容區域，返回body
        return str(soup.body)
    
    def html_to_markdown(self, html_content):
        """將HTML內容轉換為Markdown
        
        Args:
            html_content: HTML格式的內容
            
        Returns:
            Markdown格式的內容
        """
        try:
            # 解析HTML
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # 提取文本
            markdown_content = []
            
            # 處理標題
            for i in range(1, 7):
                for heading in soup.find_all(f'h{i}'):
                    markdown_content.append(f"{'#' * i} {heading.get_text().strip()}")
            
            # 處理段落
            for para in soup.find_all('p'):
                markdown_content.append(para.get_text().strip())
            
            # 處理列表
            for ul in soup.find_all('ul'):
                for li in ul.find_all('li'):
                    markdown_content.append(f"* {li.get_text().strip()}")
            
            for ol in soup.find_all('ol'):
                for i, li in enumerate(ol.find_all('li')):
                    markdown_content.append(f"{i+1}. {li.get_text().strip()}")
            
            # 處理表格
            for table in soup.find_all('table'):
                # 表格頭部
                headers = []
                for th in table.find_all('th'):
                    headers.append(th.get_text().strip())
                
                if headers:
                    markdown_content.append("|" + "|".join(headers) + "|")
                    markdown_content.append("|" + "|".join(["---" for _ in headers]) + "|")
                
                # 表格內容
                for tr in table.find_all('tr'):
                    cells = []
                    for td in tr.find_all('td'):
                        cells.append(td.get_text().strip())
                    
                    if cells:
                        markdown_content.append("|" + "|".join(cells) + "|")
            
            # 處理代碼塊
            for pre in soup.find_all('pre'):
                code = pre.get_text().strip()
                markdown_content.append(f"```\n{code}\n```")
            
            # 處理引用
            for blockquote in soup.find_all('blockquote'):
                quote = blockquote.get_text().strip()
                markdown_content.append(f"> {quote}")
            
            # 合併所有內容
            result = "\n\n".join(markdown_content)
            
            logger.info("HTML已轉換為Markdown")
            return result
            
        except Exception as e:
            logger.error(f"HTML到Markdown轉換失敗: {str(e)}")
            raise
    
    def save_as_markdown(self, content, output_path):
        """將內容保存為Markdown文件
        
        Args:
            content: Markdown格式的內容
            output_path: 輸出文件路徑
            
        Returns:
            布爾值，表示操作是否成功
        """
        try:
            # 確保目錄存在
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            
            # 保存文件
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            logger.info(f"Markdown已保存到: {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"保存Markdown失敗: {output_path}, 錯誤: {str(e)}")
            return False
    
    def markdown_to_html(self, markdown_content):
        """將Markdown內容轉換為HTML
        
        Args:
            markdown_content: Markdown格式的內容
            
        Returns:
            HTML格式的內容
        """
        try:
            # 使用markdown庫轉換
            html = markdown.markdown(markdown_content, extensions=['tables', 'fenced_code'])
            
            logger.info("Markdown已轉換為HTML")
            return html
            
        except Exception as e:
            logger.error(f"Markdown到HTML轉換失敗: {str(e)}")
            raise
