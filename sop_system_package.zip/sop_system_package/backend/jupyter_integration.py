import os
import json
import time
import uuid
import subprocess
import threading
import logging
import nbformat
from nbformat.v4 import new_notebook, new_markdown_cell, new_code_cell
import requests
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import base64
from PIL import Image
from io import BytesIO

# 配置日誌
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='jupyter_integration.log'
)
logger = logging.getLogger('jupyter_integration')

class JupyterIntegration:
    """與Jupyter Notebook整合的類，提供啟動、控制和截圖功能"""
    
    def __init__(self, base_dir, jupyter_port=8889, jupyter_token="01c8ba4ec1944166d33d1819c011bb037bcae4e41c86023b"):
        """初始化Jupyter整合
        
        Args:
            base_dir: 基礎目錄
            jupyter_port: Jupyter服務器端口
            jupyter_token: Jupyter訪問令牌
        """
        self.base_dir = base_dir
        self.jupyter_port = jupyter_port
        self.jupyter_token = jupyter_token
        self.jupyter_url = f"http://127.0.0.1:{jupyter_port}/?token={jupyter_token}"
        
        # 截圖相關設置
        self.screenshots_dir = os.path.join(base_dir, 'screenshots')
        os.makedirs(self.screenshots_dir, exist_ok=True)
        
        # 報告相關設置
        self.reports_dir = os.path.join(base_dir, 'reports')
        os.makedirs(self.reports_dir, exist_ok=True)
        
        # 記錄當前運行的截圖任務
        self.screenshot_tasks = {}
        
        logger.info(f"初始化Jupyter整合，基礎目錄: {base_dir}, Jupyter端口: {jupyter_port}")
    
    def is_jupyter_running(self):
        """檢查Jupyter服務器是否正在運行
        
        Returns:
            布爾值，表示Jupyter是否運行
        """
        try:
            response = requests.get(f"http://127.0.0.1:{self.jupyter_port}/api/status", 
                                   params={"token": self.jupyter_token},
                                   timeout=5)
            return response.status_code == 200
        except:
            return False
    
    def start_jupyter_server(self, notebook_dir=None):
        """啟動Jupyter服務器
        
        Args:
            notebook_dir: Jupyter筆記本目錄，默認為None（使用當前目錄）
            
        Returns:
            布爾值，表示是否成功啟動
        """
        if self.is_jupyter_running():
            logger.info("Jupyter服務器已經在運行")
            return True
        
        if notebook_dir is None:
            notebook_dir = os.path.join(self.base_dir, 'notebooks')
            os.makedirs(notebook_dir, exist_ok=True)
        
        # Windows環境下的啟動命令
        cmd = [
            "jupyter", "notebook",
            f"--NotebookApp.token={self.jupyter_token}",
            f"--port={self.jupyter_port}",
            f"--notebook-dir={notebook_dir}",
            "--no-browser"
        ]
        
        try:
            # 使用subprocess啟動Jupyter
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                shell=True  # Windows環境下需要shell=True
            )
            
            # 等待Jupyter啟動
            for _ in range(10):
                if self.is_jupyter_running():
                    logger.info(f"Jupyter服務器已啟動，URL: {self.jupyter_url}")
                    return True
                time.sleep(1)
            
            logger.error("Jupyter服務器啟動超時")
            return False
        except Exception as e:
            logger.error(f"啟動Jupyter服務器時出錯: {str(e)}")
            return False
    
    def generate_notebook_from_markdown(self, markdown_content, metadata=None):
        """從Markdown內容生成Jupyter Notebook
        
        Args:
            markdown_content: Markdown格式的內容
            metadata: 筆記本元數據
            
        Returns:
            生成的筆記本對象
        """
        # 創建新筆記本
        notebook = new_notebook()
        
        # 添加元數據
        if metadata:
            notebook.metadata.update(metadata)
        
        # 分割Markdown內容
        sections = markdown_content.split('## ')
        
        # 處理第一部分（可能包含標題）
        if sections[0].startswith('# '):
            # 提取主標題
            title_lines = sections[0].split('\n', 1)
            title = title_lines[0].strip('# ')
            rest = title_lines[1] if len(title_lines) > 1 else ""
            
            # 添加標題單元格
            notebook.cells.append(new_markdown_cell(f"# {title}"))
            
            # 添加剩餘內容
            if rest.strip():
                notebook.cells.append(new_markdown_cell(rest.strip()))
        else:
            # 沒有主標題，直接添加內容
            if sections[0].strip():
                notebook.cells.append(new_markdown_cell(sections[0].strip()))
        
        # 處理其餘部分
        for section in sections[1:]:
            if not section.strip():
                continue
            
            # 分割標題和內容
            lines = section.split('\n', 1)
            section_title = lines[0].strip()
            section_content = lines[1].strip() if len(lines) > 1 else ""
            
            # 添加標題單元格
            notebook.cells.append(new_markdown_cell(f"## {section_title}"))
            
            # 處理內容
            if section_content:
                # 分割代碼塊和文本
                parts = section_content.split('```')
                
                # 第一部分是文本
                if parts[0].strip():
                    notebook.cells.append(new_markdown_cell(parts[0].strip()))
                
                # 處理代碼塊
                for i in range(1, len(parts), 2):
                    code_part = parts[i].strip()
                    
                    # 檢查代碼類型
                    if code_part.startswith('python') or code_part.startswith('py'):
                        # 提取Python代碼
                        code = code_part.split('\n', 1)[1] if '\n' in code_part else ""
                        notebook.cells.append(new_code_cell(code))
                    elif code_part.startswith('sql'):
                        # SQL代碼轉換為Python代碼
                        sql_code = code_part.split('\n', 1)[1] if '\n' in code_part else ""
                        python_code = f'# 執行SQL查詢\nimport pandas as pd\n\n# 連接數據庫\n# conn = create_connection()\n\n# 執行查詢\nsql = """\n{sql_code}\n"""\n# result = pd.read_sql(sql, conn)\n# result'
                        notebook.cells.append(new_code_cell(python_code))
                    elif code_part.startswith('bash') or code_part.startswith('sh'):
                        # Bash代碼轉換為Python代碼
                        bash_code = code_part.split('\n', 1)[1] if '\n' in code_part else ""
                        python_code = f'# 執行Shell命令\nimport subprocess\n\n# 命令\ncmd = """\n{bash_code}\n"""\n\n# 執行\n# !{bash_code.replace(chr(10), chr(10)+"# !")}'
                        notebook.cells.append(new_code_cell(python_code))
                    else:
                        # 其他代碼類型，保留為Markdown
                        notebook.cells.append(new_markdown_cell(f"```{code_part}```"))
                    
                    # 添加後續文本（如果有）
                    if i + 1 < len(parts) and parts[i + 1].strip():
                        notebook.cells.append(new_markdown_cell(parts[i + 1].strip()))
        
        return notebook
    
    def save_notebook(self, notebook, filepath):
        """保存Jupyter Notebook到文件
        
        Args:
            notebook: 筆記本對象
            filepath: 保存路徑
            
        Returns:
            布爾值，表示是否成功保存
        """
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                nbformat.write(notebook, f)
            logger.info(f"筆記本已保存到: {filepath}")
            return True
        except Exception as e:
            logger.error(f"保存筆記本時出錯: {str(e)}")
            return False
    
    def open_notebook_in_jupyter(self, notebook_path):
        """在Jupyter中打開筆記本
        
        Args:
            notebook_path: 筆記本文件路徑
            
        Returns:
            筆記本URL
        """
        # 確保Jupyter服務器正在運行
        if not self.is_jupyter_running():
            self.start_jupyter_server()
        
        # 獲取相對路徑
        if os.path.isabs(notebook_path):
            notebook_dir = os.path.join(self.base_dir, 'notebooks')
            rel_path = os.path.relpath(notebook_path, notebook_dir)
        else:
            rel_path = notebook_path
        
        # 構建URL
        notebook_url = f"{self.jupyter_url}&path={rel_path}"
        logger.info(f"筆記本URL: {notebook_url}")
        
        return notebook_url
    
    def start_screenshot_service(self, notebook_path, interval=5):
        """啟動截圖服務
        
        Args:
            notebook_path: 筆記本文件路徑
            interval: 截圖間隔（秒）
            
        Returns:
            任務ID
        """
        # 生成任務ID
        task_id = str(uuid.uuid4())
        
        # 創建截圖目錄
        task_screenshots_dir = os.path.join(self.screenshots_dir, task_id)
        os.makedirs(task_screenshots_dir, exist_ok=True)
        
        # 獲取筆記本URL
        notebook_url = self.open_notebook_in_jupyter(notebook_path)
        
        # 啟動截圖線程
        thread = threading.Thread(
            target=self._screenshot_thread,
            args=(task_id, notebook_url, task_screenshots_dir, interval)
        )
        thread.daemon = True
        thread.start()
        
        # 記錄任務信息
        self.screenshot_tasks[task_id] = {
            'thread': thread,
            'notebook_path': notebook_path,
            'notebook_url': notebook_url,
            'screenshots_dir': task_screenshots_dir,
            'start_time': datetime.now(),
            'status': 'running'
        }
        
        logger.info(f"截圖服務已啟動，任務ID: {task_id}")
        return task_id
    
    def _screenshot_thread(self, task_id, url, screenshots_dir, interval):
        """截圖線程
        
        Args:
            task_id: 任務ID
            url: 要截圖的URL
            screenshots_dir: 截圖保存目錄
            interval: 截圖間隔（秒）
        """
        try:
            # 配置Chrome選項
            chrome_options = Options()
            chrome_options.add_argument("--headless")
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_argument("--window-size=1920,1080")
            
            # 初始化WebDriver
            driver = webdriver.Chrome(options=chrome_options)
            
            # 訪問URL
            driver.get(url)
            
            # 等待頁面加載
            WebDriverWait(driver, 30).until(
                EC.presence_of_element_located((By.ID, "notebook-container"))
            )
            
            # 截圖計數
            count = 0
            
            # 循環截圖
            while task_id in self.screenshot_tasks and self.screenshot_tasks[task_id]['status'] == 'running':
                # 截圖
                screenshot = driver.get_screenshot_as_png()
                
                # 保存截圖
                screenshot_path = os.path.join(screenshots_dir, f"screenshot_{count:04d}.png")
                with open(screenshot_path, 'wb') as f:
                    f.write(screenshot)
                
                logger.info(f"已保存截圖: {screenshot_path}")
                
                # 增加計數
                count += 1
                
                # 等待下一次截圖
                time.sleep(interval)
            
            # 關閉WebDriver
            driver.quit()
            
            logger.info(f"截圖線程已結束，任務ID: {task_id}")
            
        except Exception as e:
            logger.error(f"截圖線程出錯，任務ID: {task_id}, 錯誤: {str(e)}")
            
            # 更新任務狀態
            if task_id in self.screenshot_tasks:
                self.screenshot_tasks[task_id]['status'] = 'error'
                self.screenshot_tasks[task_id]['error'] = str(e)
    
    def stop_screenshot_service(self, task_id):
        """停止截圖服務
        
        Args:
            task_id: 任務ID
            
        Returns:
            布爾值，表示是否成功停止
        """
        if task_id not in self.screenshot_tasks:
            logger.warning(f"找不到截圖任務: {task_id}")
            return False
        
        # 更新任務狀態
        self.screenshot_tasks[task_id]['status'] = 'stopping'
        
        # 等待線程結束
        self.screenshot_tasks[task_id]['thread'].join(timeout=10)
        
        # 更新任務狀態
        self.screenshot_tasks[task_id]['status'] = 'stopped'
        self.screenshot_tasks[task_id]['end_time'] = datetime.now()
        
        logger.info(f"截圖服務已停止，任務ID: {task_id}")
        return True
    
    def generate_report(self, task_id, sop_name=None):
        """生成執行報告
        
        Args:
            task_id: 任務ID
            sop_name: SOP名稱，默認為None
            
        Returns:
            報告文件路徑
        """
        if task_id not in self.screenshot_tasks:
            logger.warning(f"找不到截圖任務: {task_id}")
            return None
        
        # 獲取任務信息
        task_info = self.screenshot_tasks[task_id]
        screenshots_dir = task_info['screenshots_dir']
        notebook_path = task_info['notebook_path']
        
        # 獲取SOP名稱
        if sop_name is None:
            sop_name = os.path.basename(notebook_path).split('.')[0]
        
        # 生成報告文件名
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
        report_filename = f"{sop_name}_{timestamp}.html"
        report_path = os.path.join(self.reports_dir, report_filename)
        
        # 獲取截圖列表
        screenshots = sorted([f for f in os.listdir(screenshots_dir) if f.endswith('.png')])
        
        # 生成HTML報告
        html_content = f"""
        <!DOCTYPE html>
        <html lang="zh-TW">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>SOP執行報告 - {sop_name}</title>
            <style>
                body {{
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    margin: 0;
                    padding: 20px;
                    color: #333;
                }}
                .container {{
                    max-width: 1200px;
                    margin: 0 auto;
                }}
                header {{
                    background-color: #f8f9fa;
                    padding: 20px;
                    margin-bottom: 30px;
                    border-radius: 5px;
                    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
                }}
                h1 {{
                    color: #0056b3;
                    margin-top: 0;
                }}
                .report-info {{
                    display: flex;
                    flex-wrap: wrap;
                    margin-bottom: 20px;
                }}
                .info-item {{
                    flex: 1;
                    min-width: 200px;
                    margin-bottom: 10px;
                }}
                .info-label {{
                    font-weight: bold;
                    color: #555;
                }}
                .screenshots {{
                    display: flex;
                    flex-direction: column;
                    gap: 30px;
                }}
                .screenshot-item {{
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    overflow: hidden;
                    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
                }}
                .screenshot-header {{
                    background-color: #f8f9fa;
                    padding: 10px 15px;
                    border-bottom: 1px solid #ddd;
                }}
                .screenshot-image {{
                    width: 100%;
                    height: auto;
                }}
                footer {{
                    margin-top: 50px;
                    text-align: center;
                    color: #777;
                    font-size: 0.9em;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <header>
                    <h1>SOP執行報告</h1>
                    <div class="report-info">
                        <div class="info-item">
                            <div class="info-label">SOP名稱:</div>
                            <div>{sop_name}</div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">執行開始時間:</div>
                            <div>{task_info['start_time'].strftime('%Y-%m-%d %H:%M:%S')}</div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">執行結束時間:</div>
                            <div>{task_info.get('end_time', datetime.now()).strftime('%Y-%m-%d %H:%M:%S')}</div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">筆記本:</div>
                            <div>{os.path.basename(notebook_path)}</div>
                        </div>
                    </div>
                </header>
                
                <h2>執行過程截圖</h2>
                <div class="screenshots">
        """
        
        # 添加截圖
        for i, screenshot in enumerate(screenshots):
            screenshot_path = os.path.join(screenshots_dir, screenshot)
            
            # 讀取圖片並轉換為base64
            with open(screenshot_path, 'rb') as img_file:
                img_data = base64.b64encode(img_file.read()).decode('utf-8')
            
            html_content += f"""
                    <div class="screenshot-item">
                        <div class="screenshot-header">步驟 {i+1}</div>
                        <img src="data:image/png;base64,{img_data}" class="screenshot-image" alt="步驟 {i+1} 截圖">
                    </div>
            """
        
        # 完成HTML
        html_content += """
                </div>
                
                <footer>
                    <p>此報告由SOP執行系統自動生成</p>
                </footer>
            </div>
        </body>
        </html>
        """
        
        # 保存HTML報告
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        logger.info(f"報告已生成: {report_path}")
        return report_path
    
    def get_task_status(self, task_id):
        """獲取任務狀態
        
        Args:
            task_id: 任務ID
            
        Returns:
            任務狀態信息
        """
        if task_id not in self.screenshot_tasks:
            return {'status': 'not_found'}
        
        return {
            'status': self.screenshot_tasks[task_id]['status'],
            'start_time': self.screenshot_tasks[task_id]['start_time'].isoformat(),
            'end_time': self.screenshot_tasks[task_id].get('end_time', '').isoformat() if 'end_time' in self.screenshot_tasks[task_id] else None,
            'notebook_path': self.screenshot_tasks[task_id]['notebook_path'],
            'notebook_url': self.screenshot_tasks[task_id]['notebook_url'],
            'screenshots_dir': self.screenshot_tasks[task_id]['screenshots_dir'],
            'error': self.screenshot_tasks[task_id].get('error')
        }
