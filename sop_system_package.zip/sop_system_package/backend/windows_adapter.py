import os
import platform
import shutil
import logging
import re
from pathlib import Path, PureWindowsPath

# 配置日誌
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='windows_adapter.log'
)
logger = logging.getLogger('windows_adapter')

class WindowsAdapter:
    """Windows環境適配器，處理路徑轉換和文件系統操作"""
    
    def __init__(self, base_dir=None, windows_root="D:\\"):
        """初始化Windows適配器
        
        Args:
            base_dir: 基礎目錄（Linux環境下）
            windows_root: Windows環境下的根目錄
        """
        self.base_dir = base_dir
        self.windows_root = windows_root
        self.is_windows = platform.system() == "Windows"
        
        logger.info(f"初始化Windows適配器，基礎目錄: {base_dir}, Windows根目錄: {windows_root}")
        logger.info(f"當前運行環境: {'Windows' if self.is_windows else 'Non-Windows'}")
    
    def to_windows_path(self, path):
        """將路徑轉換為Windows格式
        
        Args:
            path: 原始路徑
            
        Returns:
            Windows格式的路徑
        """
        if self.is_windows:
            return path
        
        # 處理絕對路徑
        if os.path.isabs(path):
            # 如果路徑以base_dir開頭，則轉換為Windows路徑
            if self.base_dir and path.startswith(self.base_dir):
                rel_path = os.path.relpath(path, self.base_dir)
                win_path = os.path.join(self.windows_root, rel_path)
                # 將正斜杠轉換為反斜杠
                win_path = win_path.replace('/', '\\')
                return win_path
            else:
                # 其他絕對路徑，直接轉換為Windows格式
                win_path = PureWindowsPath(path)
                return str(win_path)
        else:
            # 相對路徑，只需轉換斜杠
            return path.replace('/', '\\')
    
    def to_unix_path(self, path):
        """將Windows路徑轉換為Unix格式
        
        Args:
            path: Windows路徑
            
        Returns:
            Unix格式的路徑
        """
        if not self.is_windows:
            return path
        
        # 處理Windows絕對路徑
        if re.match(r'^[A-Za-z]:\\', path):
            # 如果路徑以windows_root開頭，則轉換為相對於base_dir的路徑
            if path.startswith(self.windows_root):
                rel_path = path[len(self.windows_root):]
                unix_path = os.path.join(self.base_dir, rel_path)
                # 將反斜杠轉換為正斜杠
                unix_path = unix_path.replace('\\', '/')
                return unix_path
            else:
                # 其他Windows絕對路徑，轉換為Unix格式
                unix_path = path.replace('\\', '/')
                return unix_path
        else:
            # 相對路徑，只需轉換斜杠
            return path.replace('\\', '/')
    
    def ensure_dir_exists(self, path):
        """確保目錄存在，如果不存在則創建
        
        Args:
            path: 目錄路徑
            
        Returns:
            布爾值，表示操作是否成功
        """
        try:
            if not os.path.exists(path):
                os.makedirs(path, exist_ok=True)
                logger.info(f"創建目錄: {path}")
            return True
        except Exception as e:
            logger.error(f"創建目錄失敗: {path}, 錯誤: {str(e)}")
            return False
    
    def copy_file(self, src, dst):
        """複製文件
        
        Args:
            src: 源文件路徑
            dst: 目標文件路徑
            
        Returns:
            布爾值，表示操作是否成功
        """
        try:
            # 確保目標目錄存在
            dst_dir = os.path.dirname(dst)
            self.ensure_dir_exists(dst_dir)
            
            # 複製文件
            shutil.copy2(src, dst)
            logger.info(f"複製文件: {src} -> {dst}")
            return True
        except Exception as e:
            logger.error(f"複製文件失敗: {src} -> {dst}, 錯誤: {str(e)}")
            return False
    
    def move_file(self, src, dst):
        """移動文件
        
        Args:
            src: 源文件路徑
            dst: 目標文件路徑
            
        Returns:
            布爾值，表示操作是否成功
        """
        try:
            # 確保目標目錄存在
            dst_dir = os.path.dirname(dst)
            self.ensure_dir_exists(dst_dir)
            
            # 移動文件
            shutil.move(src, dst)
            logger.info(f"移動文件: {src} -> {dst}")
            return True
        except Exception as e:
            logger.error(f"移動文件失敗: {src} -> {dst}, 錯誤: {str(e)}")
            return False
    
    def delete_file(self, path):
        """刪除文件
        
        Args:
            path: 文件路徑
            
        Returns:
            布爾值，表示操作是否成功
        """
        try:
            if os.path.exists(path):
                os.remove(path)
                logger.info(f"刪除文件: {path}")
                return True
            else:
                logger.warning(f"文件不存在，無法刪除: {path}")
                return False
        except Exception as e:
            logger.error(f"刪除文件失敗: {path}, 錯誤: {str(e)}")
            return False
    
    def list_files(self, directory, pattern=None):
        """列出目錄中的文件
        
        Args:
            directory: 目錄路徑
            pattern: 文件名模式（正則表達式）
            
        Returns:
            文件列表
        """
        try:
            if not os.path.exists(directory):
                logger.warning(f"目錄不存在: {directory}")
                return []
            
            files = os.listdir(directory)
            
            # 過濾文件
            if pattern:
                files = [f for f in files if re.match(pattern, f)]
            
            # 構建完整路徑
            files = [os.path.join(directory, f) for f in files]
            
            # 只返回文件（不包括目錄）
            files = [f for f in files if os.path.isfile(f)]
            
            return files
        except Exception as e:
            logger.error(f"列出文件失敗: {directory}, 錯誤: {str(e)}")
            return []
    
    def get_file_info(self, path):
        """獲取文件信息
        
        Args:
            path: 文件路徑
            
        Returns:
            文件信息字典
        """
        try:
            if not os.path.exists(path):
                logger.warning(f"文件不存在: {path}")
                return None
            
            stat = os.stat(path)
            
            return {
                'path': path,
                'size': stat.st_size,
                'created': stat.st_ctime,
                'modified': stat.st_mtime,
                'accessed': stat.st_atime,
                'filename': os.path.basename(path),
                'extension': os.path.splitext(path)[1][1:],
                'is_file': os.path.isfile(path),
                'is_dir': os.path.isdir(path)
            }
        except Exception as e:
            logger.error(f"獲取文件信息失敗: {path}, 錯誤: {str(e)}")
            return None
    
    def create_windows_structure(self, fab_list=None, product_list=None):
        """創建Windows環境下的目錄結構
        
        Args:
            fab_list: FAB列表
            product_list: 產品列表
            
        Returns:
            布爾值，表示操作是否成功
        """
        if fab_list is None:
            fab_list = ["FAB12", "FAB14", "FAB15", "FAB18", "ENT", "FOC"]
        
        if product_list is None:
            product_list = ["ELFM", "EMP", "OWMS", "MPCS"]
        
        try:
            # 在Windows環境下創建目錄結構
            if self.is_windows:
                # 創建FAB目錄
                for fab in fab_list:
                    fab_dir = os.path.join(self.windows_root, fab)
                    self.ensure_dir_exists(fab_dir)
                    
                    # 創建產品目錄
                    for product in product_list:
                        product_dir = os.path.join(fab_dir, product)
                        self.ensure_dir_exists(product_dir)
                
                logger.info(f"Windows目錄結構已創建")
                return True
            else:
                # 在非Windows環境下，創建模擬的目錄結構
                windows_root = os.path.join(self.base_dir, "windows_structure")
                self.ensure_dir_exists(windows_root)
                
                # 創建FAB目錄
                for fab in fab_list:
                    fab_dir = os.path.join(windows_root, fab)
                    self.ensure_dir_exists(fab_dir)
                    
                    # 創建產品目錄
                    for product in product_list:
                        product_dir = os.path.join(fab_dir, product)
                        self.ensure_dir_exists(product_dir)
                
                logger.info(f"模擬的Windows目錄結構已創建: {windows_root}")
                return True
        except Exception as e:
            logger.error(f"創建Windows目錄結構失敗: {str(e)}")
            return False
