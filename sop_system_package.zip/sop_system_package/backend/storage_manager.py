import os
import json
import datetime
import uuid
import logging
from .windows_adapter import WindowsAdapter

# 配置日誌
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='storage_manager.log'
)
logger = logging.getLogger('storage_manager')

class StorageManager:
    """管理SOP文件的存儲和組織"""
    
    def __init__(self, base_dir, windows_root="D:\\"):
        """初始化存儲管理器
        
        Args:
            base_dir: 基礎存儲目錄
            windows_root: Windows環境下的根目錄
        """
        self.base_dir = base_dir
        self.windows_adapter = WindowsAdapter(base_dir, windows_root)
        
        # 確保目錄存在
        os.makedirs(base_dir, exist_ok=True)
        
        logger.info(f"初始化存儲管理器，基礎目錄: {base_dir}, Windows根目錄: {windows_root}")
    
    def get_storage_path(self, fab, product):
        """獲取特定FAB和產品的存儲路徑
        
        Args:
            fab: FAB名稱
            product: 產品名稱
            
        Returns:
            存儲路徑
        """
        # 在Windows環境下的路徑
        windows_path = os.path.join(self.windows_adapter.windows_root, fab, product)
        
        # 轉換為當前環境的路徑
        path = self.windows_adapter.to_unix_path(windows_path)
        
        # 確保目錄存在
        os.makedirs(path, exist_ok=True)
        
        logger.info(f"獲取存儲路徑: {path} (Windows: {windows_path})")
        return path
    
    def generate_filename(self, fab, product, sop_name, extension):
        """生成符合命名規則的文件名
        
        Args:
            fab: FAB名稱
            product: 產品名稱
            sop_name: SOP名稱
            extension: 文件擴展名
            
        Returns:
            生成的文件名
        """
        # 清理SOP名稱，替換空格和特殊字符
        clean_name = sop_name.replace(' ', '_').replace('-', '_')
        clean_name = ''.join(c for c in clean_name if c.isalnum() or c == '_')
        
        # 生成時間戳
        timestamp = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        
        # 構建文件名
        filename = f"{fab}_{product}_{clean_name}_{timestamp}.{extension}"
        
        logger.info(f"生成文件名: {filename}")
        return filename
    
    def save_file(self, content, fab, product, sop_name, extension=None, original_filename=None):
        """保存文件
        
        Args:
            content: 文件內容
            fab: FAB名稱
            product: 產品名稱
            sop_name: SOP名稱
            extension: 文件擴展名，默認為None（根據內容類型自動確定）
            original_filename: 原始文件名，默認為None
            
        Returns:
            保存結果
        """
        try:
            # 確定文件擴展名
            if extension is None:
                if original_filename:
                    extension = original_filename.split('.')[-1]
                else:
                    extension = 'md'  # 默認為Markdown
            
            # 獲取存儲路徑
            storage_path = self.get_storage_path(fab, product)
            
            # 生成文件名
            filename = self.generate_filename(fab, product, sop_name, extension)
            
            # 構建完整路徑
            file_path = os.path.join(storage_path, filename)
            
            # 保存文件
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            # 計算相對路徑
            relative_path = os.path.relpath(file_path, self.base_dir)
            
            # 轉換為Windows路徑
            windows_path = self.windows_adapter.to_windows_path(file_path)
            
            logger.info(f"文件已保存: {file_path} (Windows: {windows_path})")
            
            return {
                'success': True,
                'path': file_path,
                'windows_path': windows_path,
                'relative_path': relative_path,
                'filename': filename,
                'fab': fab,
                'product': product,
                'sop_name': sop_name
            }
            
        except Exception as e:
            logger.error(f"保存文件失敗: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def list_files(self, fab=None, product=None):
        """列出文件
        
        Args:
            fab: 可選的FAB過濾條件
            product: 可選的產品過濾條件
            
        Returns:
            文件列表
        """
        try:
            files = []
            
            # 如果指定了FAB和產品
            if fab and product:
                storage_path = self.get_storage_path(fab, product)
                if os.path.exists(storage_path):
                    for filename in os.listdir(storage_path):
                        file_path = os.path.join(storage_path, filename)
                        if os.path.isfile(file_path):
                            # 解析文件名
                            parts = filename.split('_')
                            if len(parts) >= 4:
                                file_fab = parts[0]
                                file_product = parts[1]
                                file_sop_name = '_'.join(parts[2:-1])
                                file_timestamp = parts[-1].split('.')[0]
                                file_extension = filename.split('.')[-1]
                                
                                files.append({
                                    'path': file_path,
                                    'windows_path': self.windows_adapter.to_windows_path(file_path),
                                    'relative_path': os.path.relpath(file_path, self.base_dir),
                                    'filename': filename,
                                    'fab': file_fab,
                                    'product': file_product,
                                    'sop_name': file_sop_name,
                                    'timestamp': file_timestamp,
                                    'extension': file_extension
                                })
            
            # 如果只指定了FAB
            elif fab:
                fab_path = os.path.join(self.windows_adapter.windows_root, fab)
                fab_path = self.windows_adapter.to_unix_path(fab_path)
                
                if os.path.exists(fab_path):
                    for product_dir in os.listdir(fab_path):
                        product_path = os.path.join(fab_path, product_dir)
                        if os.path.isdir(product_path):
                            for filename in os.listdir(product_path):
                                file_path = os.path.join(product_path, filename)
                                if os.path.isfile(file_path):
                                    # 解析文件名
                                    parts = filename.split('_')
                                    if len(parts) >= 4:
                                        file_fab = parts[0]
                                        file_product = parts[1]
                                        file_sop_name = '_'.join(parts[2:-1])
                                        file_timestamp = parts[-1].split('.')[0]
                                        file_extension = filename.split('.')[-1]
                                        
                                        files.append({
                                            'path': file_path,
                                            'windows_path': self.windows_adapter.to_windows_path(file_path),
                                            'relative_path': os.path.relpath(file_path, self.base_dir),
                                            'filename': filename,
                                            'fab': file_fab,
                                            'product': file_product,
                                            'sop_name': file_sop_name,
                                            'timestamp': file_timestamp,
                                            'extension': file_extension
                                        })
            
            # 如果沒有指定FAB和產品，列出所有文件
            else:
                windows_root = self.windows_adapter.windows_root
                root_path = self.windows_adapter.to_unix_path(windows_root)
                
                if os.path.exists(root_path):
                    for fab_dir in os.listdir(root_path):
                        fab_path = os.path.join(root_path, fab_dir)
                        if os.path.isdir(fab_path):
                            for product_dir in os.listdir(fab_path):
                                product_path = os.path.join(fab_path, product_dir)
                                if os.path.isdir(product_path):
                                    for filename in os.listdir(product_path):
                                        file_path = os.path.join(product_path, filename)
                                        if os.path.isfile(file_path):
                                            # 解析文件名
                                            parts = filename.split('_')
                                            if len(parts) >= 4:
                                                file_fab = parts[0]
                                                file_product = parts[1]
                                                file_sop_name = '_'.join(parts[2:-1])
                                                file_timestamp = parts[-1].split('.')[0]
                                                file_extension = filename.split('.')[-1]
                                                
                                                files.append({
                                                    'path': file_path,
                                                    'windows_path': self.windows_adapter.to_windows_path(file_path),
                                                    'relative_path': os.path.relpath(file_path, self.base_dir),
                                                    'filename': filename,
                                                    'fab': file_fab,
                                                    'product': file_product,
                                                    'sop_name': file_sop_name,
                                                    'timestamp': file_timestamp,
                                                    'extension': file_extension
                                                })
            
            logger.info(f"列出文件: {len(files)} 個文件")
            return files
            
        except Exception as e:
            logger.error(f"列出文件失敗: {str(e)}")
            return []
    
    def get_file(self, file_path):
        """獲取文件內容
        
        Args:
            file_path: 文件路徑
            
        Returns:
            文件內容
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            logger.info(f"獲取文件內容: {file_path}")
            return content
            
        except Exception as e:
            logger.error(f"獲取文件內容失敗: {file_path}, 錯誤: {str(e)}")
            return None
    
    def delete_file(self, file_path):
        """刪除文件
        
        Args:
            file_path: 文件路徑
            
        Returns:
            布爾值，表示操作是否成功
        """
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
                logger.info(f"刪除文件: {file_path}")
                return True
            else:
                logger.warning(f"文件不存在，無法刪除: {file_path}")
                return False
                
        except Exception as e:
            logger.error(f"刪除文件失敗: {file_path}, 錯誤: {str(e)}")
            return False
    
    def create_windows_structure(self):
        """創建Windows環境下的目錄結構
        
        Returns:
            布爾值，表示操作是否成功
        """
        return self.windows_adapter.create_windows_structure()
