import os
import json
import shutil
import datetime
import difflib
import re

class VersionControl:
    """增強的SOP版本控制系統，支持版本比較、回滾和分支"""
    
    def __init__(self, versions_folder):
        """初始化版本控制系統
        
        Args:
            versions_folder: 版本存儲目錄
        """
        self.versions_folder = versions_folder
        os.makedirs(versions_folder, exist_ok=True)
    
    def create_version(self, sop_id, file_path, version=None, comment=None, author=None):
        """創建新版本
        
        Args:
            sop_id: SOP的唯一ID
            file_path: SOP文件路徑
            version: 可選的版本號，如果未提供則自動計算
            comment: 可選的版本註釋
            author: 可選的作者信息
            
        Returns:
            版本信息
        """
        # 確保SOP的版本目錄存在
        sop_version_folder = os.path.join(self.versions_folder, sop_id)
        os.makedirs(sop_version_folder, exist_ok=True)
        
        # 如果未指定版本，則自動計算下一個版本號
        if version is None:
            version = self._get_next_version(sop_id)
        
        # 獲取原始文件名
        original_filename = os.path.basename(file_path)
        
        # 創建版本文件名
        version_filename = f"v{version}_{original_filename}"
        version_path = os.path.join(sop_version_folder, version_filename)
        
        # 複製文件到版本目錄
        shutil.copy2(file_path, version_path)
        
        # 創建版本元數據
        version_info = {
            'version': version,
            'filename': version_filename,
            'path': version_path,
            'created_at': datetime.datetime.now().isoformat(),
            'comment': comment or f"Version {version}",
            'author': author or "System"
        }
        
        # 保存版本元數據
        metadata_path = os.path.join(sop_version_folder, f"v{version}_metadata.json")
        with open(metadata_path, 'w', encoding='utf-8') as f:
            json.dump(version_info, f, indent=2)
        
        return version_info
    
    def get_versions(self, sop_id):
        """獲取SOP的所有版本
        
        Args:
            sop_id: SOP的唯一ID
            
        Returns:
            版本列表
        """
        sop_version_folder = os.path.join(self.versions_folder, sop_id)
        if not os.path.exists(sop_version_folder):
            return []
        
        versions = []
        for filename in os.listdir(sop_version_folder):
            if filename.startswith('v') and filename.endswith('_metadata.json'):
                metadata_path = os.path.join(sop_version_folder, filename)
                
                with open(metadata_path, 'r', encoding='utf-8') as f:
                    version_info = json.load(f)
                    versions.append(version_info)
            elif filename.startswith('v') and not filename.endswith('_metadata.json'):
                # 處理沒有元數據的舊版本文件
                version_str = filename.split('_')[0][1:]
                
                # 檢查是否已經有這個版本的元數據
                if not any(v.get('version') == version_str for v in versions):
                    version_path = os.path.join(sop_version_folder, filename)
                    
                    versions.append({
                        'version': version_str,
                        'filename': filename,
                        'path': version_path,
                        'created_at': datetime.datetime.fromtimestamp(
                            os.path.getctime(version_path)
                        ).isoformat(),
                        'comment': f"Version {version_str}",
                        'author': "System"
                    })
        
        # 按版本號排序
        versions.sort(key=lambda x: float(x['version']), reverse=True)
        
        return versions
    
    def get_version(self, sop_id, version):
        """獲取特定版本的SOP
        
        Args:
            sop_id: SOP的唯一ID
            version: 版本號
            
        Returns:
            版本信息和內容
        """
        sop_version_folder = os.path.join(self.versions_folder, sop_id)
        if not os.path.exists(sop_version_folder):
            return None
        
        # 查找版本元數據
        metadata_path = os.path.join(sop_version_folder, f"v{version}_metadata.json")
        if os.path.exists(metadata_path):
            with open(metadata_path, 'r', encoding='utf-8') as f:
                version_info = json.load(f)
                
                # 獲取版本文件內容
                version_path = version_info.get('path')
                if not os.path.exists(version_path):
                    # 嘗試使用相對路徑
                    version_path = os.path.join(sop_version_folder, version_info.get('filename'))
                
                if os.path.exists(version_path):
                    with open(version_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        version_info['content'] = content
                
                return version_info
        
        # 如果沒有找到元數據，嘗試直接查找版本文件
        for filename in os.listdir(sop_version_folder):
            if filename.startswith(f"v{version}_") and not filename.endswith('_metadata.json'):
                version_path = os.path.join(sop_version_folder, filename)
                
                with open(version_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                return {
                    'version': version,
                    'filename': filename,
                    'path': version_path,
                    'content': content,
                    'created_at': datetime.datetime.fromtimestamp(
                        os.path.getctime(version_path)
                    ).isoformat(),
                    'comment': f"Version {version}",
                    'author': "System"
                }
        
        return None
    
    def compare_versions(self, sop_id, version1, version2, format='unified'):
        """比較兩個版本的差異
        
        Args:
            sop_id: SOP的唯一ID
            version1: 第一個版本號
            version2: 第二個版本號
            format: 差異格式，可選 'unified'、'html' 或 'json'
            
        Returns:
            差異信息
        """
        v1 = self.get_version(sop_id, version1)
        v2 = self.get_version(sop_id, version2)
        
        if not v1 or not v2:
            return None
        
        # 獲取內容
        content1 = v1.get('content', '')
        content2 = v2.get('content', '')
        
        # 分割為行
        lines1 = content1.splitlines()
        lines2 = content2.splitlines()
        
        # 計算差異
        if format == 'unified':
            # 統一差異格式
            diff = difflib.unified_diff(
                lines1, 
                lines2, 
                fromfile=f"Version {version1}", 
                tofile=f"Version {version2}", 
                lineterm=''
            )
            return '\n'.join(diff)
        
        elif format == 'html':
            # HTML差異格式
            diff = difflib.HtmlDiff()
            return diff.make_file(
                lines1, 
                lines2, 
                f"Version {version1}", 
                f"Version {version2}"
            )
        
        elif format == 'json':
            # JSON差異格式
            matcher = difflib.SequenceMatcher(None, lines1, lines2)
            diffs = []
            
            for tag, i1, i2, j1, j2 in matcher.get_opcodes():
                if tag == 'equal':
                    diffs.append({
                        'type': 'equal',
                        'lines1': lines1[i1:i2],
                        'lines2': lines2[j1:j2],
                        'line_range1': [i1, i2],
                        'line_range2': [j1, j2]
                    })
                elif tag == 'replace':
                    diffs.append({
                        'type': 'replace',
                        'lines1': lines1[i1:i2],
                        'lines2': lines2[j1:j2],
                        'line_range1': [i1, i2],
                        'line_range2': [j1, j2]
                    })
                elif tag == 'delete':
                    diffs.append({
                        'type': 'delete',
                        'lines1': lines1[i1:i2],
                        'lines2': [],
                        'line_range1': [i1, i2],
                        'line_range2': [j1, j2]
                    })
                elif tag == 'insert':
                    diffs.append({
                        'type': 'insert',
                        'lines1': [],
                        'lines2': lines2[j1:j2],
                        'line_range1': [i1, i2],
                        'line_range2': [j1, j2]
                    })
            
            return {
                'version1': {
                    'version': version1,
                    'total_lines': len(lines1)
                },
                'version2': {
                    'version': version2,
                    'total_lines': len(lines2)
                },
                'differences': diffs
            }
        
        else:
            raise ValueError(f"不支持的差異格式: {format}")
    
    def rollback(self, sop_id, version, target_path):
        """回滾到指定版本
        
        Args:
            sop_id: SOP的唯一ID
            version: 要回滾到的版本號
            target_path: 目標文件路徑
            
        Returns:
            回滾結果
        """
        version_info = self.get_version(sop_id, version)
        if not version_info:
            return {
                'success': False,
                'error': f"找不到版本 {version}"
            }
        
        # 獲取版本文件路徑
        version_path = version_info.get('path')
        if not os.path.exists(version_path):
            # 嘗試使用相對路徑
            version_path = os.path.join(self.versions_folder, sop_id, version_info.get('filename'))
        
        if not os.path.exists(version_path):
            return {
                'success': False,
                'error': f"找不到版本文件: {version_path}"
            }
        
        # 複製版本文件到目標路徑
        try:
            shutil.copy2(version_path, target_path)
            
            return {
                'success': True,
                'version': version,
                'target_path': target_path
            }
        except Exception as e:
            return {
                'success': False,
                'error': f"回滾失敗: {str(e)}"
            }
    
    def create_branch(self, sop_id, base_version, branch_name):
        """創建分支
        
        Args:
            sop_id: SOP的唯一ID
            base_version: 基礎版本號
            branch_name: 分支名稱
            
        Returns:
            分支信息
        """
        # 獲取基礎版本
        base_version_info = self.get_version(sop_id, base_version)
        if not base_version_info:
            return {
                'success': False,
                'error': f"找不到基礎版本 {base_version}"
            }
        
        # 創建分支目錄
        branch_folder = os.path.join(self.versions_folder, sop_id, 'branches', branch_name)
        os.makedirs(branch_folder, exist_ok=True)
        
        # 複製基礎版本到分支
        base_version_path = base_version_info.get('path')
        if not os.path.exists(base_version_path):
            # 嘗試使用相對路徑
            base_version_path = os.path.join(self.versions_folder, sop_id, base_version_info.get('filename'))
        
        if not os.path.exists(base_version_path):
            return {
                'success': False,
                'error': f"找不到基礎版本文件: {base_version_path}"
            }
        
        # 創建分支版本文件
        branch_version_filename = f"v1.0_{os.path.basename(base_version_path).split('_', 1)[1]}"
        branch_version_path = os.path.join(branch_folder, branch_version_filename)
        
        # 複製文件
        shutil.copy2(base_version_path, branch_version_path)
        
        # 創建分支元數據
        branch_info = {
            'name': branch_name,
            'base_version': base_version,
            'created_at': datetime.datetime.now().isoformat(),
            'current_version': '1.0',
            'versions': [
                {
                    'version': '1.0',
                    'filename': branch_version_filename,
                    'path': branch_version_path,
                    'created_at': datetime.datetime.now().isoformat(),
                    'comment': f"Branch {branch_name} created from version {base_version}",
                    'author': "System"
                }
            ]
        }
        
        # 保存分支元數據
        branch_metadata_path = os.path.join(branch_folder, 'branch_metadata.json')
        with open(branch_metadata_path, 'w', encoding='utf-8') as f:
            json.dump(branch_info, f, indent=2)
        
        return {
            'success': True,
            'branch': branch_info
        }
    
    def get_branches(self, sop_id):
        """獲取SOP的所有分支
        
        Args:
            sop_id: SOP的唯一ID
            
        Returns:
            分支列表
        """
        branches_folder = os.path.join(self.versions_folder, sop_id, 'branches')
        if not os.path.exists(branches_folder):
            return []
        
        branches = []
        for branch_name in os.listdir(branches_folder):
            branch_folder = os.path.join(branches_folder, branch_name)
            if os.path.isdir(branch_folder):
                # 讀取分支元數據
                metadata_path = os.path.join(branch_folder, 'branch_metadata.json')
                if os.path.exists(metadata_path):
                    with open(metadata_path, 'r', encoding='utf-8') as f:
                        branch_info = json.load(f)
                        branches.append(branch_info)
                else:
                    # 如果沒有元數據，創建基本信息
                    branches.append({
                        'name': branch_name,
                        'created_at': datetime.datetime.fromtimestamp(
                            os.path.getctime(branch_folder)
                        ).isoformat(),
                        'current_version': 'unknown'
                    })
        
        return branches
    
    def merge_branch(self, sop_id, branch_name, target_path):
        """合併分支到主線
        
        Args:
            sop_id: SOP的唯一ID
            branch_name: 分支名稱
            target_path: 目標文件路徑
            
        Returns:
            合併結果
        """
        # 獲取分支信息
        branches_folder = os.path.join(self.versions_folder, sop_id, 'branches')
        branch_folder = os.path.join(branches_folder, branch_name)
        
        if not os.path.exists(branch_folder):
            return {
                'success': False,
                'error': f"找不到分支: {branch_name}"
            }
        
        # 讀取分支元數據
        metadata_path = os.path.join(branch_folder, 'branch_metadata.json')
        if not os.path.exists(metadata_path):
            return {
                'success': False,
                'error': f"找不到分支元數據: {metadata_path}"
            }
        
        with open(metadata_path, 'r', encoding='utf-8') as f:
            branch_info = json.load(f)
        
        # 獲取最新版本
        if not branch_info.get('versions'):
            return {
                'success': False,
                'error': f"分支沒有版本: {branch_name}"
            }
        
        latest_version = branch_info['versions'][0]
        version_path = latest_version.get('path')
        
        if not os.path.exists(version_path):
            # 嘗試使用相對路徑
            version_path = os.path.join(branch_folder, latest_version.get('filename'))
        
        if not os.path.exists(version_path):
            return {
                'success': False,
                'error': f"找不到分支版本文件: {version_path}"
            }
        
        # 複製分支版本到目標路徑
        try:
            shutil.copy2(version_path, target_path)
            
            return {
                'success': True,
                'branch': branch_name,
                'version': latest_version.get('version'),
                'target_path': target_path
            }
        except Exception as e:
            return {
                'success': False,
                'error': f"合併失敗: {str(e)}"
            }
    
    def _get_next_version(self, sop_id):
        """獲取下一個版本號
        
        Args:
            sop_id: SOP的唯一ID
            
        Returns:
            下一個版本號
        """
        versions = self.get_versions(sop_id)
        
        if not versions:
            return '1.0'
        
        # 獲取最新版本號
        latest_version = float(versions[0]['version'])
        
        # 增加0.1作為新版本號
        return str(latest_version + 0.1)
