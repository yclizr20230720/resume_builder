import os
import json
import datetime
import uuid
import logging
from .storage_manager import StorageManager
from .document_converter import DocumentConverter
from .jupyter_integration import JupyterIntegration
from .ai_notebook_generator import AINotebookGenerator
from .windows_adapter import WindowsAdapter

# 配置日誌
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='sop_manager.log'
)
logger = logging.getLogger('sop_manager')

class SopManager:
    """SOP管理器，整合SOP創建、上傳、執行和報告生成功能"""
    
    def __init__(self, base_dir, windows_root="D:\\"):
        """初始化SOP管理器
        
        Args:
            base_dir: 基礎目錄
            windows_root: Windows環境下的根目錄
        """
        self.base_dir = base_dir
        self.windows_root = windows_root
        
        # 初始化相關組件
        self.windows_adapter = WindowsAdapter(base_dir, windows_root)
        self.storage_manager = StorageManager(base_dir, windows_root)
        self.document_converter = DocumentConverter()
        self.jupyter_integration = JupyterIntegration(base_dir)
        self.ai_notebook_generator = AINotebookGenerator(base_dir)
        
        # 確保目錄存在
        self.metadata_dir = os.path.join(base_dir, 'metadata')
        os.makedirs(self.metadata_dir, exist_ok=True)
        
        logger.info(f"初始化SOP管理器，基礎目錄: {base_dir}, Windows根目錄: {windows_root}")
    
    def create_sop_from_file(self, file_obj, metadata):
        """從上傳的文件創建SOP
        
        Args:
            file_obj: 上傳的文件對象
            metadata: SOP元數據
            
        Returns:
            創建結果
        """
        try:
            # 獲取文件名和擴展名
            filename = file_obj.filename
            extension = filename.split('.')[-1].lower()
            
            # 臨時保存文件
            temp_path = os.path.join(self.base_dir, f"temp_{uuid.uuid4()}_{filename}")
            file_obj.save(temp_path)
            
            # 處理不同類型的文件
            if extension in ['doc', 'docx']:
                # 轉換Word文檔為Markdown
                markdown_content = self.document_converter.word_to_markdown(temp_path)
                
                # 保存Markdown文件
                storage_result = self.storage_manager.save_file(
                    markdown_content,
                    metadata['fab'],
                    metadata['product'],
                    metadata['title'],
                    'md'
                )
                
                # 更新元數據
                metadata['file_type'] = 'md'
                metadata['original_file_type'] = extension
                metadata['storage_path'] = storage_result['relative_path']
                
                # 生成Jupyter Notebook
                notebook_result = self.ai_notebook_generator.generate_notebook(
                    markdown_content,
                    metadata
                )
                
                # 保存原始文件
                original_storage_result = self.storage_manager.save_file(
                    open(temp_path, 'rb').read().decode('utf-8', errors='ignore'),
                    metadata['fab'],
                    metadata['product'],
                    metadata['title'],
                    extension
                )
                
                metadata['original_storage_path'] = original_storage_result['relative_path']
                
            elif extension == 'md':
                # 讀取Markdown文件
                with open(temp_path, 'r', encoding='utf-8') as f:
                    markdown_content = f.read()
                
                # 保存Markdown文件
                storage_result = self.storage_manager.save_file(
                    markdown_content,
                    metadata['fab'],
                    metadata['product'],
                    metadata['title'],
                    'md'
                )
                
                # 更新元數據
                metadata['file_type'] = 'md'
                metadata['storage_path'] = storage_result['relative_path']
                
                # 生成Jupyter Notebook
                notebook_result = self.ai_notebook_generator.generate_notebook(
                    markdown_content,
                    metadata
                )
                
            else:
                # 其他類型文件，直接保存
                with open(temp_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                storage_result = self.storage_manager.save_file(
                    content,
                    metadata['fab'],
                    metadata['product'],
                    metadata['title'],
                    extension
                )
                
                # 更新元數據
                metadata['file_type'] = extension
                metadata['storage_path'] = storage_result['relative_path']
                
                # 如果不是Markdown，嘗試轉換為Markdown
                try:
                    markdown_content = content
                    notebook_result = self.ai_notebook_generator.generate_notebook(
                        markdown_content,
                        metadata
                    )
                except:
                    notebook_result = {
                        'success': False,
                        'error': '無法從此文件類型生成筆記本'
                    }
            
            # 生成SOP ID
            sop_id = str(uuid.uuid4())
            
            # 添加基本元數據
            metadata['id'] = sop_id
            metadata['created_at'] = datetime.datetime.now().isoformat()
            metadata['updated_at'] = datetime.datetime.now().isoformat()
            metadata['version'] = '1.0'
            metadata['status'] = 'draft'
            
            if notebook_result['success']:
                metadata['notebook_path'] = os.path.relpath(notebook_result['path'], self.base_dir)
            
            # 保存元數據
            metadata_path = os.path.join(self.metadata_dir, f"{sop_id}.json")
            with open(metadata_path, 'w', encoding='utf-8') as f:
                json.dump(metadata, f, indent=2)
            
            # 刪除臨時文件
            if os.path.exists(temp_path):
                os.remove(temp_path)
            
            logger.info(f"從文件創建SOP成功: {sop_id}")
            
            return {
                'success': True,
                'sop_id': sop_id,
                'metadata': metadata,
                'storage': storage_result,
                'notebook': notebook_result if notebook_result['success'] else None
            }
            
        except Exception as e:
            logger.error(f"從文件創建SOP失敗: {str(e)}")
            
            # 刪除臨時文件
            if 'temp_path' in locals() and os.path.exists(temp_path):
                os.remove(temp_path)
            
            return {
                'success': False,
                'error': str(e)
            }
    
    def create_sop_from_url(self, url, metadata):
        """從URL創建SOP
        
        Args:
            url: SOP內容的URL
            metadata: SOP元數據
            
        Returns:
            創建結果
        """
        try:
            # 提取URL內容
            markdown_content = self.document_converter.extract_from_url(url)
            
            # 保存Markdown文件
            storage_result = self.storage_manager.save_file(
                markdown_content,
                metadata['fab'],
                metadata['product'],
                metadata['title'],
                'md'
            )
            
            # 更新元數據
            metadata['file_type'] = 'md'
            metadata['source_url'] = url
            metadata['storage_path'] = storage_result['relative_path']
            
            # 生成Jupyter Notebook
            notebook_result = self.ai_notebook_generator.generate_notebook(
                markdown_content,
                metadata
            )
            
            # 生成SOP ID
            sop_id = str(uuid.uuid4())
            
            # 添加基本元數據
            metadata['id'] = sop_id
            metadata['created_at'] = datetime.datetime.now().isoformat()
            metadata['updated_at'] = datetime.datetime.now().isoformat()
            metadata['version'] = '1.0'
            metadata['status'] = 'draft'
            
            if notebook_result['success']:
                metadata['notebook_path'] = os.path.relpath(notebook_result['path'], self.base_dir)
            
            # 保存元數據
            metadata_path = os.path.join(self.metadata_dir, f"{sop_id}.json")
            with open(metadata_path, 'w', encoding='utf-8') as f:
                json.dump(metadata, f, indent=2)
            
            logger.info(f"從URL創建SOP成功: {sop_id}")
            
            return {
                'success': True,
                'sop_id': sop_id,
                'metadata': metadata,
                'storage': storage_result,
                'notebook': notebook_result if notebook_result['success'] else None
            }
            
        except Exception as e:
            logger.error(f"從URL創建SOP失敗: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def create_sop_from_content(self, content, metadata):
        """從內容創建SOP
        
        Args:
            content: SOP內容
            metadata: SOP元數據
            
        Returns:
            創建結果
        """
        try:
            # 保存Markdown文件
            storage_result = self.storage_manager.save_file(
                content,
                metadata['fab'],
                metadata['product'],
                metadata['title'],
                'md'
            )
            
            # 更新元數據
            metadata['file_type'] = 'md'
            metadata['storage_path'] = storage_result['relative_path']
            
            # 生成Jupyter Notebook
            notebook_result = self.ai_notebook_generator.generate_notebook(
                content,
                metadata
            )
            
            # 生成SOP ID
            sop_id = str(uuid.uuid4())
            
            # 添加基本元數據
            metadata['id'] = sop_id
            metadata['created_at'] = datetime.datetime.now().isoformat()
            metadata['updated_at'] = datetime.datetime.now().isoformat()
            metadata['version'] = '1.0'
            metadata['status'] = 'draft'
            
            if notebook_result['success']:
                metadata['notebook_path'] = os.path.relpath(notebook_result['path'], self.base_dir)
            
            # 保存元數據
            metadata_path = os.path.join(self.metadata_dir, f"{sop_id}.json")
            with open(metadata_path, 'w', encoding='utf-8') as f:
                json.dump(metadata, f, indent=2)
            
            logger.info(f"從內容創建SOP成功: {sop_id}")
            
            return {
                'success': True,
                'sop_id': sop_id,
                'metadata': metadata,
                'storage': storage_result,
                'notebook': notebook_result if notebook_result['success'] else None
            }
            
        except Exception as e:
            logger.error(f"從內容創建SOP失敗: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def get_sop(self, sop_id):
        """獲取SOP信息
        
        Args:
            sop_id: SOP的唯一ID
            
        Returns:
            SOP信息
        """
        try:
            # 獲取元數據
            metadata_path = os.path.join(self.metadata_dir, f"{sop_id}.json")
            if not os.path.exists(metadata_path):
                logger.warning(f"SOP不存在: {sop_id}")
                return None
            
            with open(metadata_path, 'r', encoding='utf-8') as f:
                metadata = json.load(f)
            
            # 獲取SOP內容
            content = None
            if 'storage_path' in metadata:
                file_path = os.path.join(self.base_dir, metadata['storage_path'])
                if os.path.exists(file_path):
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
            
            # 獲取Jupyter Notebook
            notebook = None
            if 'notebook_path' in metadata:
                notebook_path = os.path.join(self.base_dir, metadata['notebook_path'])
                if os.path.exists(notebook_path):
                    with open(notebook_path, 'r', encoding='utf-8') as f:
                        notebook = json.load(f)
            
            logger.info(f"獲取SOP信息: {sop_id}")
            
            return {
                'metadata': metadata,
                'content': content,
                'notebook': notebook
            }
            
        except Exception as e:
            logger.error(f"獲取SOP信息失敗: {sop_id}, 錯誤: {str(e)}")
            return None
    
    def list_sops(self, fab=None, product=None):
        """列出所有SOP
        
        Args:
            fab: 可選的FAB過濾條件
            product: 可選的產品過濾條件
            
        Returns:
            SOP列表
        """
        try:
            # 獲取所有元數據文件
            metadata_files = [f for f in os.listdir(self.metadata_dir) if f.endswith('.json')]
            
            sops = []
            for metadata_file in metadata_files:
                # 讀取元數據
                with open(os.path.join(self.metadata_dir, metadata_file), 'r', encoding='utf-8') as f:
                    metadata = json.load(f)
                
                # 過濾FAB和產品
                if fab and metadata.get('fab') != fab:
                    continue
                
                if product and metadata.get('product') != product:
                    continue
                
                sops.append({
                    'metadata': metadata
                })
            
            logger.info(f"列出SOP: {len(sops)} 個SOP")
            return sops
            
        except Exception as e:
            logger.error(f"列出SOP失敗: {str(e)}")
            return []
    
    def search_sops(self, query=None, fab=None, product=None):
        """搜索SOP
        
        Args:
            query: 搜索關鍵詞
            fab: 可選的FAB過濾條件
            product: 可選的產品過濾條件
            
        Returns:
            搜索結果
        """
        try:
            # 獲取所有SOP
            all_sops = self.list_sops(fab, product)
            
            # 如果沒有查詢條件，返回所有結果
            if not query:
                return all_sops
            
            # 過濾結果
            results = []
            query = query.lower()
            
            for sop in all_sops:
                metadata = sop['metadata']
                
                # 搜索標題、描述和作者
                if ('title' in metadata and query in metadata['title'].lower()) or \
                   ('description' in metadata and query in metadata['description'].lower()) or \
                   ('author' in metadata and query in metadata['author'].lower()):
                    results.append(sop)
                    continue
                
                # 搜索SOP內容
                if 'storage_path' in metadata:
                    file_path = os.path.join(self.base_dir, metadata['storage_path'])
                    if os.path.exists(file_path):
                        try:
                            with open(file_path, 'r', encoding='utf-8') as f:
                                content = f.read().lower()
                                if query in content:
                                    results.append(sop)
                                    continue
                        except:
                            pass
            
            logger.info(f"搜索SOP: {len(results)} 個結果")
            return results
            
        except Exception as e:
            logger.error(f"搜索SOP失敗: {str(e)}")
            return []
    
    def execute_sop(self, sop_id):
        """執行SOP
        
        Args:
            sop_id: SOP的唯一ID
            
        Returns:
            執行結果
        """
        try:
            # 獲取SOP信息
            sop = self.get_sop(sop_id)
            if not sop:
                logger.warning(f"SOP不存在: {sop_id}")
                return {
                    'success': False,
                    'error': 'SOP不存在'
                }
            
            # 檢查是否有筆記本
            if not sop['notebook']:
                logger.warning(f"SOP沒有關聯的筆記本: {sop_id}")
                return {
                    'success': False,
                    'error': 'SOP沒有關聯的筆記本'
                }
            
            # 獲取筆記本路徑
            notebook_path = os.path.join(self.base_dir, sop['metadata']['notebook_path'])
            
            # 啟動截圖服務
            task_id = self.jupyter_integration.start_screenshot_service(notebook_path)
            
            # 獲取筆記本URL
            notebook_url = self.jupyter_integration.open_notebook_in_jupyter(notebook_path)
            
            logger.info(f"執行SOP: {sop_id}, 任務ID: {task_id}")
            
            return {
                'success': True,
                'task_id': task_id,
                'notebook_url': notebook_url,
                'sop_id': sop_id
            }
            
        except Exception as e:
            logger.error(f"執行SOP失敗: {sop_id}, 錯誤: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def stop_sop_execution(self, task_id):
        """停止SOP執行
        
        Args:
            task_id: 任務ID
            
        Returns:
            停止結果
        """
        try:
            # 停止截圖服務
            result = self.jupyter_integration.stop_screenshot_service(task_id)
            
            logger.info(f"停止SOP執行: {task_id}, 結果: {result}")
            
            return {
                'success': result
            }
            
        except Exception as e:
            logger.error(f"停止SOP執行失敗: {task_id}, 錯誤: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def generate_report(self, task_id, sop_id):
        """生成SOP執行報告
        
        Args:
            task_id: 任務ID
            sop_id: SOP的唯一ID
            
        Returns:
            報告生成結果
        """
        try:
            # 獲取SOP信息
            sop = self.get_sop(sop_id)
            if not sop:
                logger.warning(f"SOP不存在: {sop_id}")
                return {
                    'success': False,
                    'error': 'SOP不存在'
                }
            
            # 生成報告
            report_path = self.jupyter_integration.generate_report(task_id, sop['metadata'].get('title'))
            
            if not report_path:
                logger.warning(f"生成報告失敗: {task_id}")
                return {
                    'success': False,
                    'error': '生成報告失敗'
                }
            
            # 更新元數據
            metadata = sop['metadata']
            if 'reports' not in metadata:
                metadata['reports'] = []
            
            report_info = {
                'path': os.path.relpath(report_path, self.base_dir),
                'created_at': datetime.datetime.now().isoformat(),
                'task_id': task_id
            }
            
            metadata['reports'].append(report_info)
            metadata['updated_at'] = datetime.datetime.now().isoformat()
            
            # 保存元數據
            metadata_path = os.path.join(self.metadata_dir, f"{sop_id}.json")
            with open(metadata_path, 'w', encoding='utf-8') as f:
                json.dump(metadata, f, indent=2)
            
            logger.info(f"生成報告: {report_path}")
            
            return {
                'success': True,
                'report_path': report_path,
                'report_info': report_info
            }
            
        except Exception as e:
            logger.error(f"生成報告失敗: {task_id}, 錯誤: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def update_sop(self, sop_id, file=None, content=None, metadata=None):
        """更新SOP
        
        Args:
            sop_id: SOP的唯一ID
            file: 新的文件（可選）
            content: 新的內容（可選）
            metadata: 新的元數據（可選）
            
        Returns:
            更新結果
        """
        try:
            # 獲取SOP信息
            sop = self.get_sop(sop_id)
            if not sop:
                logger.warning(f"SOP不存在: {sop_id}")
                return {
                    'success': False,
                    'error': 'SOP不存在'
                }
            
            # 更新元數據
            if metadata:
                sop['metadata'].update(metadata)
            
            # 更新內容
            if file:
                # 從文件更新
                result = self.create_sop_from_file(file, sop['metadata'])
                if not result['success']:
                    return result
                
                # 更新元數據
                sop['metadata'] = result['metadata']
                sop['metadata']['id'] = sop_id  # 保持原始ID
                
            elif content:
                # 從內容更新
                result = self.create_sop_from_content(content, sop['metadata'])
                if not result['success']:
                    return result
                
                # 更新元數據
                sop['metadata'] = result['metadata']
                sop['metadata']['id'] = sop_id  # 保持原始ID
            
            # 更新版本
            version = float(sop['metadata'].get('version', '1.0'))
            sop['metadata']['version'] = str(version + 0.1)
            sop['metadata']['updated_at'] = datetime.datetime.now().isoformat()
            
            # 保存元數據
            metadata_path = os.path.join(self.metadata_dir, f"{sop_id}.json")
            with open(metadata_path, 'w', encoding='utf-8') as f:
                json.dump(sop['metadata'], f, indent=2)
            
            logger.info(f"更新SOP: {sop_id}")
            
            return {
                'success': True,
                'sop_id': sop_id,
                'metadata': sop['metadata'],
                'version': sop['metadata']['version']
            }
            
        except Exception as e:
            logger.error(f"更新SOP失敗: {sop_id}, 錯誤: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def delete_sop(self, sop_id):
        """刪除SOP
        
        Args:
            sop_id: SOP的唯一ID
            
        Returns:
            刪除結果
        """
        try:
            # 獲取SOP信息
            sop = self.get_sop(sop_id)
            if not sop:
                logger.warning(f"SOP不存在: {sop_id}")
                return False
            
            # 刪除文件
            if 'storage_path' in sop['metadata']:
                file_path = os.path.join(self.base_dir, sop['metadata']['storage_path'])
                if os.path.exists(file_path):
                    os.remove(file_path)
            
            # 刪除筆記本
            if 'notebook_path' in sop['metadata']:
                notebook_path = os.path.join(self.base_dir, sop['metadata']['notebook_path'])
                if os.path.exists(notebook_path):
                    os.remove(notebook_path)
            
            # 刪除報告
            if 'reports' in sop['metadata']:
                for report in sop['metadata']['reports']:
                    report_path = os.path.join(self.base_dir, report['path'])
                    if os.path.exists(report_path):
                        os.remove(report_path)
            
            # 刪除元數據
            metadata_path = os.path.join(self.metadata_dir, f"{sop_id}.json")
            if os.path.exists(metadata_path):
                os.remove(metadata_path)
            
            logger.info(f"刪除SOP: {sop_id}")
            return True
            
        except Exception as e:
            logger.error(f"刪除SOP失敗: {sop_id}, 錯誤: {str(e)}")
            return False
