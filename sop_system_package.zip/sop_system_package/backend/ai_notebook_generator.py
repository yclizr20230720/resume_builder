import os
import json
import datetime
import uuid
import logging
import requests
from .document_converter import DocumentConverter
from .storage_manager import StorageManager
from .jupyter_integration import JupyterIntegration
from .windows_adapter import WindowsAdapter

# 配置日誌
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    filename='ai_notebook_generator.log'
)
logger = logging.getLogger('ai_notebook_generator')

class AINotebookGenerator:
    """基於SOP內容生成Jupyter Notebook的AI服務"""
    
    def __init__(self, base_dir, api_key=None, api_endpoint=None):
        """初始化AI Notebook生成器
        
        Args:
            base_dir: 基礎目錄
            api_key: AI服務API密鑰（可選）
            api_endpoint: AI服務端點（可選）
        """
        self.base_dir = base_dir
        self.api_key = api_key
        self.api_endpoint = api_endpoint or "https://api.example.com/generate-notebook"
        
        # 初始化相關組件
        self.document_converter = DocumentConverter()
        self.jupyter_integration = JupyterIntegration(base_dir)
        
        # 確保目錄存在
        self.notebooks_dir = os.path.join(base_dir, 'notebooks')
        os.makedirs(self.notebooks_dir, exist_ok=True)
        
        logger.info(f"初始化AI Notebook生成器，基礎目錄: {base_dir}")
    
    def generate_notebook(self, sop_content, metadata=None, use_ai_service=True):
        """從SOP內容生成Jupyter Notebook
        
        Args:
            sop_content: SOP內容（Markdown格式）
            metadata: SOP元數據
            use_ai_service: 是否使用AI服務，默認為True
            
        Returns:
            生成的筆記本對象和保存路徑
        """
        try:
            # 如果使用AI服務
            if use_ai_service and self.api_key:
                notebook = self._generate_notebook_with_ai(sop_content, metadata)
            else:
                # 使用本地轉換
                notebook = self.jupyter_integration.generate_notebook_from_markdown(sop_content, metadata)
            
            # 生成唯一ID
            notebook_id = str(uuid.uuid4())
            
            # 構建保存路徑
            if metadata and 'title' in metadata:
                filename = f"{metadata.get('fab', 'FAB')}_{metadata.get('product', 'PROD')}_{metadata['title']}_{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}.ipynb"
            else:
                filename = f"notebook_{notebook_id}.ipynb"
            
            notebook_path = os.path.join(self.notebooks_dir, filename)
            
            # 保存筆記本
            self.jupyter_integration.save_notebook(notebook, notebook_path)
            
            logger.info(f"筆記本已生成並保存: {notebook_path}")
            
            return {
                'success': True,
                'notebook': notebook,
                'path': notebook_path,
                'id': notebook_id,
                'filename': filename
            }
            
        except Exception as e:
            logger.error(f"生成筆記本失敗: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def _generate_notebook_with_ai(self, sop_content, metadata=None):
        """使用AI服務生成Jupyter Notebook
        
        Args:
            sop_content: SOP內容（Markdown格式）
            metadata: SOP元數據
            
        Returns:
            生成的筆記本對象
        """
        try:
            # 準備請求數據
            data = {
                'sop_content': sop_content,
                'metadata': metadata or {}
            }
            
            # 設置請求頭
            headers = {
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {self.api_key}'
            }
            
            # 發送請求
            response = requests.post(
                self.api_endpoint,
                headers=headers,
                json=data,
                timeout=60
            )
            
            # 檢查響應
            response.raise_for_status()
            
            # 解析響應
            result = response.json()
            
            if 'notebook' in result:
                # 返回筆記本對象
                return result['notebook']
            else:
                # 如果AI服務沒有返回筆記本，使用本地轉換
                logger.warning("AI服務沒有返回筆記本，使用本地轉換")
                return self.jupyter_integration.generate_notebook_from_markdown(sop_content, metadata)
                
        except Exception as e:
            logger.error(f"使用AI服務生成筆記本失敗: {str(e)}")
            # 如果AI服務失敗，使用本地轉換
            logger.info("使用本地轉換作為備選方案")
            return self.jupyter_integration.generate_notebook_from_markdown(sop_content, metadata)
    
    def update_notebook(self, notebook_path, content=None, metadata=None):
        """更新Jupyter Notebook
        
        Args:
            notebook_path: 筆記本路徑
            content: 新的內容（可選）
            metadata: 新的元數據（可選）
            
        Returns:
            更新結果
        """
        try:
            # 讀取現有筆記本
            with open(notebook_path, 'r', encoding='utf-8') as f:
                notebook = json.load(f)
            
            # 更新內容
            if content:
                # 生成新的筆記本
                new_notebook = self.jupyter_integration.generate_notebook_from_markdown(content, metadata)
                
                # 更新單元格
                notebook['cells'] = new_notebook['cells']
            
            # 更新元數據
            if metadata:
                notebook['metadata'].update(metadata)
            
            # 保存筆記本
            with open(notebook_path, 'w', encoding='utf-8') as f:
                json.dump(notebook, f, indent=2)
            
            logger.info(f"筆記本已更新: {notebook_path}")
            
            return {
                'success': True,
                'path': notebook_path
            }
            
        except Exception as e:
            logger.error(f"更新筆記本失敗: {notebook_path}, 錯誤: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def mock_ai_service(self, sop_content, metadata=None):
        """模擬AI服務生成Jupyter Notebook（用於演示）
        
        Args:
            sop_content: SOP內容（Markdown格式）
            metadata: SOP元數據
            
        Returns:
            生成的筆記本對象
        """
        # 使用本地轉換，但添加一些模擬的AI增強
        notebook = self.jupyter_integration.generate_notebook_from_markdown(sop_content, metadata)
        
        # 添加一個AI生成的說明單元格
        if 'cells' in notebook:
            ai_cell = {
                "cell_type": "markdown",
                "metadata": {},
                "source": [
                    "# AI生成的RunbyCode Notebook\n\n",
                    "本筆記本由AI自動生成，基於提供的SOP文檔。\n\n",
                    "## 使用說明\n\n",
                    "1. 按順序執行每個代碼單元格\n",
                    "2. 閱讀每個步驟的說明\n",
                    "3. 觀察執行結果\n",
                    "4. 如有問題，請參考原始SOP文檔\n\n",
                    "**注意**: 本環境為只讀模式，不允許修改代碼。"
                ]
            }
            notebook['cells'].insert(0, ai_cell)
        
        logger.info("已模擬AI服務生成筆記本")
        return notebook
