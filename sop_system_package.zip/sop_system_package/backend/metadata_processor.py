import os
import json
import datetime
import re
from collections import defaultdict

class MetadataProcessor:
    """增強的SOP元數據處理系統，支持高級搜索、分類和過濾"""
    
    def __init__(self, metadata_folder):
        """初始化元數據處理器
        
        Args:
            metadata_folder: 元數據存儲目錄
        """
        self.metadata_folder = metadata_folder
        os.makedirs(metadata_folder, exist_ok=True)
        
        # 索引緩存
        self._index_cache = None
        self._index_last_updated = None
    
    def create_metadata(self, sop_id, data):
        """創建SOP元數據
        
        Args:
            sop_id: SOP的唯一ID
            data: 元數據字典
            
        Returns:
            創建的元數據
        """
        # 基本元數據
        metadata = {
            'id': sop_id,
            'created_at': datetime.datetime.now().isoformat(),
            'updated_at': datetime.datetime.now().isoformat(),
            'version': '1.0',
            'status': 'draft',
            'tags': [],
            'categories': []
        }
        
        # 合併用戶提供的數據
        metadata.update(data)
        
        # 確保必要字段存在
        if 'title' not in metadata:
            metadata['title'] = f"Untitled SOP {sop_id}"
        
        # 自動生成標籤
        if 'tags' not in metadata or not metadata['tags']:
            metadata['tags'] = self._generate_tags(metadata)
        
        # 保存元數據
        self._save_metadata(sop_id, metadata)
        
        # 更新索引
        self._invalidate_index()
        
        return metadata
    
    def get_metadata(self, sop_id):
        """獲取SOP元數據
        
        Args:
            sop_id: SOP的唯一ID
            
        Returns:
            元數據字典
        """
        metadata_path = os.path.join(self.metadata_folder, f"{sop_id}.json")
        if not os.path.exists(metadata_path):
            return None
        
        with open(metadata_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def update_metadata(self, sop_id, data):
        """更新SOP元數據
        
        Args:
            sop_id: SOP的唯一ID
            data: 要更新的元數據字段
            
        Returns:
            更新後的元數據
        """
        metadata = self.get_metadata(sop_id)
        if not metadata:
            return None
        
        # 更新元數據
        metadata.update(data)
        metadata['updated_at'] = datetime.datetime.now().isoformat()
        
        # 保存更新後的元數據
        self._save_metadata(sop_id, metadata)
        
        # 更新索引
        self._invalidate_index()
        
        return metadata
    
    def add_tags(self, sop_id, tags):
        """添加標籤到SOP
        
        Args:
            sop_id: SOP的唯一ID
            tags: 要添加的標籤列表
            
        Returns:
            更新後的元數據
        """
        metadata = self.get_metadata(sop_id)
        if not metadata:
            return None
        
        # 確保tags字段存在
        if 'tags' not in metadata:
            metadata['tags'] = []
        
        # 添加新標籤（避免重複）
        for tag in tags:
            if tag not in metadata['tags']:
                metadata['tags'].append(tag)
        
        # 保存更新後的元數據
        metadata['updated_at'] = datetime.datetime.now().isoformat()
        self._save_metadata(sop_id, metadata)
        
        # 更新索引
        self._invalidate_index()
        
        return metadata
    
    def remove_tags(self, sop_id, tags):
        """從SOP中移除標籤
        
        Args:
            sop_id: SOP的唯一ID
            tags: 要移除的標籤列表
            
        Returns:
            更新後的元數據
        """
        metadata = self.get_metadata(sop_id)
        if not metadata or 'tags' not in metadata:
            return metadata
        
        # 移除標籤
        metadata['tags'] = [tag for tag in metadata['tags'] if tag not in tags]
        
        # 保存更新後的元數據
        metadata['updated_at'] = datetime.datetime.now().isoformat()
        self._save_metadata(sop_id, metadata)
        
        # 更新索引
        self._invalidate_index()
        
        return metadata
    
    def set_categories(self, sop_id, categories):
        """設置SOP的分類
        
        Args:
            sop_id: SOP的唯一ID
            categories: 分類列表
            
        Returns:
            更新後的元數據
        """
        metadata = self.get_metadata(sop_id)
        if not metadata:
            return None
        
        # 設置分類
        metadata['categories'] = categories
        
        # 保存更新後的元數據
        metadata['updated_at'] = datetime.datetime.now().isoformat()
        self._save_metadata(sop_id, metadata)
        
        # 更新索引
        self._invalidate_index()
        
        return metadata
    
    def search(self, query=None, filters=None, sort_by='updated_at', sort_order='desc'):
        """搜索SOP元數據
        
        Args:
            query: 搜索關鍵詞
            filters: 過濾條件字典
            sort_by: 排序字段
            sort_order: 排序順序 ('asc' 或 'desc')
            
        Returns:
            搜索結果
        """
        # 獲取所有元數據
        all_metadata = self._get_all_metadata()
        
        # 應用過濾器
        results = self._apply_filters(all_metadata, filters)
        
        # 應用搜索查詢
        if query:
            results = self._apply_search(results, query)
        
        # 應用排序
        results = self._apply_sorting(results, sort_by, sort_order)
        
        return results
    
    def get_all_tags(self):
        """獲取所有標籤
        
        Returns:
            標籤列表及其使用次數
        """
        # 獲取所有元數據
        all_metadata = self._get_all_metadata()
        
        # 統計標籤
        tag_counts = defaultdict(int)
        for metadata in all_metadata:
            for tag in metadata.get('tags', []):
                tag_counts[tag] += 1
        
        # 轉換為列表
        tags = [{'tag': tag, 'count': count} for tag, count in tag_counts.items()]
        
        # 按使用次數排序
        tags.sort(key=lambda x: x['count'], reverse=True)
        
        return tags
    
    def get_all_categories(self):
        """獲取所有分類
        
        Returns:
            分類列表及其使用次數
        """
        # 獲取所有元數據
        all_metadata = self._get_all_metadata()
        
        # 統計分類
        category_counts = defaultdict(int)
        for metadata in all_metadata:
            for category in metadata.get('categories', []):
                category_counts[category] += 1
        
        # 轉換為列表
        categories = [{'category': category, 'count': count} for category, count in category_counts.items()]
        
        # 按使用次數排序
        categories.sort(key=lambda x: x['count'], reverse=True)
        
        return categories
    
    def get_statistics(self):
        """獲取SOP統計信息
        
        Returns:
            統計信息
        """
        # 獲取所有元數據
        all_metadata = self._get_all_metadata()
        
        # 初始化統計信息
        stats = {
            'total_sops': len(all_metadata),
            'by_fab': defaultdict(int),
            'by_product': defaultdict(int),
            'by_status': defaultdict(int),
            'by_author': defaultdict(int),
            'by_file_type': defaultdict(int),
            'created_last_30_days': 0,
            'updated_last_30_days': 0
        }
        
        # 獲取當前時間
        now = datetime.datetime.now()
        thirty_days_ago = now - datetime.timedelta(days=30)
        thirty_days_ago_str = thirty_days_ago.isoformat()
        
        # 計算統計信息
        for metadata in all_metadata:
            # 按FAB統計
            if 'fab' in metadata:
                stats['by_fab'][metadata['fab']] += 1
            
            # 按產品統計
            if 'product' in metadata:
                stats['by_product'][metadata['product']] += 1
            
            # 按狀態統計
            if 'status' in metadata:
                stats['by_status'][metadata['status']] += 1
            
            # 按作者統計
            if 'author' in metadata:
                stats['by_author'][metadata['author']] += 1
            
            # 按文件類型統計
            if 'file_type' in metadata:
                stats['by_file_type'][metadata['file_type']] += 1
            
            # 最近30天創建的SOP
            if 'created_at' in metadata and metadata['created_at'] > thirty_days_ago_str:
                stats['created_last_30_days'] += 1
            
            # 最近30天更新的SOP
            if 'updated_at' in metadata and metadata['updated_at'] > thirty_days_ago_str:
                stats['updated_last_30_days'] += 1
        
        # 轉換defaultdict為普通dict
        stats['by_fab'] = dict(stats['by_fab'])
        stats['by_product'] = dict(stats['by_product'])
        stats['by_status'] = dict(stats['by_status'])
        stats['by_author'] = dict(stats['by_author'])
        stats['by_file_type'] = dict(stats['by_file_type'])
        
        return stats
    
    def delete_metadata(self, sop_id):
        """刪除SOP元數據
        
        Args:
            sop_id: SOP的唯一ID
            
        Returns:
            是否成功刪除
        """
        metadata_path = os.path.join(self.metadata_folder, f"{sop_id}.json")
        if os.path.exists(metadata_path):
            os.remove(metadata_path)
            
            # 更新索引
            self._invalidate_index()
            
            return True
        
        return False
    
    def _save_metadata(self, sop_id, metadata):
        """保存元數據到文件
        
        Args:
            sop_id: SOP的唯一ID
            metadata: 元數據字典
        """
        metadata_path = os.path.join(self.metadata_folder, f"{sop_id}.json")
        with open(metadata_path, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, indent=2)
    
    def _get_all_metadata(self):
        """獲取所有SOP元數據
        
        Returns:
            元數據列表
        """
        # 檢查索引緩存是否有效
        if self._index_cache is not None and self._index_last_updated is not None:
            # 檢查元數據目錄是否有更新
            latest_update = max([os.path.getmtime(os.path.join(self.metadata_folder, f)) 
                               for f in os.listdir(self.metadata_folder) if f.endswith('.json')], default=0)
            
            if latest_update <= self._index_last_updated:
                return self._index_cache
        
        # 重建索引
        metadata_list = []
        
        for filename in os.listdir(self.metadata_folder):
            if filename.endswith('.json'):
                metadata_path = os.path.join(self.metadata_folder, filename)
                
                try:
                    with open(metadata_path, 'r', encoding='utf-8') as f:
                        metadata = json.load(f)
                        metadata_list.append(metadata)
                except Exception as e:
                    print(f"Error loading metadata file {filename}: {str(e)}")
        
        # 更新索引緩存
        self._index_cache = metadata_list
        self._index_last_updated = datetime.datetime.now().timestamp()
        
        return metadata_list
    
    def _invalidate_index(self):
        """使索引緩存失效"""
        self._index_cache = None
        self._index_last_updated = None
    
    def _apply_filters(self, metadata_list, filters):
        """應用過濾條件
        
        Args:
            metadata_list: 元數據列表
            filters: 過濾條件字典
            
        Returns:
            過濾後的元數據列表
        """
        if not filters:
            return metadata_list
        
        results = []
        
        for metadata in metadata_list:
            match = True
            
            for key, value in filters.items():
                # 處理特殊過濾器
                if key == 'tags' and isinstance(value, list):
                    # 標籤過濾器（任何一個標籤匹配）
                    if not any(tag in metadata.get('tags', []) for tag in value):
                        match = False
                        break
                
                elif key == 'all_tags' and isinstance(value, list):
                    # 標籤過濾器（所有標籤都必須匹配）
                    if not all(tag in metadata.get('tags', []) for tag in value):
                        match = False
                        break
                
                elif key == 'categories' and isinstance(value, list):
                    # 分類過濾器
                    if not any(category in metadata.get('categories', []) for category in value):
                        match = False
                        break
                
                elif key == 'created_after' and isinstance(value, str):
                    # 創建日期過濾器
                    if 'created_at' not in metadata or metadata['created_at'] < value:
                        match = False
                        break
                
                elif key == 'created_before' and isinstance(value, str):
                    # 創建日期過濾器
                    if 'created_at' not in metadata or metadata['created_at'] > value:
                        match = False
                        break
                
                elif key == 'updated_after' and isinstance(value, str):
                    # 更新日期過濾器
                    if 'updated_at' not in metadata or metadata['updated_at'] < value:
                        match = False
                        break
                
                elif key == 'updated_before' and isinstance(value, str):
                    # 更新日期過濾器
                    if 'updated_at' not in metadata or metadata['updated_at'] > value:
                        match = False
                        break
                
                elif key in metadata:
                    # 一般過濾器
                    if isinstance(value, list):
                        if metadata[key] not in value:
                            match = False
                            break
                    elif metadata[key] != value:
                        match = False
                        break
                
                else:
                    # 字段不存在
                    match = False
                    break
            
            if match:
                results.append(metadata)
        
        return results
    
    def _apply_search(self, metadata_list, query):
        """應用搜索查詢
        
        Args:
            metadata_list: 元數據列表
            query: 搜索關鍵詞
            
        Returns:
            搜索結果
        """
        if not query:
            return metadata_list
        
        query = query.lower()
        results = []
        
        for metadata in metadata_list:
            # 搜索標題
            if 'title' in metadata and query in metadata['title'].lower():
                results.append(metadata)
                continue
            
            # 搜索描述
            if 'description' in metadata and metadata['description'] and query in metadata['description'].lower():
                results.append(metadata)
                continue
            
            # 搜索作者
            if 'author' in metadata and metadata['author'] and query in metadata['author'].lower():
                results.append(metadata)
                continue
            
            # 搜索標籤
            if 'tags' in metadata and any(query in tag.lower() for tag in metadata['tags']):
                results.append(metadata)
                continue
            
            # 搜索分類
            if 'categories' in metadata and any(query in category.lower() for category in metadata['categories']):
                results.append(metadata)
                continue
        
        return results
    
    def _apply_sorting(self, metadata_list, sort_by, sort_order):
        """應用排序
        
        Args:
            metadata_list: 元數據列表
            sort_by: 排序字段
            sort_order: 排序順序 ('asc' 或 'desc')
            
        Returns:
            排序後的元數據列表
        """
        reverse = sort_order.lower() == 'desc'
        
        # 定義排序鍵函數
        def sort_key(metadata):
            if sort_by in metadata:
                return metadata[sort_by]
            return '' if reverse else 'zzzzzzzzz'  # 確保缺少排序字段的項目排在最後
        
        # 應用排序
        return sorted(metadata_list, key=sort_key, reverse=reverse)
    
    def _generate_tags(self, metadata):
        """根據元數據自動生成標籤
        
        Args:
            metadata: 元數據字典
            
        Returns:
            生成的標籤列表
        """
        tags = []
        
        # 從FAB生成標籤
        if 'fab' in metadata and metadata['fab']:
            tags.append(metadata['fab'])
        
        # 從產品生成標籤
        if 'product' in metadata and metadata['product']:
            tags.append(metadata['product'])
        
        # 從標題生成標籤
        if 'title' in metadata and metadata['title']:
            # 提取標題中的關鍵詞
            words = re.findall(r'\b\w+\b', metadata['title'])
            for word in words:
                if len(word) > 3 and word.lower() not in ['the', 'and', 'for', 'with']:
                    tags.append(word)
        
        # 從文件類型生成標籤
        if 'file_type' in metadata and metadata['file_type']:
            tags.append(f"format:{metadata['file_type']}")
        
        return tags[:10]  # 限制標籤數量
