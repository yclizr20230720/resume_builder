# SOP執行系統安裝指南

## 系統需求
- Windows 11操作系統
- Python 3.8或更高版本
- Jupyter Notebook

## 安裝步驟

### 1. 安裝Python
如果尚未安裝Python，請從[Python官網](https://www.python.org/downloads/)下載並安裝Python 3.8或更高版本。
安裝時請勾選"Add Python to PATH"選項。

### 2. 安裝依賴包
打開命令提示符(CMD)，切換到部署包目錄，執行以下命令：
```
pip install -r requirements.txt
```

### 3. 配置系統
編輯`config.json`文件，根據需要修改以下配置：
- `windows_root`: Windows根目錄，默認為"D:\"
- `base_dir`: 系統基礎目錄，默認為"D:\sop_system"
- `jupyter_server`: Jupyter服務器地址，默認為"http://localhost:8888"
- `debug`: 是否啟用調試模式，默認為false
- `port`: 服務器端口，默認為5000
- `host`: 服務器主機，默認為"0.0.0.0"

### 4. 啟動Jupyter Notebook
打開命令提示符(CMD)，執行以下命令：
```
jupyter notebook
```

### 5. 啟動SOP執行系統
打開另一個命令提示符(CMD)，切換到部署包目錄，執行以下命令：
```
python app.py
```

### 6. 訪問系統
打開瀏覽器，訪問以下地址：
```
http://localhost:5000
```

## 常見問題

### 1. 無法啟動系統
- 確保Python已正確安裝並添加到PATH
- 確保所有依賴包已正確安裝
- 檢查端口5000是否被其他程序佔用

### 2. 無法執行SOP
- 確保Jupyter Notebook已啟動
- 確保config.json中的jupyter_server配置正確
- 檢查Jupyter Notebook是否可以通過瀏覽器訪問

### 3. 文件上傳失敗
- 確保上傳目錄具有寫入權限
- 檢查文件大小是否超過限制

## 聯繫支持
如有任何問題，請聯繫系統管理員或發送郵件至support@example.com
