import os
import json
import uuid
import datetime
import shutil
import nbformat
from werkzeug.utils import secure_filename

class SopValidator:
    """SOP驗證系統，用於驗證SOP文件的格式和內容"""
    
    def __init__(self, allowed_extensions=None):
        self.allowed_extensions = allowed_extensions or {'md', 'txt', 'ipynb', 'py', 'json'}
    
    def validate_file_extension(self, filename):
        """驗證文件擴展名是否允許"""
        return '.' in filename and filename.rsplit('.', 1)[1].lower() in self.allowed_extensions
    
    def validate_content(self, content, file_type):
        """驗證SOP內容"""
        errors = []
        warnings = []
        
        # 基本內容驗證
        if len(content) < 50:
            warnings.append('SOP內容過短，建議提供更詳細的說明')
        
        # 根據文件類型進行特定驗證
        if file_type == 'md':
            # Markdown文件驗證
            if '# ' not in content:
                errors.append('缺少標題（使用#開頭的標題）')
            
            if '```' not in content:
                warnings.append('未發現代碼塊，SOP可能缺少可執行代碼')
            
            # 檢查是否有步驟列表
            if '1. ' not in content and '- ' not in content:
                warnings.append('未發現列表或步驟，建議使用有序列表描述操作步驟')
        
        elif file_type == 'ipynb':
            # Jupyter Notebook驗證
            try:
                notebook = json.loads(content)
                
                # 檢查是否有單元格
                if 'cells' not in notebook or len(notebook['cells']) == 0:
                    errors.append('Notebook不包含任何單元格')
                
                # 檢查是否有代碼單元格
                has_code_cell = False
                for cell in notebook.get('cells', []):
                    if cell.get('cell_type') == 'code':
                        has_code_cell = True
                        break
                
                if not has_code_cell:
                    warnings.append('Notebook不包含代碼單元格，可能無法執行操作')
                
            except json.JSONDecodeError:
                errors.append('無效的Jupyter Notebook格式')
        
        elif file_type == 'py':
            # Python文件驗證
            if 'def ' not in content and 'class ' not in content:
                warnings.append('Python文件未包含函數或類定義')
            
            if '# ' not in content:
                warnings.append('Python文件缺少註釋，建議添加註釋以提高可讀性')
        
        return {
            'valid': len(errors) == 0,
            'errors': errors,
            'warnings': warnings
        }
    
    def validate_metadata(self, metadata):
        """驗證SOP元數據"""
        errors = []
        warnings = []
        
        # 檢查必要字段
        required_fields = ['title', 'author', 'fab', 'product']
        for field in required_fields:
            if field not in metadata or not metadata[field]:
                errors.append(f'缺少必要的元數據字段：{field}')
        
        # 檢查描述
        if 'description' not in metadata or len(metadata.get('description', '')) < 10:
            warnings.append('描述過短，建議提供更詳細的SOP描述')
        
        return {
            'valid': len(errors) == 0,
            'errors': errors,
            'warnings': warnings
        }

class VersionControl:
    """SOP版本控制系統"""
    
    def __init__(self, versions_folder):
        self.versions_folder = versions_folder
        os.makedirs(versions_folder, exist_ok=True)
    
    def create_version(self, sop_id, file_path, version=None):
        """創建新版本"""
        # 確保SOP的版本目錄存在
        sop_version_folder = os.path.join(self.versions_folder, sop_id)
        os.makedirs(sop_version_folder, exist_ok=True)
        
        # 如果未指定版本，則自動計算下一個版本號
        if version is None:
            version = self._get_next_version(sop_id)
        
        # 獲取原始文件名
        original_filename = os.path.basename(file_path)
        
        # 創建版本文件名
        version_filename = f"v{version}_{original_filename}"
        version_path = os.path.join(sop_version_folder, version_filename)
        
        # 複製文件到版本目錄
        shutil.copy2(file_path, version_path)
        
        return {
            'version': version,
            'filename': version_filename,
            'path': version_path,
            'created_at': datetime.datetime.now().isoformat()
        }
    
    def get_versions(self, sop_id):
        """獲取SOP的所有版本"""
        sop_version_folder = os.path.join(self.versions_folder, sop_id)
        if not os.path.exists(sop_version_folder):
            return []
        
        versions = []
        for filename in os.listdir(sop_version_folder):
            if filename.startswith('v'):
                # 提取版本號
                version_str = filename.split('_')[0][1:]
                
                versions.append({
                    'version': version_str,
                    'filename': filename,
                    'path': os.path.join(sop_version_folder, filename),
                    'created_at': datetime.datetime.fromtimestamp(
                        os.path.getctime(os.path.join(sop_version_folder, filename))
                    ).isoformat()
                })
        
        # 按版本號排序
        versions.sort(key=lambda x: float(x['version']), reverse=True)
        
        return versions
    
    def get_version(self, sop_id, version):
        """獲取特定版本的SOP"""
        sop_version_folder = os.path.join(self.versions_folder, sop_id)
        if not os.path.exists(sop_version_folder):
            return None
        
        # 查找匹配的版本文件
        for filename in os.listdir(sop_version_folder):
            if filename.startswith(f'v{version}_'):
                version_path = os.path.join(sop_version_folder, filename)
                
                with open(version_path, 'r') as f:
                    content = f.read()
                
                return {
                    'version': version,
                    'filename': filename,
                    'path': version_path,
                    'content': content,
                    'created_at': datetime.datetime.fromtimestamp(
                        os.path.getctime(version_path)
                    ).isoformat()
                }
        
        return None
    
    def compare_versions(self, sop_id, version1, version2):
        """比較兩個版本的差異"""
        v1 = self.get_version(sop_id, version1)
        v2 = self.get_version(sop_id, version2)
        
        if not v1 or not v2:
            return None
        
        # 這裡可以實現更複雜的差異比較邏輯
        # 簡單起見，我們只返回兩個版本的內容
        return {
            'version1': {
                'version': version1,
                'content': v1['content']
            },
            'version2': {
                'version': version2,
                'content': v2['content']
            }
        }
    
    def _get_next_version(self, sop_id):
        """獲取下一個版本號"""
        versions = self.get_versions(sop_id)
        
        if not versions:
            return '1.0'
        
        # 獲取最新版本號
        latest_version = float(versions[0]['version'])
        
        # 增加0.1作為新版本號
        return str(latest_version + 0.1)

class MetadataManager:
    """SOP元數據管理系統"""
    
    def __init__(self, metadata_folder):
        self.metadata_folder = metadata_folder
        os.makedirs(metadata_folder, exist_ok=True)
    
    def create_metadata(self, sop_id, data):
        """創建SOP元數據"""
        # 基本元數據
        metadata = {
            'id': sop_id,
            'created_at': datetime.datetime.now().isoformat(),
            'updated_at': datetime.datetime.now().isoformat(),
            'version': '1.0',
            'status': 'draft'
        }
        
        # 合併用戶提供的數據
        metadata.update(data)
        
        # 保存元數據
        self._save_metadata(sop_id, metadata)
        
        return metadata
    
    def get_metadata(self, sop_id):
        """獲取SOP元數據"""
        metadata_path = os.path.join(self.metadata_folder, f"{sop_id}.json")
        if not os.path.exists(metadata_path):
            return None
        
        with open(metadata_path, 'r') as f:
            return json.load(f)
    
    def update_metadata(self, sop_id, data):
        """更新SOP元數據"""
        metadata = self.get_metadata(sop_id)
        if not metadata:
            return None
        
        # 更新元數據
        metadata.update(data)
        metadata['updated_at'] = datetime.datetime.now().isoformat()
        
        # 保存更新後的元數據
        self._save_metadata(sop_id, metadata)
        
        return metadata
    
    def search_metadata(self, query=None, filters=None):
        """搜索SOP元數據"""
        results = []
        
        # 遍歷所有元數據文件
        for filename in os.listdir(self.metadata_folder):
            if filename.endswith('.json'):
                with open(os.path.join(self.metadata_folder, filename), 'r') as f:
                    metadata = json.load(f)
                
                # 應用過濾器
                if filters:
                    skip = False
                    for key, value in filters.items():
                        if key in metadata and metadata[key] != value:
                            skip = True
                            break
                    
                    if skip:
                        continue
                
                # 應用搜索查詢
                if query:
                    query = query.lower()
                    found = False
                    
                    # 搜索標題、描述和作者
                    searchable_fields = ['title', 'description', 'author']
                    for field in searchable_fields:
                        if field in metadata and query in metadata[field].lower():
                            found = True
                            break
                    
                    if not found:
                        continue
                
                results.append(metadata)
        
        # 按更新時間排序
        results.sort(key=lambda x: x.get('updated_at', ''), reverse=True)
        
        return results
    
    def delete_metadata(self, sop_id):
        """刪除SOP元數據"""
        metadata_path = os.path.join(self.metadata_folder, f"{sop_id}.json")
        if os.path.exists(metadata_path):
            os.remove(metadata_path)
            return True
        
        return False
    
    def _save_metadata(self, sop_id, metadata):
        """保存元數據到文件"""
        metadata_path = os.path.join(self.metadata_folder, f"{sop_id}.json")
        with open(metadata_path, 'w') as f:
            json.dump(metadata, f, indent=2)

class SopManager:
    """SOP管理系統，整合驗證、版本控制和元數據管理"""
    
    def __init__(self, base_folder):
        # 設置各個目錄
        self.base_folder = base_folder
        self.upload_folder = os.path.join(base_folder, 'uploads')
        self.notebooks_folder = os.path.join(base_folder, 'notebooks')
        self.versions_folder = os.path.join(base_folder, 'versions')
        self.metadata_folder = os.path.join(base_folder, 'metadata')
        
        # 確保目錄存在
        for folder in [self.upload_folder, self.notebooks_folder, self.versions_folder, self.metadata_folder]:
            os.makedirs(folder, exist_ok=True)
        
        # 初始化子系統
        self.validator = SopValidator()
        self.version_control = VersionControl(self.versions_folder)
        self.metadata_manager = MetadataManager(self.metadata_folder)
    
    def create_sop_from_file(self, file, metadata):
        """從文件創建SOP"""
        # 驗證文件
        if not self.validator.validate_file_extension(file.filename):
            return {
                'success': False,
                'error': '不支持的文件格式'
            }
        
        # 讀取文件內容進行驗證
        content = file.read().decode('utf-8')
        file.seek(0)  # 重置文件指針
        
        file_type = file.filename.rsplit('.', 1)[1].lower()
        validation_result = self.validator.validate_content(content, file_type)
        
        # 驗證元數據
        metadata_validation = self.validator.validate_metadata(metadata)
        
        # 如果有嚴重錯誤，返回驗證結果
        if not validation_result['valid'] or not metadata_validation['valid']:
            return {
                'success': False,
                'validation': validation_result,
                'metadata_validation': metadata_validation
            }
        
        # 生成唯一ID
        sop_id = str(uuid.uuid4())
        
        # 保存文件
        filename = secure_filename(file.filename)
        file_path = os.path.join(self.upload_folder, f"{sop_id}_{filename}")
        file.save(file_path)
        
        # 更新元數據
        metadata['filename'] = f"{sop_id}_{filename}"
        metadata['file_type'] = file_type
        
        # 創建元數據
        self.metadata_manager.create_metadata(sop_id, metadata)
        
        # 創建初始版本
        self.version_control.create_version(sop_id, file_path)
        
        # 如果是Jupyter Notebook，直接使用
        # 否則，創建關聯的Notebook
        if file_type == 'ipynb':
            shutil.copy2(file_path, os.path.join(self.notebooks_folder, f"{sop_id}.ipynb"))
        else:
            self._generate_notebook(sop_id, content, metadata)
        
        return {
            'success': True,
            'sop_id': sop_id,
            'validation': validation_result,
            'metadata_validation': metadata_validation
        }
    
    def create_sop_from_content(self, content, metadata, file_type='md'):
        """從內容創建SOP"""
        # 驗證內容
        validation_result = self.validator.validate_content(content, file_type)
        
        # 驗證元數據
        metadata_validation = self.validator.validate_metadata(metadata)
        
        # 如果有嚴重錯誤，返回驗證結果
        if not validation_result['valid'] or not metadata_validation['valid']:
            return {
                'success': False,
                'validation': validation_result,
                'metadata_validation': metadata_validation
            }
        
        # 生成唯一ID
        sop_id = str(uuid.uuid4())
        
        # 創建文件
        filename = f"{sop_id}.{file_type}"
        file_path = os.path.join(self.upload_folder, filename)
        with open(file_path, 'w') as f:
            f.write(content)
        
        # 更新元數據
        metadata['filename'] = filename
        metadata['file_type'] = file_type
        
        # 創建元數據
        self.metadata_manager.create_metadata(sop_id, metadata)
        
        # 創建初始版本
        self.version_control.create_version(sop_id, file_path)
        
        # 創建關聯的Notebook
        self._generate_notebook(sop_id, content, metadata)
        
        return {
            'success': True,
            'sop_id': sop_id,
            'validation': validation_result,
            'metadata_validation': metadata_validation
        }
    
    def update_sop(self, sop_id, content=None, file=None, metadata=None):
        """更新SOP"""
        # 檢查SOP是否存在
        existing_metadata = self.metadata_manager.get_metadata(sop_id)
        if not existing_metadata:
            return {
                'success': False,
                'error': 'SOP不存在'
            }
        
        # 獲取當前版本號
        current_version = existing_metadata.get('version', '1.0')
        
        # 更新內容
        if content or file:
            if file:
                # 驗證文件
                if not self.validator.validate_file_extension(file.filename):
                    return {
                        'success': False,
                        'error': '不支持的文件格式'
                    }
                
                # 讀取文件內容進行驗證
                file_content = file.read().decode('utf-8')
                file.seek(0)  # 重置文件指針
                
                file_type = file.filename.rsplit('.', 1)[1].lower()
                validation_result = self.validator.validate_content(file_content, file_type)
                
                # 如果有嚴重錯誤，返回驗證結果
                if not validation_result['valid']:
                    return {
                        'success': False,
                        'validation': validation_result
                    }
                
                # 保存文件
                filename = secure_filename(file.filename)
                file_path = os.path.join(self.upload_folder, f"{sop_id}_{filename}")
                file.save(file_path)
                
                # 更新元數據
                if metadata is None:
                    metadata = {}
                
                metadata['filename'] = f"{sop_id}_{filename}"
                metadata['file_type'] = file_type
                
                # 創建新版本
                version_info = self.version_control.create_version(sop_id, file_path)
                
                # 更新元數據中的版本號
                metadata['version'] = version_info['version']
                
                # 如果是Jupyter Notebook，直接使用
                # 否則，更新關聯的Notebook
                if file_type == 'ipynb':
                    shutil.copy2(file_path, os.path.join(self.notebooks_folder, f"{sop_id}.ipynb"))
                else:
                    self._generate_notebook(sop_id, file_content, existing_metadata)
            
            elif content:
                # 獲取文件類型
                file_type = existing_metadata.get('file_type', 'md')
                
                # 驗證內容
                validation_result = self.validator.validate_content(content, file_type)
                
                # 如果有嚴重錯誤，返回驗證結果
                if not validation_result['valid']:
                    return {
                        'success': False,
                        'validation': validation_result
                    }
                
                # 獲取原始文件名
                filename = existing_metadata.get('filename', f"{sop_id}.{file_type}")
                
                # 保存更新的內容
                file_path = os.path.join(self.upload_folder, filename)
                with open(file_path, 'w') as f:
                    f.write(content)
                
                # 創建新版本
                version_info = self.version_control.create_version(sop_id, file_path)
                
                # 更新元數據中的版本號
                if metadata is None:
                    metadata = {}
                
                metadata['version'] = version_info['version']
                
                # 更新關聯的Notebook
                self._generate_notebook(sop_id, content, existing_metadata)
        
        # 更新元數據
        if metadata:
            self.metadata_manager.update_metadata(sop_id, metadata)
        
        return {
            'success': True,
            'sop_id': sop_id,
            'version': metadata.get('version', current_version) if metadata else current_version
        }
    
    def get_sop(self, sop_id):
        """獲取SOP信息"""
        # 獲取元數據
        metadata = self.metadata_manager.get_metadata(sop_id)
        if not metadata:
            return None
        
        # 獲取SOP內容
        filename = metadata.get('filename')
        if not filename:
            return {
                'metadata': metadata,
                'content': None,
                'notebook': None,
                'versions': []
            }
        
        file_path = os.path.join(self.upload_folder, filename)
        content = None
        if os.path.exists(file_path):
            with open(file_path, 'r') as f:
                content = f.read()
        
        # 獲取關聯的Notebook
        notebook_path = os.path.join(self.notebooks_folder, f"{sop_id}.ipynb")
        notebook = None
        if os.path.exists(notebook_path):
            with open(notebook_path, 'r') as f:
                notebook = json.load(f)
        
        # 獲取版本歷史
        versions = self.version_control.get_versions(sop_id)
        
        return {
            'metadata': metadata,
            'content': content,
            'notebook': notebook,
            'versions': versions
        }
    
    def delete_sop(self, sop_id):
        """刪除SOP"""
        # 獲取元數據
        metadata = self.metadata_manager.get_metadata(sop_id)
        if not metadata:
            return False
        
        # 刪除SOP文件
        filename = metadata.get('filename')
        if filename:
            file_path = os.path.join(self.upload_folder, filename)
            if os.path.exists(file_path):
                os.remove(file_path)
        
        # 刪除Notebook
        notebook_path = os.path.join(self.notebooks_folder, f"{sop_id}.ipynb")
        if os.path.exists(notebook_path):
            os.remove(notebook_path)
        
        # 刪除版本歷史
        version_folder = os.path.join(self.versions_folder, sop_id)
        if os.path.exists(version_folder):
            shutil.rmtree(version_folder)
        
        # 刪除元數據
        self.metadata_manager.delete_metadata(sop_id)
        
        return True
    
    def search_sops(self, query=None, filters=None):
        """搜索SOPs"""
        return self.metadata_manager.search_metadata(query, filters)
    
    def _generate_notebook(self, sop_id, content, metadata):
        """根據SOP內容生成Jupyter Notebook"""
        notebook = nbformat.v4.new_notebook()
        cells = []
        
        # 添加標題和描述
        title = metadata.get('title', 'Untitled SOP')
        description = metadata.get('description', '')
        
        cells.append(nbformat.v4.new_markdown_cell(f"# {title}\n\n{description}"))
        
        # 處理不同類型的SOP內容
        file_type = metadata.get('file_type', 'md')
        
        if file_type == 'md':
            # 解析Markdown內容
            sections = content.split('\n## ')
            
            # 處理第一部分（可能包含主標題）
            first_section = sections[0]
            if first_section.startswith('# '):
                first_section = first_section.split('\n', 1)[1] if '\n' in first_section else ''
            
            if first_section.strip():
                cells.append(nbformat.v4.new_markdown_cell(first_section))
            
            # 處理其餘部分
            for i, section in enumerate(sections[1:], 1):
                section_title = section.split('\n', 1)[0] if '\n' in section else section
                section_content = section.split('\n', 1)[1] if '\n' in section else ''
                
                cells.append(nbformat.v4.new_markdown_cell(f"## {section_title}"))
                
                # 提取代碼塊
                code_blocks = []
                in_code_block = False
                current_block = []
                
                for line in section_content.split('\n'):
                    if line.startswith('```'):
                        if in_code_block:
                            # 結束代碼塊
                            in_code_block = False
                            code_blocks.append('\n'.join(current_block))
                            current_block = []
                        else:
                            # 開始代碼塊
                            in_code_block = True
                            # 跳過語言標識行
                            continue
                    elif in_code_block:
                        current_block.append(line)
                
                # 添加Markdown內容（不包括代碼塊）
                markdown_content = section_content
                for code_block in code_blocks:
                    markdown_content = markdown_content.replace(f"```\n{code_block}\n```", '')
                    markdown_content = markdown_content.replace(f"```python\n{code_block}\n```", '')
                
                if markdown_content.strip():
                    cells.append(nbformat.v4.new_markdown_cell(markdown_content))
                
                # 添加代碼塊
                for code_block in code_blocks:
                    cells.append(nbformat.v4.new_code_cell(code_block))
        
        elif file_type == 'py':
            # 將Python文件轉換為Notebook
            # 解析註釋和代碼
            lines = content.split('\n')
            current_comment = []
            current_code = []
            
            for line in lines:
                if line.strip().startswith('#'):
                    # 如果有累積的代碼，先添加代碼單元格
                    if current_code:
                        cells.append(nbformat.v4.new_code_cell('\n'.join(current_code)))
                        current_code = []
                    
                    # 收集註釋
                    current_comment.append(line.strip()[1:].strip())
                else:
                    # 如果有累積的註釋，先添加Markdown單元格
                    if current_comment:
                        cells.append(nbformat.v4.new_markdown_cell('\n'.join(current_comment)))
                        current_comment = []
                    
                    # 收集代碼
                    if line.strip():
                        current_code.append(line)
            
            # 處理最後的註釋或代碼
            if current_comment:
                cells.append(nbformat.v4.new_markdown_cell('\n'.join(current_comment)))
            
            if current_code:
                cells.append(nbformat.v4.new_code_cell('\n'.join(current_code)))
        
        # 將單元格添加到Notebook
        notebook.cells = cells
        
        # 保存Notebook
        notebook_path = os.path.join(self.notebooks_folder, f"{sop_id}.ipynb")
        with open(notebook_path, 'w') as f:
            nbformat.write(notebook, f)
        
        return notebook_path
