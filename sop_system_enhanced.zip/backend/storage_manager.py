import os
import datetime
import re
from werkzeug.utils import secure_filename

class StorageManager:
    """管理SOP文件的存儲結構和命名規則"""
    
    def __init__(self, base_folder):
        """初始化存儲管理器
        
        Args:
            base_folder: 基礎存儲目錄
        """
        self.base_folder = base_folder
        
        # 確保基礎目錄存在
        os.makedirs(base_folder, exist_ok=True)
        
        # FAB和產品列表
        self.fab_list = ['FAB12', 'FAB14', 'FAB15', 'FAB18', 'ENT', 'FOC']
        self.product_list = ['ELFM', 'EMP', 'OWMS', 'MPCS']
    
    def get_storage_path(self, fab, product):
        """獲取特定FAB和產品的存儲路徑
        
        Args:
            fab: FAB名稱 (例如 'FAB12')
            product: 產品名稱 (例如 'EMP')
            
        Returns:
            存儲路徑
        """
        # 驗證FAB和產品
        if fab not in self.fab_list and fab != 'Other':
            raise ValueError(f"無效的FAB: {fab}. 有效選項: {', '.join(self.fab_list)}")
        
        if product not in self.product_list and product != 'Other':
            raise ValueError(f"無效的產品: {product}. 有效選項: {', '.join(self.product_list)}")
        
        # 創建路徑
        path = os.path.join(self.base_folder, fab, product)
        
        # 確保目錄存在
        os.makedirs(path, exist_ok=True)
        
        return path
    
    def generate_filename(self, fab, product, sop_name, file_extension, timestamp=None):
        """生成符合命名規則的文件名
        
        Args:
            fab: FAB名稱 (例如 'FAB12')
            product: 產品名稱 (例如 'EMP')
            sop_name: SOP名稱
            file_extension: 文件擴展名 (不含點)
            timestamp: 可選的時間戳，如果未提供則使用當前時間
            
        Returns:
            生成的文件名
        """
        # 清理SOP名稱，移除特殊字符並替換空格為下劃線
        clean_sop_name = re.sub(r'[^\w\s-]', '', sop_name).strip().replace(' ', '_')
        
        # 獲取時間戳
        if timestamp is None:
            timestamp = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        
        # 生成文件名: FABXX_System_SOPName_DateTime.extension
        filename = f"{fab}_{product}_{clean_sop_name}_{timestamp}.{file_extension}"
        
        return filename
    
    def save_file(self, file_obj, fab, product, sop_name, original_filename=None):
        """保存上傳的文件
        
        Args:
            file_obj: 文件對象或文件內容
            fab: FAB名稱
            product: 產品名稱
            sop_name: SOP名稱
            original_filename: 原始文件名，用於確定文件類型
            
        Returns:
            保存的文件路徑和文件名
        """
        # 獲取存儲路徑
        storage_path = self.get_storage_path(fab, product)
        
        # 確定文件擴展名
        if original_filename:
            file_extension = original_filename.rsplit('.', 1)[1].lower() if '.' in original_filename else 'txt'
        else:
            file_extension = 'txt'
        
        # 生成文件名
        filename = self.generate_filename(fab, product, sop_name, file_extension)
        
        # 完整文件路徑
        file_path = os.path.join(storage_path, filename)
        
        # 保存文件
        if hasattr(file_obj, 'read'):
            # 如果是文件對象
            file_obj.save(file_path)
        else:
            # 如果是文件內容
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(file_obj)
        
        return {
            'path': file_path,
            'filename': filename,
            'relative_path': os.path.join(fab, product, filename)
        }
    
    def get_file_path(self, fab, product, filename):
        """獲取文件的完整路徑
        
        Args:
            fab: FAB名稱
            product: 產品名稱
            filename: 文件名
            
        Returns:
            文件的完整路徑
        """
        return os.path.join(self.base_folder, fab, product, filename)
    
    def list_files(self, fab=None, product=None):
        """列出指定FAB和產品下的所有文件
        
        Args:
            fab: 可選的FAB名稱過濾
            product: 可選的產品名稱過濾
            
        Returns:
            文件列表
        """
        files = []
        
        # 確定要搜索的目錄
        if fab and product:
            # 特定FAB和產品
            search_dirs = [os.path.join(self.base_folder, fab, product)]
        elif fab:
            # 特定FAB的所有產品
            search_dirs = []
            fab_dir = os.path.join(self.base_folder, fab)
            if os.path.exists(fab_dir):
                for prod in os.listdir(fab_dir):
                    prod_path = os.path.join(fab_dir, prod)
                    if os.path.isdir(prod_path):
                        search_dirs.append(prod_path)
        else:
            # 所有FAB和產品
            search_dirs = []
            for root, dirs, _ in os.walk(self.base_folder):
                for dir_name in dirs:
                    search_dirs.append(os.path.join(root, dir_name))
        
        # 搜索文件
        for directory in search_dirs:
            if os.path.exists(directory):
                for filename in os.listdir(directory):
                    file_path = os.path.join(directory, filename)
                    if os.path.isfile(file_path):
                        # 解析文件名以提取元數據
                        parts = filename.split('_')
                        if len(parts) >= 4:
                            file_fab = parts[0]
                            file_product = parts[1]
                            # 最後一部分包含日期時間和擴展名
                            datetime_ext = parts[-1]
                            datetime_part = datetime_ext.rsplit('.', 1)[0]
                            extension = datetime_ext.rsplit('.', 1)[1] if '.' in datetime_ext else ''
                            
                            # SOP名稱可能包含多個部分
                            sop_name = '_'.join(parts[2:-1])
                            
                            files.append({
                                'filename': filename,
                                'path': file_path,
                                'fab': file_fab,
                                'product': file_product,
                                'sop_name': sop_name,
                                'datetime': datetime_part,
                                'extension': extension,
                                'relative_path': os.path.relpath(file_path, self.base_folder)
                            })
        
        return files
