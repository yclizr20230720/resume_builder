import os
import sys
from flask import Flask, request, jsonify, render_template, redirect, url_for
import json
import datetime
import shutil
from werkzeug.utils import secure_filename

# Add the parent directory to the path to import backend modules
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import enhanced backend components
from backend.storage_manager import StorageManager
from backend.document_converter import DocumentConverter
from backend.version_control import VersionControl
from backend.metadata_processor import MetadataProcessor
from backend.sop_integration import SopIntegration

app = Flask(__name__)

# Base directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Initialize SOP integration system
sop_system = SopIntegration(BASE_DIR)

# 允許的文件擴展名
ALLOWED_EXTENSIONS = {'md', 'txt', 'ipynb', 'py', 'json', 'doc', 'docx'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# 路由
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/sop/list')
def sop_list():
    # 獲取過濾參數
    fab = request.args.get('fab', '')
    product = request.args.get('product', '')
    
    # 使用SOP整合系統列出SOPs
    sops = sop_system.list_sops(fab if fab else None, product if product else None)
    
    # 提取元數據列表
    metadata_list = [sop.get('metadata', {}) for sop in sops]
    
    return render_template('sop_list.html', sops=metadata_list)

@app.route('/sop/view/<sop_id>')
def sop_view(sop_id):
    # 使用SOP整合系統獲取SOP
    sop = sop_system.get_sop(sop_id)
    if not sop:
        return "SOP not found", 404
    
    return render_template('sop_view.html', 
                          metadata=sop.get('metadata', {}), 
                          sop_content=sop.get('content', ''), 
                          notebook_content=sop.get('notebook', {}))

@app.route('/sop/create', methods=['GET', 'POST'])
def sop_create():
    if request.method == 'GET':
        return render_template('sop_create.html')
    
    # 處理POST請求（創建SOP）
    if request.method == 'POST':
        # 獲取表單數據
        data = request.form
        upload_type = data.get('upload_type', 'file')
        
        # 處理FAB和產品字段
        fab = data.get('fab_custom') if data.get('fab_custom_check') == 'on' else data.get('fab')
        product = data.get('product_custom') if data.get('product_custom_check') == 'on' else data.get('product')
        
        # 創建元數據
        metadata = {
            'title': data.get('title', 'Untitled SOP'),
            'description': data.get('description', ''),
            'author': data.get('author', 'Anonymous'),
            'fab': fab,
            'product': product,
            'status': 'draft'
        }
        
        # 處理文件上傳或內容創建
        if upload_type == 'file':
            # 檢查是否有文件
            if 'file' not in request.files:
                return "No file part", 400
            
            file = request.files['file']
            if file.filename == '':
                return "No selected file", 400
            
            if file and allowed_file(file.filename):
                # 使用SOP整合系統創建SOP
                result = sop_system.create_sop_from_file(file, metadata)
                
                if result.get('success'):
                    return redirect(url_for('sop_view', sop_id=result.get('sop_id')))
                else:
                    return f"Error creating SOP: {result.get('error')}", 400
            else:
                return "File type not allowed", 400
        else:  # 從URL或編輯器創建
            content = data.get('content', '')
            url = data.get('url', '')
            
            if url:
                # 從URL創建SOP
                result = sop_system.create_sop_from_url(url, metadata)
                
                if result.get('success'):
                    return redirect(url_for('sop_view', sop_id=result.get('sop_id')))
                else:
                    return f"Error creating SOP from URL: {result.get('error')}", 400
            elif content:
                # 使用SOP整合系統從內容創建SOP
                result = sop_system.create_sop_from_content(content, metadata)
                
                if result.get('success'):
                    return redirect(url_for('sop_view', sop_id=result.get('sop_id')))
                else:
                    return f"Error creating SOP: {result.get('error')}", 400
            else:
                return "Content or URL is required", 400

@app.route('/api/sop/validate', methods=['POST'])
def validate_sop():
    """驗證SOP格式和內容"""
    if 'file' not in request.files:
        return jsonify({'valid': False, 'errors': ['No file provided']}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'valid': False, 'errors': ['Empty filename']}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'valid': False, 'errors': [f'File type not allowed. Allowed types: {", ".join(ALLOWED_EXTENSIONS)}']}), 400
    
    # 讀取文件內容進行驗證
    content = file.read().decode('utf-8')
    file.seek(0)  # 重置文件指針以便後續處理
    
    # 使用SOP整合系統的驗證功能
    file_type = file.filename.rsplit('.', 1)[1].lower()
    
    # 簡單驗證邏輯
    errors = []
    warnings = []
    
    if len(content) < 10:
        errors.append('Content too short')
    
    if '```' not in content and file_type == 'md':
        warnings.append('No code blocks found in markdown')
    
    # 返回驗證結果
    valid = len(errors) == 0
    return jsonify({
        'valid': valid,
        'errors': errors,
        'warnings': warnings
    })

@app.route('/api/sop/versions/<sop_id>', methods=['GET'])
def get_sop_versions(sop_id):
    """獲取SOP的版本歷史"""
    # 使用版本控制系統獲取版本
    versions = sop_system.version_control.get_versions(sop_id)
    
    if not versions:
        return jsonify([])
    
    return jsonify(versions)

@app.route('/api/sop/version/<sop_id>/<version>', methods=['GET'])
def get_sop_version(sop_id, version):
    """獲取特定版本的SOP內容"""
    # 使用版本控制系統獲取特定版本
    version_info = sop_system.version_control.get_version(sop_id, version)
    
    if not version_info:
        return jsonify({'error': 'Version not found'}), 404
    
    return jsonify(version_info)

@app.route('/api/sop/compare/<sop_id>/<version1>/<version2>', methods=['GET'])
def compare_sop_versions(sop_id, version1, version2):
    """比較兩個SOP版本"""
    format_type = request.args.get('format', 'unified')
    
    # 使用版本控制系統比較版本
    diff = sop_system.version_control.compare_versions(sop_id, version1, version2, format=format_type)
    
    if not diff:
        return jsonify({'error': 'Could not compare versions'}), 404
    
    if format_type == 'html':
        return diff
    else:
        return jsonify({'diff': diff})

@app.route('/api/sop/update/<sop_id>', methods=['POST'])
def update_sop(sop_id):
    """更新SOP內容並創建新版本"""
    # 檢查SOP是否存在
    sop = sop_system.get_sop(sop_id)
    if not sop:
        return jsonify({'error': 'SOP not found'}), 404
    
    # 獲取更新數據
    data = {}
    if 'title' in request.form:
        data['title'] = request.form.get('title')
    
    if 'description' in request.form:
        data['description'] = request.form.get('description')
    
    if 'author' in request.form:
        data['author'] = request.form.get('author')
    
    if 'status' in request.form:
        data['status'] = request.form.get('status')
    
    # 處理更新內容
    if 'file' in request.files:
        file = request.files['file']
        if file.filename != '' and allowed_file(file.filename):
            # 使用SOP整合系統更新SOP
            result = sop_system.update_sop(sop_id, file=file, metadata=data)
            
            if result.get('success'):
                return jsonify({
                    'success': True,
                    'sop_id': sop_id,
                    'version': result.get('version')
                })
            else:
                return jsonify({'error': result.get('error')}), 400
        else:
            return jsonify({'error': 'Invalid file'}), 400
    elif 'content' in request.form:
        content = request.form.get('content')
        
        # 使用SOP整合系統更新SOP
        result = sop_system.update_sop(sop_id, content=content, metadata=data)
        
        if result.get('success'):
            return jsonify({
                'success': True,
                'sop_id': sop_id,
                'version': result.get('version')
            })
        else:
            return jsonify({'error': result.get('error')}), 400
    elif data:
        # 只更新元數據
        metadata = sop_system.metadata_processor.update_metadata(sop_id, data)
        
        if metadata:
            return jsonify({
                'success': True,
                'sop_id': sop_id,
                'version': metadata.get('version')
            })
        else:
            return jsonify({'error': 'Failed to update metadata'}), 400
    else:
        return jsonify({'error': 'No content or metadata provided'}), 400

@app.route('/api/sop/search', methods=['GET'])
def search_sops():
    """搜索SOP"""
    query = request.args.get('q', '')
    fab = request.args.get('fab', '')
    product = request.args.get('product', '')
    
    # 使用SOP整合系統搜索SOPs
    results = sop_system.search_sops(query, fab if fab else None, product if product else None)
    
    # 提取元數據列表
    metadata_list = [sop.get('metadata', {}) for sop in results]
    
    return jsonify(metadata_list)

@app.route('/api/sop/tags', methods=['GET'])
def get_all_tags():
    """獲取所有標籤"""
    tags = sop_system.metadata_processor.get_all_tags()
    return jsonify(tags)

@app.route('/api/sop/categories', methods=['GET'])
def get_all_categories():
    """獲取所有分類"""
    categories = sop_system.metadata_processor.get_all_categories()
    return jsonify(categories)

@app.route('/api/sop/statistics', methods=['GET'])
def get_statistics():
    """獲取SOP統計信息"""
    stats = sop_system.metadata_processor.get_statistics()
    return jsonify(stats)

@app.route('/api/sop/metadata/<sop_id>', methods=['GET'])
def get_sop_metadata(sop_id):
    """獲取SOP元數據"""
    metadata = sop_system.metadata_processor.get_metadata(sop_id)
    if not metadata:
        return jsonify({'error': 'SOP not found'}), 404
    
    return jsonify(metadata)

@app.route('/api/sop/delete/<sop_id>', methods=['DELETE'])
def delete_sop(sop_id):
    """刪除SOP"""
    # 使用SOP整合系統刪除SOP
    result = sop_system.delete_sop(sop_id)
    
    if result:
        return jsonify({'success': True})
    else:
        return jsonify({'error': 'SOP not found or could not be deleted'}), 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
