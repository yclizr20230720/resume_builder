# SOP執行系統 - 快速安裝指南

本文檔提供SOP執行系統在Windows 11環境中的快速安裝步驟。如需詳細說明，請參閱完整的部署指南。

## 前置準備

1. 確認您的系統符合以下最低要求：
   - Windows 11 或 Windows Server 2019/2022
   - 4GB RAM
   - 10GB可用磁碟空間
   - 管理員權限的Windows帳戶

2. 下載並安裝Python 3.8+：
   - 訪問 https://www.python.org/downloads/windows/
   - 下載最新版本的Python安裝程式
   - 執行安裝程式，確保勾選「Add Python to PATH」選項

## 安裝步驟

### 步驟1：解壓部署包

1. 將SOP執行系統部署包解壓到本地目錄，例如：`C:\sop_deployment`

### 步驟2：安裝依賴項

1. 以管理員身份打開命令提示符(CMD)
2. 導航到部署包的scripts目錄：`cd C:\sop_deployment\windows_deployment\scripts`
3. 執行安裝依賴項腳本：`install_dependencies.bat`
4. 等待所有依賴項安裝完成

### 步驟3：初始化系統

1. 在同一命令提示符中執行系統初始化腳本：`initialize_system.bat`
2. 等待系統初始化完成
3. 確認應用程序目錄和資料目錄已成功創建

### 步驟4：配置Windows服務（可選）

1. 在同一命令提示符中執行Windows服務配置腳本：`create_windows_service.bat`
2. 等待服務創建和啟動完成

### 步驟5：配置IIS反向代理（可選）

1. 在同一命令提示符中執行IIS反向代理配置腳本：`configure_iis_proxy.bat`
2. 按照提示安裝URL Rewrite和ARR模組（如果尚未安裝）
3. 等待IIS配置完成

## 驗證安裝

1. 打開瀏覽器（如Chrome、Edge或Firefox）
2. 訪問以下地址之一：
   - 直接訪問：http://localhost:5000
   - 通過IIS反向代理：http://localhost
3. 確認SOP執行系統主頁面正確加載

## 故障排除

如果遇到問題，請參考以下資源：
- 檢查應用程式日誌：`C:\sop_system_data\logs\app.log`
- 參閱完整的部署指南中的故障排除章節
- 聯繫系統管理員尋求支持

## 下一步

成功安裝後，您可以：
1. 上傳SOP文件
2. 創建和執行Jupyter Notebook
3. 生成操作報告

詳細的使用說明請參閱系統使用指南。
