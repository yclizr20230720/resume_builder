# SOP執行系統 - Windows 11部署指南

## 1. 系統需求

### 1.1 硬體需求
- 處理器：雙核心或更高
- 記憶體：至少4GB RAM
- 硬碟空間：至少10GB可用空間

### 1.2 軟體需求
- Windows 11 或 Windows Server 2019/2022
- Python 3.8 或更高版本
- Internet Information Services (IIS)
- 網際網路連接（用於安裝依賴項）

### 1.3 權限需求
- 管理員權限的Windows帳戶

## 2. 部署步驟概述

完整的部署過程包含以下步驟：
1. 安裝Python環境
2. 安裝必要的Python套件
3. 初始化系統和創建資料目錄
4. 配置Windows服務（可選）
5. 配置IIS反向代理（可選）
6. 系統測試和驗證

## 3. 詳細部署步驟

### 3.1 安裝Python環境

1. 訪問Python官方網站：https://www.python.org/downloads/windows/
2. 下載最新版本的Python安裝程式（建議Python 3.10或更高版本）
3. 以管理員身份運行安裝程式
4. 勾選「Add Python to PATH」選項
5. 選擇「Customize installation」
6. 在「Optional Features」中確保所有選項都被勾選
7. 在「Advanced Options」中勾選：
   - 「Install for all users」
   - 「Create shortcuts for installed applications」
   - 「Add Python to environment variables」
   - 「Precompile standard library」
8. 點擊「Install」開始安裝
9. 等待安裝完成

### 3.2 安裝必要的Python套件

1. 解壓部署包到本地目錄
2. 以管理員身份打開命令提示符(CMD)
3. 導航到部署包的scripts目錄
4. 執行`install_dependencies.bat`腳本
5. 等待所有依賴項安裝完成
6. 確認無錯誤信息

### 3.3 初始化系統和創建資料目錄

1. 以管理員身份打開命令提示符(CMD)
2. 導航到部署包的scripts目錄
3. 執行`initialize_system.bat`腳本
4. 等待系統初始化完成
5. 確認應用程序目錄和資料目錄已成功創建

### 3.4 配置Windows服務（可選）

如果您希望將SOP執行系統作為Windows服務運行，請按照以下步驟操作：

1. 以管理員身份打開命令提示符(CMD)
2. 導航到部署包的scripts目錄
3. 執行`create_windows_service.bat`腳本
4. 等待服務創建和啟動完成
5. 確認服務已成功啟動

### 3.5 配置IIS反向代理（可選）

如果您希望通過IIS反向代理訪問SOP執行系統，請按照以下步驟操作：

1. 確保已安裝IIS和必要的組件
2. 以管理員身份打開命令提示符(CMD)
3. 導航到部署包的scripts目錄
4. 執行`configure_iis_proxy.bat`腳本
5. 按照提示安裝URL Rewrite和ARR模組（如果尚未安裝）
6. 等待IIS配置完成
7. 確認可以通過http://localhost/訪問系統

### 3.6 系統測試和驗證

1. 打開瀏覽器（如Chrome、Edge或Firefox）
2. 訪問以下地址之一：
   - 直接訪問：http://localhost:5000
   - 通過IIS反向代理：http://localhost
3. 確認SOP執行系統主頁面正確加載
4. 測試基本功能：
   - 點擊「SOP列表」，確認頁面正確加載
   - 點擊「SOP創建和上傳」，確認頁面正確加載

## 4. 故障排除

### 4.1 應用程式無法啟動
- 檢查Python版本是否正確：`python --version`
- 確認所有依賴項已安裝：`pip list`
- 檢查應用程式日誌中的錯誤信息（位於`C:\sop_system_data\logs\app.log`）
- 確認應用程式目錄結構正確

### 4.2 無法訪問網頁
- 確認應用程式正在運行：`netstat -ano | findstr 5000`
- 檢查防火牆設置，確保端口5000已開放
- 如果使用IIS，檢查IIS日誌（位於`%SystemDrive%\inetpub\logs\LogFiles`）

### 4.3 Windows服務問題
- 檢查服務狀態：`sc query SOPExecutionSystem`
- 查看服務日誌（位於`C:\sop_system\logs\service_stderr.log`）
- 嘗試重新啟動服務：`sc stop SOPExecutionSystem && sc start SOPExecutionSystem`

### 4.4 IIS反向代理問題
- 確認URL Rewrite和ARR模組已正確安裝
- 檢查web.config文件中的重寫規則
- 重啟IIS：`iisreset`

## 5. 系統維護

### 5.1 定期備份
建議定期備份以下目錄：
- `C:\sop_system_data\uploads`：上傳的SOP文件
- `C:\sop_system_data\notebooks`：生成的Jupyter Notebook
- `C:\sop_system_data\metadata`：SOP元數據

可以創建以下備份腳本（backup.bat）：
```batch
@echo off
set BACKUP_DIR=D:\backups\sop_system\%date:~-4,4%%date:~-7,2%%date:~-10,2%
mkdir %BACKUP_DIR%
xcopy C:\sop_system_data\uploads %BACKUP_DIR%\uploads /E /I /Y
xcopy C:\sop_system_data\notebooks %BACKUP_DIR%\notebooks /E /I /Y
xcopy C:\sop_system_data\metadata %BACKUP_DIR%\metadata /E /I /Y
echo Backup completed to %BACKUP_DIR%
```

### 5.2 日誌管理
- 定期檢查應用程式日誌（位於`C:\sop_system_data\logs\app.log`）
- 如果日誌文件過大，可以進行歸檔或清理

### 5.3 系統更新
1. 停止服務：`sc stop SOPExecutionSystem`
2. 備份當前系統
3. 替換更新的文件
4. 重新啟動服務：`sc start SOPExecutionSystem`

## 6. 安全建議

### 6.1 訪問控制
- 限制對服務器的物理訪問
- 使用強密碼保護管理員帳戶
- 實施最小權限原則

### 6.2 網絡安全
- 使用防火牆限制對端口5000的訪問
- 考慮使用HTTPS而非HTTP
- 定期更新Windows和所有已安裝的軟體

### 6.3 資料安全
- 定期備份重要數據
- 加密敏感數據
- 實施資料訪問審計

## 7. 聯繫支持

如有任何問題或需要技術支持，請聯繫系統管理員。
