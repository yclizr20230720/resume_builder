# SOP執行系統 - Windows 11部署包說明文件

## 部署包內容

本部署包包含在Windows 11環境中部署SOP執行系統所需的所有組件，包括：

1. **部署腳本**
   - `install_dependencies.bat` - 安裝所有必要的Python依賴項
   - `create_windows_service.bat` - 配置Windows服務
   - `configure_iis_proxy.bat` - 配置IIS反向代理
   - `initialize_system.bat` - 初始化系統和創建資料目錄

2. **文檔**
   - `deployment_guide.md` - 詳細的部署指南
   - `system_requirements.md` - 系統需求文檔
   - `quick_install_guide.md` - 快速安裝指南
   - `test_report.md` - 部署包測試報告

3. **原始代碼**
   - 完整的SOP執行系統源代碼

## 部署步驟概述

1. 解壓部署包到本地目錄
2. 安裝Python 3.8+（如果尚未安裝）
3. 運行`install_dependencies.bat`安裝依賴項
4. 運行`initialize_system.bat`初始化系統
5. 運行`create_windows_service.bat`配置Windows服務（可選）
6. 運行`configure_iis_proxy.bat`配置IIS反向代理（可選）
7. 訪問系統並驗證功能

詳細的部署步驟請參閱`deployment_guide.md`或`quick_install_guide.md`。

## 系統需求

- Windows 11 或 Windows Server 2019/2022
- Python 3.8+
- 至少4GB RAM
- 至少10GB可用磁碟空間
- 管理員權限的Windows帳戶

詳細的系統需求請參閱`system_requirements.md`。

## 聯繫支持

如有任何問題或需要技術支持，請聯繫系統管理員。
