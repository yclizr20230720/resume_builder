// 添加Markdown編輯器功能
document.addEventListener('DOMContentLoaded', function() {
    // 初始化SimpleMDE Markdown編輯器
    // 注意：這需要在HTML中引入SimpleMDE的CSS和JS
    let markdownEditor = null;
    
    // 當用戶選擇通過URL創建SOP時，顯示Markdown編輯器
    document.getElementById('sopUrl').addEventListener('input', function() {
        if (this.value.trim() !== '') {
            // 如果尚未初始化編輯器，則初始化
            if (!markdownEditor && document.getElementById('markdownEditor')) {
                markdownEditor = new SimpleMDE({
                    element: document.getElementById('markdownEditor'),
                    spellChecker: false,
                    autosave: {
                        enabled: true,
                        uniqueId: 'sopMarkdownEditor',
                        delay: 1000,
                    },
                    placeholder: '在此編輯SOP內容...',
                    toolbar: [
                        'bold', 'italic', 'heading', '|',
                        'quote', 'unordered-list', 'ordered-list', '|',
                        'link', 'image', '|',
                        'preview', 'side-by-side', 'fullscreen', '|',
                        'guide'
                    ]
                });
            }
            
            // 顯示Markdown編輯區域
            document.getElementById('markdownEditorContainer').style.display = 'block';
        } else {
            // 隱藏Markdown編輯區域
            document.getElementById('markdownEditorContainer').style.display = 'none';
        }
    });
    
    // 當用戶點擊"從URL提取"按鈕時
    document.getElementById('extractUrlBtn').addEventListener('click', function() {
        const sopUrl = document.getElementById('sopUrl').value.trim();
        
        if (!sopUrl) {
            showError('請輸入有效的SOP URL');
            return;
        }
        
        // 顯示加載狀態
        this.disabled = true;
        this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 提取中...';
        
        // 模擬從URL提取內容
        setTimeout(() => {
            // 模擬提取的Markdown內容
            const extractedContent = `# SOP標題：${document.getElementById('sopName').value || '未命名SOP'}

## 1. 簡介
這是從URL自動提取的SOP內容。實際應用中，這裡會顯示從URL解析出的真實內容。

## 2. 適用範圍
本SOP適用於所有需要執行此操作的人員。

## 3. 責任
操作人員負責按照本SOP執行操作，主管負責監督執行過程。

## 4. 操作步驟

### 4.1 準備工作
確保所有必要的工具和材料已準備就緒。

### 4.2 執行操作
按照以下步驟執行操作：

1. 步驟1：執行第一個操作
2. 步驟2：執行第二個操作
3. 步驟3：執行第三個操作

### 4.3 完成操作
確認所有步驟已正確執行，並記錄結果。

## 5. 注意事項
執行過程中需要注意的特殊情況和安全事項。
`;
            
            // 設置編輯器內容
            if (markdownEditor) {
                markdownEditor.value(extractedContent);
            }
            
            // 顯示預覽
            document.getElementById('previewContainer').style.display = 'block';
            document.getElementById('previewContent').innerHTML = marked(extractedContent);
            
            // 恢復按鈕狀態
            this.disabled = false;
            this.innerHTML = '<i class="fas fa-download"></i> 從URL提取';
            
            // 滾動到預覽區域
            document.getElementById('previewContainer').scrollIntoView({ behavior: 'smooth' });
            
            // 顯示成功消息
            showSuccess('已成功從URL提取SOP內容');
        }, 2000);
    });
    
    // 當編輯器內容變化時更新預覽
    if (typeof SimpleMDE !== 'undefined') {
        document.addEventListener('simplemde:change', function() {
            if (markdownEditor) {
                const content = markdownEditor.value();
                document.getElementById('previewContent').innerHTML = marked(content);
            }
        });
    }
});
