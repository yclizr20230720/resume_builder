# SOP創建和上傳功能需求分析

## Web GUI需求

1. 上傳SOP文件頁面必須包含以下選項：
   - FAB選擇：FAB12, FAB14, FAB15, FAB18, ENT, FOC
   - 產品選擇：ELFM, EMP, OWMS, MPCS
   - SOP URL：允許用戶輸入URL
   - SOP名稱：如果用戶輸入SOP URL，必須提供SOP名稱
2. 上傳文件必須是Word文件格式

## 後端API需求

1. API必須能夠按FAB和系統創建文件夾結構（例如：D:\FAB12\EMP）來保存上傳的文件
2. SOP文件必須按照規則重命名：FABXX_System_SOPName_DateTime（例如：FAB12-EMP_AddNewTool_20250412132045.doc）
3. 如果用戶只提供SOP URL，API必須從SOP頁面提取文本內容並保存為markdown文件，使用不同的標題級別來良好顯示文檔
4. Markdown文件命名規則：FABXX_System_SOPName_DateTime（例如：FAB12_EMP_AddNewTool_20250412132045.md）
5. 當SOP Markdown文件創建後，返回GUI以美觀的方式顯示內容（瀏覽器支持Markdown格式內容）
6. 向用戶返回消息，說明上傳文件已保存為FAB12_EMP_AddNewTool_20250412132045.doc或FAB12_EMP_AddNewTool_20250412132045.md
7. 必須與之前的Block 4（SOP執行）設計兼容，確保上傳的SOP文件位置或路徑匹配
8. 完善的過程消息日誌記錄
9. 強大的異常處理，向用戶彈出消息說明發生了什麼以及下一步該做什麼
