import os
import json
import uuid
import datetime
import shutil
import nbformat
from werkzeug.utils import secure_filename
from .storage_manager import StorageManager
from .document_converter import DocumentConverter

class SopIntegration:
    """整合SOP管理、存儲結構和文檔轉換的系統"""
    
    def __init__(self, base_folder):
        """初始化SOP整合系統
        
        Args:
            base_folder: 基礎存儲目錄
        """
        self.base_folder = base_folder
        
        # 設置各個目錄
        self.uploads_folder = os.path.join(base_folder, 'uploads')
        self.notebooks_folder = os.path.join(base_folder, 'notebooks')
        self.versions_folder = os.path.join(base_folder, 'versions')
        self.metadata_folder = os.path.join(base_folder, 'metadata')
        self.reports_folder = os.path.join(base_folder, 'reports')
        self.screenshots_folder = os.path.join(base_folder, 'screenshots')
        
        # 確保目錄存在
        for folder in [self.uploads_folder, self.notebooks_folder, self.versions_folder, 
                      self.metadata_folder, self.reports_folder, self.screenshots_folder]:
            os.makedirs(folder, exist_ok=True)
        
        # 初始化子系統
        self.storage_manager = StorageManager(self.uploads_folder)
        self.document_converter = DocumentConverter()
        
        # 允許的文件擴展名
        self.allowed_extensions = {'md', 'txt', 'ipynb', 'py', 'json', 'doc', 'docx'}
    
    def allowed_file(self, filename):
        """檢查文件擴展名是否允許
        
        Args:
            filename: 文件名
            
        Returns:
            布爾值，表示文件是否允許
        """
        return '.' in filename and filename.rsplit('.', 1)[1].lower() in self.allowed_extensions
    
    def create_sop_from_file(self, file, metadata):
        """從上傳的文件創建SOP
        
        Args:
            file: 上傳的文件對象
            metadata: SOP元數據，包含fab、product、title等
            
        Returns:
            處理結果
        """
        # 驗證文件
        if not self.allowed_file(file.filename):
            return {
                'success': False,
                'error': f'不支持的文件格式。允許的格式: {", ".join(self.allowed_extensions)}'
            }
        
        # 獲取文件類型
        file_type = file.filename.rsplit('.', 1)[1].lower()
        
        # 生成唯一ID
        sop_id = str(uuid.uuid4())
        
        # 臨時保存上傳的文件
        temp_path = os.path.join(self.uploads_folder, f"temp_{sop_id}_{secure_filename(file.filename)}")
        file.save(temp_path)
        
        # 處理Word文檔
        if file_type in ['doc', 'docx']:
            try:
                # 轉換為Markdown
                markdown_content = self.document_converter.word_to_markdown(temp_path)
                
                # 保存Markdown文件
                md_filename = f"{metadata['fab']}_{metadata['product']}_{metadata['title']}_{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}.md"
                md_path = os.path.join(self.uploads_folder, md_filename)
                
                with open(md_path, 'w', encoding='utf-8') as f:
                    f.write(markdown_content)
                
                # 使用新的存儲管理器保存文件
                storage_result = self.storage_manager.save_file(
                    markdown_content,
                    metadata['fab'],
                    metadata['product'],
                    metadata['title']
                )
                
                # 更新元數據
                metadata['filename'] = storage_result['filename']
                metadata['file_type'] = 'md'
                metadata['original_file_type'] = file_type
                metadata['storage_path'] = storage_result['relative_path']
                
                # 創建元數據文件
                self._save_metadata(sop_id, metadata)
                
                # 生成Jupyter Notebook
                notebook_path = self._generate_notebook(sop_id, markdown_content, metadata)
                
                # 創建版本記錄
                version_info = self._create_version(sop_id, md_path, metadata)
                
                # 清理臨時文件
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                
                return {
                    'success': True,
                    'sop_id': sop_id,
                    'metadata': metadata,
                    'storage': storage_result,
                    'notebook_path': notebook_path,
                    'version': version_info
                }
                
            except Exception as e:
                # 清理臨時文件
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                
                return {
                    'success': False,
                    'error': f'處理Word文檔失敗: {str(e)}'
                }
        
        # 處理其他文件類型
        else:
            try:
                # 使用新的存儲管理器保存文件
                with open(temp_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                storage_result = self.storage_manager.save_file(
                    content,
                    metadata['fab'],
                    metadata['product'],
                    metadata['title'],
                    original_filename=file.filename
                )
                
                # 更新元數據
                metadata['filename'] = storage_result['filename']
                metadata['file_type'] = file_type
                metadata['storage_path'] = storage_result['relative_path']
                
                # 創建元數據文件
                self._save_metadata(sop_id, metadata)
                
                # 生成Jupyter Notebook
                notebook_path = self._generate_notebook(sop_id, content, metadata)
                
                # 創建版本記錄
                version_info = self._create_version(sop_id, storage_result['path'], metadata)
                
                # 清理臨時文件
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                
                return {
                    'success': True,
                    'sop_id': sop_id,
                    'metadata': metadata,
                    'storage': storage_result,
                    'notebook_path': notebook_path,
                    'version': version_info
                }
                
            except Exception as e:
                # 清理臨時文件
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                
                return {
                    'success': False,
                    'error': f'處理文件失敗: {str(e)}'
                }
    
    def create_sop_from_url(self, url, metadata):
        """從URL創建SOP
        
        Args:
            url: SOP內容的URL
            metadata: SOP元數據，包含fab、product、title等
            
        Returns:
            處理結果
        """
        try:
            # 提取URL內容
            markdown_content = self.document_converter.extract_from_url(url)
            
            # 生成唯一ID
            sop_id = str(uuid.uuid4())
            
            # 使用新的存儲管理器保存文件
            storage_result = self.storage_manager.save_file(
                markdown_content,
                metadata['fab'],
                metadata['product'],
                metadata['title']
            )
            
            # 更新元數據
            metadata['filename'] = storage_result['filename']
            metadata['file_type'] = 'md'
            metadata['source_url'] = url
            metadata['storage_path'] = storage_result['relative_path']
            
            # 創建元數據文件
            self._save_metadata(sop_id, metadata)
            
            # 生成Jupyter Notebook
            notebook_path = self._generate_notebook(sop_id, markdown_content, metadata)
            
            # 創建版本記錄
            version_info = self._create_version(sop_id, storage_result['path'], metadata)
            
            return {
                'success': True,
                'sop_id': sop_id,
                'metadata': metadata,
                'storage': storage_result,
                'notebook_path': notebook_path,
                'version': version_info
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'從URL創建SOP失敗: {str(e)}'
            }
    
    def get_sop(self, sop_id):
        """獲取SOP信息
        
        Args:
            sop_id: SOP的唯一ID
            
        Returns:
            SOP信息
        """
        # 獲取元數據
        metadata = self._get_metadata(sop_id)
        if not metadata:
            return None
        
        # 獲取SOP內容
        content = None
        if 'storage_path' in metadata:
            file_path = os.path.join(self.uploads_folder, metadata['storage_path'])
            if os.path.exists(file_path):
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
        
        # 獲取Jupyter Notebook
        notebook_path = os.path.join(self.notebooks_folder, f"{sop_id}.ipynb")
        notebook = None
        if os.path.exists(notebook_path):
            with open(notebook_path, 'r', encoding='utf-8') as f:
                notebook = json.load(f)
        
        # 獲取版本歷史
        versions = self._get_versions(sop_id)
        
        return {
            'metadata': metadata,
            'content': content,
            'notebook': notebook,
            'versions': versions
        }
    
    def list_sops(self, fab=None, product=None):
        """列出所有SOP
        
        Args:
            fab: 可選的FAB過濾條件
            product: 可選的產品過濾條件
            
        Returns:
            SOP列表
        """
        # 使用存儲管理器列出文件
        files = self.storage_manager.list_files(fab, product)
        
        # 獲取每個文件的元數據
        sops = []
        for file_info in files:
            # 嘗試從文件名解析SOP ID
            metadata_files = os.listdir(self.metadata_folder)
            matching_metadata = None
            
            for metadata_file in metadata_files:
                if metadata_file.endswith('.json'):
                    with open(os.path.join(self.metadata_folder, metadata_file), 'r', encoding='utf-8') as f:
                        metadata = json.load(f)
                        if 'filename' in metadata and metadata['filename'] == file_info['filename']:
                            matching_metadata = metadata
                            break
            
            if matching_metadata:
                sops.append({
                    'file_info': file_info,
                    'metadata': matching_metadata
                })
            else:
                # 如果找不到元數據，使用文件信息創建基本元數據
                sops.append({
                    'file_info': file_info,
                    'metadata': {
                        'title': file_info['sop_name'],
                        'fab': file_info['fab'],
                        'product': file_info['product'],
                        'created_at': datetime.datetime.now().isoformat(),
                        'filename': file_info['filename']
                    }
                })
        
        return sops
    
    def search_sops(self, query=None, fab=None, product=None):
        """搜索SOP
        
        Args:
            query: 搜索關鍵詞
            fab: 可選的FAB過濾條件
            product: 可選的產品過濾條件
            
        Returns:
            搜索結果
        """
        # 獲取所有SOP
        all_sops = self.list_sops(fab, product)
        
        # 如果沒有查詢條件，返回所有結果
        if not query:
            return all_sops
        
        # 過濾結果
        results = []
        query = query.lower()
        
        for sop in all_sops:
            metadata = sop['metadata']
            
            # 搜索標題、描述和作者
            if ('title' in metadata and query in metadata['title'].lower()) or \
               ('description' in metadata and query in metadata['description'].lower()) or \
               ('author' in metadata and query in metadata['author'].lower()):
                results.append(sop)
                continue
            
            # 搜索文件名
            if 'filename' in metadata and query in metadata['filename'].lower():
                results.append(sop)
                continue
            
            # 搜索SOP內容
            if 'storage_path' in metadata:
                file_path = os.path.join(self.uploads_folder, metadata['storage_path'])
                if os.path.exists(file_path):
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            content = f.read().lower()
                            if query in content:
                                results.append(sop)
                                continue
                    except:
                        pass
        
        return results
    
    def _save_metadata(self, sop_id, metadata):
        """保存SOP元數據
        
        Args:
            sop_id: SOP的唯一ID
            metadata: 元數據字典
            
        Returns:
            保存的文件路徑
        """
        # 添加基本元數據
        if 'id' not in metadata:
            metadata['id'] = sop_id
        
        if 'created_at' not in metadata:
            metadata['created_at'] = datetime.datetime.now().isoformat()
        
        if 'updated_at' not in metadata:
            metadata['updated_at'] = datetime.datetime.now().isoformat()
        
        if 'version' not in metadata:
            metadata['version'] = '1.0'
        
        if 'status' not in metadata:
            metadata['status'] = 'draft'
        
        # 保存元數據
        metadata_path = os.path.join(self.metadata_folder, f"{sop_id}.json")
        with open(metadata_path, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, indent=2)
        
        return metadata_path
    
    def _get_metadata(self, sop_id):
        """獲取SOP元數據
        
        Args:
            sop_id: SOP的唯一ID
            
        Returns:
            元數據字典
        """
        metadata_path = os.path.join(self.metadata_folder, f"{sop_id}.json")
        if not os.path.exists(metadata_path):
            return None
        
        with open(metadata_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def _create_version(self, sop_id, file_path, metadata):
        """創建SOP版本
        
        Args:
            sop_id: SOP的唯一ID
            file_path: SOP文件路徑
            metadata: SOP元數據
            
        Returns:
            版本信息
        """
        # 確保版本目錄存在
        version_folder = os.path.join(self.versions_folder, sop_id)
        os.makedirs(version_folder, exist_ok=True)
        
        # 獲取版本號
        version = metadata.get('version', '1.0')
        
        # 獲取原始文件名
        original_filename = os.path.basename(file_path)
        
        # 創建版本文件名
        version_filename = f"v{version}_{original_filename}"
        version_path = os.path.join(version_folder, version_filename)
        
        # 複製文件到版本目錄
        shutil.copy2(file_path, version_path)
        
        return {
            'version': version,
            'filename': version_filename,
            'path': version_path,
            'created_at': datetime.datetime.now().isoformat()
        }
    
    def _get_versions(self, sop_id):
        """獲取SOP的所有版本
        
        Args:
            sop_id: SOP的唯一ID
            
        Returns:
            版本列表
        """
        version_folder = os.path.join(self.versions_folder, sop_id)
        if not os.path.exists(version_folder):
            return []
        
        versions = []
        for filename in os.listdir(version_folder):
            if filename.startswith('v'):
                # 提取版本號
                version_str = filename.split('_')[0][1:]
                
                versions.append({
                    'version': version_str,
                    'filename': filename,
                    'path': os.path.join(version_folder, filename),
                    'created_at': datetime.datetime.fromtimestamp(
                        os.path.getctime(os.path.join(version_folder, filename))
                    ).isoformat()
                })
        
        # 按版本號排序
        versions.sort(key=lambda x: float(x['version']), reverse=True)
        
        return versions
    
    def _generate_notebook(self, sop_id, content, metadata):
        """根據SOP內容生成Jupyter Notebook
        
        Args:
            sop_id: SOP的唯一ID
            content: SOP內容
            metadata: SOP元數據
            
        Returns:
            Notebook文件路徑
        """
        notebook = nbformat.v4.new_notebook()
        cells = []
        
        # 添加標題和描述
        title = metadata.get('title', 'Untitled SOP')
        description = metadata.get('description', '')
        
        cells.append(nbformat.v4.new_markdown_cell(f"# {title}\n\n{description}"))
        
        # 處理不同類型的SOP內容
        file_type = metadata.get('file_type', 'md')
        
        if file_type == 'md':
            # 解析Markdown內容
            sections = content.split('\n## ')
            
            # 處理第一部分（可能包含主標題）
            first_section = sections[0]
            if first_section.startswith('# '):
                first_section = first_section.split('\n', 1)[1] if '\n' in first_section else ''
            
            if first_section.strip():
                cells.append(nbformat.v4.new_markdown_cell(first_section))
            
            # 處理其餘部分
            for i, section in enumerate(sections[1:], 1):
                section_title = section.split('\n', 1)[0] if '\n' in section else section
                section_content = section.split('\n', 1)[1] if '\n' in section else ''
                
                cells.append(nbformat.v4.new_markdown_cell(f"## {section_title}"))
                
                # 提取代碼塊
                code_blocks = []
                in_code_block = False
                current_block = []
                
                for line in section_content.split('\n'):
                    if line.startswith('```'):
                        if in_code_block:
                            # 結束代碼塊
                            in_code_block = False
                            code_blocks.append('\n'.join(current_block))
                            current_block = []
                        else:
                            # 開始代碼塊
                            in_code_block = True
                            # 跳過語言標識行
                            continue
                    elif in_code_block:
                        current_block.append(line)
                
                # 添加Markdown內容（不包括代碼塊）
                markdown_content = section_content
                for code_block in code_blocks:
                    markdown_content = markdown_content.replace(f"```\n{code_block}\n```", '')
                    markdown_content = markdown_content.replace(f"```python\n{code_block}\n```", '')
                
                if markdown_content.strip():
                    cells.append(nbformat.v4.new_markdown_cell(markdown_content))
                
                # 添加代碼塊
                for code_block in code_blocks:
                    cells.append(nbformat.v4.new_code_cell(code_block))
        
        elif file_type == 'py':
            # 將Python文件轉換為Notebook
            # 解析註釋和代碼
            lines = content.split('\n')
            current_comment = []
            current_code = []
            
            for line in lines:
                if line.strip().startswith('#'):
                    # 如果有累積的代碼，先添加代碼單元格
                    if current_code:
                        cells.append(nbformat.v4.new_code_cell('\n'.join(current_code)))
                        current_code = []
                    
                    # 收集註釋
                    current_comment.append(line.strip()[1:].strip())
                else:
                    # 如果有累積的註釋，先添加Markdown單元格
                    if current_comment:
                        cells.append(nbformat.v4.new_markdown_cell('\n'.join(current_comment)))
                        current_comment = []
                    
                    # 收集代碼
                    if line.strip():
                        current_code.append(line)
            
            # 處理最後的註釋或代碼
            if current_comment:
                cells.append(nbformat.v4.new_markdown_cell('\n'.join(current_comment)))
            
            if current_code:
                cells.append(nbformat.v4.new_code_cell('\n'.join(current_code)))
        
        # 將單元格添加到Notebook
        notebook.cells = cells
        
        # 保存Notebook
        notebook_path = os.path.join(self.notebooks_folder, f"{sop_id}.ipynb")
        with open(notebook_path, 'w', encoding='utf-8') as f:
            nbformat.write(notebook, f)
        
        return notebook_path
