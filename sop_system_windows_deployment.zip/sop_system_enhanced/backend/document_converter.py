import os
import re
import requests
from bs4 import BeautifulSoup
import markdown
import json
import tempfile
from docx import Document

class DocumentConverter:
    """文檔轉換工具，支持Word到Markdown和URL內容提取"""
    
    def __init__(self):
        """初始化文檔轉換器"""
        pass
    
    def word_to_markdown(self, docx_path):
        """將Word文檔轉換為Markdown格式
        
        Args:
            docx_path: Word文檔的路徑
            
        Returns:
            Markdown格式的文本內容
        """
        try:
            # 打開Word文檔
            doc = Document(docx_path)
            
            # 提取文本內容
            markdown_content = []
            
            # 處理標題和段落
            for para in doc.paragraphs:
                if para.style.name.startswith('Heading'):
                    # 獲取標題級別
                    level = int(para.style.name.replace('Heading', ''))
                    # 添加對應數量的#作為標題標記
                    markdown_content.append('#' * level + ' ' + para.text)
                else:
                    # 普通段落
                    markdown_content.append(para.text)
            
            # 處理表格
            for table in doc.tables:
                # 表格頭部
                markdown_content.append('| ' + ' | '.join(cell.text for cell in table.rows[0].cells) + ' |')
                # 表格分隔線
                markdown_content.append('| ' + ' | '.join(['---'] * len(table.rows[0].cells)) + ' |')
                # 表格內容
                for row in table.rows[1:]:
                    markdown_content.append('| ' + ' | '.join(cell.text for cell in row.cells) + ' |')
            
            # 合併所有內容
            return '\n\n'.join(markdown_content)
        
        except Exception as e:
            raise Exception(f"Word文檔轉換失敗: {str(e)}")
    
    def extract_from_url(self, url):
        """從URL提取內容並轉換為Markdown
        
        Args:
            url: 要提取內容的URL
            
        Returns:
            提取的Markdown內容
        """
        try:
            # 發送HTTP請求
            response = requests.get(url, headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            })
            response.raise_for_status()
            
            # 解析HTML
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 移除不需要的元素
            for element in soup(['script', 'style', 'nav', 'footer', 'iframe']):
                element.decompose()
            
            # 提取標題
            title = soup.title.string if soup.title else "Extracted Content"
            
            # 提取主要內容
            main_content = self._extract_main_content(soup)
            
            # 構建Markdown內容
            markdown_content = [f"# {title.strip()}", ""]
            
            # 處理標題
            for heading in main_content.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6']):
                level = int(heading.name[1])
                markdown_content.append('#' * level + ' ' + heading.get_text().strip())
            
            # 處理段落
            for para in main_content.find_all('p'):
                markdown_content.append(para.get_text().strip())
            
            # 處理列表
            for ul in main_content.find_all('ul'):
                for li in ul.find_all('li'):
                    markdown_content.append('- ' + li.get_text().strip())
            
            for ol in main_content.find_all('ol'):
                for i, li in enumerate(ol.find_all('li')):
                    markdown_content.append(f"{i+1}. " + li.get_text().strip())
            
            # 處理表格
            for table in main_content.find_all('table'):
                # 表格頭部
                headers = []
                for th in table.find_all('th'):
                    headers.append(th.get_text().strip())
                
                if headers:
                    markdown_content.append('| ' + ' | '.join(headers) + ' |')
                    markdown_content.append('| ' + ' | '.join(['---'] * len(headers)) + ' |')
                
                # 表格內容
                for tr in table.find_all('tr'):
                    cells = []
                    for td in tr.find_all('td'):
                        cells.append(td.get_text().strip())
                    
                    if cells:
                        markdown_content.append('| ' + ' | '.join(cells) + ' |')
            
            # 合併所有內容
            return '\n\n'.join(markdown_content)
        
        except Exception as e:
            raise Exception(f"URL內容提取失敗: {str(e)}")
    
    def _extract_main_content(self, soup):
        """嘗試提取頁面的主要內容
        
        Args:
            soup: BeautifulSoup對象
            
        Returns:
            包含主要內容的BeautifulSoup對象
        """
        # 嘗試找到主要內容區域
        main_candidates = [
            soup.find('main'),
            soup.find(id='content'),
            soup.find(id='main'),
            soup.find(class_='content'),
            soup.find(class_='main'),
            soup.find('article')
        ]
        
        # 使用第一個找到的有效元素
        for candidate in main_candidates:
            if candidate:
                return candidate
        
        # 如果找不到明確的主要內容區域，返回整個body
        return soup.body or soup
    
    def html_to_markdown(self, html_content):
        """將HTML內容轉換為Markdown
        
        Args:
            html_content: HTML內容
            
        Returns:
            Markdown格式的文本
        """
        try:
            # 解析HTML
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # 移除不需要的元素
            for element in soup(['script', 'style']):
                element.decompose()
            
            # 提取主要內容
            main_content = self._extract_main_content(soup)
            
            # 使用與extract_from_url相同的邏輯處理內容
            # 這裡可以重用上面的代碼，但為了簡潔起見，我們使用一個簡單的方法
            
            # 將HTML轉換為純文本
            text = main_content.get_text()
            
            # 清理文本
            lines = (line.strip() for line in text.splitlines())
            chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
            text = '\n'.join(chunk for chunk in chunks if chunk)
            
            return text
        
        except Exception as e:
            raise Exception(f"HTML轉換失敗: {str(e)}")
    
    def save_as_markdown(self, content, output_path):
        """將內容保存為Markdown文件
        
        Args:
            content: 要保存的內容
            output_path: 輸出文件路徑
            
        Returns:
            保存的文件路徑
        """
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            return output_path
        
        except Exception as e:
            raise Exception(f"保存Markdown文件失敗: {str(e)}")
