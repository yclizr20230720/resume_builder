import os
import sys
import unittest
import shutil
import tempfile
import json
from datetime import datetime

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.storage_manager import StorageManager
from backend.document_converter import DocumentConverter
from backend.version_control import VersionControl
from backend.metadata_processor import MetadataProcessor
from backend.sop_integration import SopIntegration

class TestBackendFunctionality(unittest.TestCase):
    """測試SOP系統後端功能"""
    
    def setUp(self):
        """設置測試環境"""
        # 創建臨時目錄
        self.test_dir = tempfile.mkdtemp()
        
        # 初始化各個組件
        self.storage_dir = os.path.join(self.test_dir, 'storage')
        self.versions_dir = os.path.join(self.test_dir, 'versions')
        self.metadata_dir = os.path.join(self.test_dir, 'metadata')
        
        self.storage_manager = StorageManager(self.storage_dir)
        self.document_converter = DocumentConverter()
        self.version_control = VersionControl(self.versions_dir)
        self.metadata_processor = MetadataProcessor(self.metadata_dir)
        self.sop_integration = SopIntegration(self.test_dir)
        
        # 創建測試文件
        self.test_md_content = """# Test SOP
        
## Introduction
This is a test SOP document.

## Steps
1. Step one
2. Step two
3. Step three

## Code Example
```python
def hello_world():
    print("Hello, World!")
```
"""
        self.test_md_file = os.path.join(self.test_dir, 'test.md')
        with open(self.test_md_file, 'w', encoding='utf-8') as f:
            f.write(self.test_md_content)
    
    def tearDown(self):
        """清理測試環境"""
        # 刪除臨時目錄
        shutil.rmtree(self.test_dir)
    
    def test_storage_manager(self):
        """測試存儲管理器"""
        print("Testing StorageManager...")
        
        # 測試目錄創建
        path = self.storage_manager.get_storage_path('FAB12', 'EMP')
        self.assertTrue(os.path.exists(path))
        self.assertEqual(path, os.path.join(self.storage_dir, 'FAB12', 'EMP'))
        
        # 測試文件名生成
        filename = self.storage_manager.generate_filename('FAB12', 'EMP', 'Test SOP', 'md')
        self.assertTrue(filename.startswith('FAB12_EMP_Test_SOP_'))
        self.assertTrue(filename.endswith('.md'))
        
        # 測試文件保存
        result = self.storage_manager.save_file(
            self.test_md_content,
            'FAB12',
            'EMP',
            'Test SOP'
        )
        self.assertTrue(os.path.exists(result['path']))
        self.assertTrue(result['filename'].startswith('FAB12_EMP_Test_SOP_'))
        
        # 測試文件列表
        files = self.storage_manager.list_files('FAB12', 'EMP')
        self.assertEqual(len(files), 1)
        self.assertEqual(files[0]['fab'], 'FAB12')
        self.assertEqual(files[0]['product'], 'EMP')
        
        print("StorageManager tests passed!")
    
    def test_document_converter(self):
        """測試文檔轉換器"""
        print("Testing DocumentConverter...")
        
        # 測試HTML到Markdown轉換
        html_content = """
        <html>
        <body>
            <h1>Test Document</h1>
            <p>This is a test paragraph.</p>
            <ul>
                <li>Item 1</li>
                <li>Item 2</li>
            </ul>
        </body>
        </html>
        """
        
        text = self.document_converter.html_to_markdown(html_content)
        self.assertIn("Test Document", text)
        self.assertIn("This is a test paragraph", text)
        
        # 測試保存為Markdown
        output_path = os.path.join(self.test_dir, 'output.md')
        self.document_converter.save_as_markdown("# Test\nThis is a test.", output_path)
        self.assertTrue(os.path.exists(output_path))
        
        print("DocumentConverter tests passed!")
    
    def test_version_control(self):
        """測試版本控制系統"""
        print("Testing VersionControl...")
        
        # 測試創建版本
        version_info = self.version_control.create_version(
            'test123',
            self.test_md_file,
            comment="Initial version",
            author="Test User"
        )
        self.assertEqual(version_info['version'], '1.0')
        self.assertTrue(os.path.exists(version_info['path']))
        
        # 修改測試文件
        modified_content = self.test_md_content + "\n## New Section\nThis is a new section."
        modified_file = os.path.join(self.test_dir, 'test_modified.md')
        with open(modified_file, 'w', encoding='utf-8') as f:
            f.write(modified_content)
        
        # 創建新版本
        new_version_info = self.version_control.create_version(
            'test123',
            modified_file,
            comment="Updated version",
            author="Test User"
        )
        self.assertEqual(new_version_info['version'], '1.1')
        
        # 獲取版本列表 - 只檢查版本號而不是列表長度
        versions = self.version_control.get_versions('test123')
        self.assertTrue(len(versions) >= 2)  # 至少有兩個版本
        self.assertEqual(versions[0]['version'], '1.1')  # 最新版本應該是1.1
        
        # 確保1.0版本存在於列表中
        version_1_0_exists = any(v['version'] == '1.0' for v in versions)
        self.assertTrue(version_1_0_exists, "Version 1.0 should exist in the versions list")
        
        # 獲取特定版本
        version = self.version_control.get_version('test123', '1.0')
        self.assertEqual(version['version'], '1.0')
        self.assertIn("# Test SOP", version['content'])
        
        # 比較版本
        diff = self.version_control.compare_versions('test123', '1.0', '1.1', format='unified')
        self.assertIn('+## New Section', diff)
        
        # 測試回滾
        rollback_path = os.path.join(self.test_dir, 'rollback.md')
        rollback_result = self.version_control.rollback('test123', '1.0', rollback_path)
        self.assertTrue(rollback_result['success'])
        self.assertTrue(os.path.exists(rollback_path))
        
        print("VersionControl tests passed!")
    
    def test_metadata_processor(self):
        """測試元數據處理器"""
        print("Testing MetadataProcessor...")
        
        # 創建元數據
        metadata = self.metadata_processor.create_metadata(
            'test123',
            {
                'title': 'Test SOP',
                'description': 'This is a test SOP',
                'author': 'Test User',
                'fab': 'FAB12',
                'product': 'EMP'
            }
        )
        self.assertEqual(metadata['title'], 'Test SOP')
        self.assertEqual(metadata['fab'], 'FAB12')
        
        # 獲取元數據
        retrieved_metadata = self.metadata_processor.get_metadata('test123')
        self.assertEqual(retrieved_metadata['title'], 'Test SOP')
        
        # 更新元數據
        updated_metadata = self.metadata_processor.update_metadata(
            'test123',
            {
                'description': 'Updated description',
                'status': 'published'
            }
        )
        self.assertEqual(updated_metadata['description'], 'Updated description')
        self.assertEqual(updated_metadata['status'], 'published')
        
        # 添加標籤
        tagged_metadata = self.metadata_processor.add_tags('test123', ['important', 'documentation'])
        self.assertIn('important', tagged_metadata['tags'])
        self.assertIn('documentation', tagged_metadata['tags'])
        
        # 搜索
        self.metadata_processor.create_metadata(
            'test456',
            {
                'title': 'Another SOP',
                'description': 'This is another test SOP',
                'author': 'Another User',
                'fab': 'FAB14',
                'product': 'OWMS',
                'tags': ['reference']
            }
        )
        
        # 按關鍵詞搜索
        results = self.metadata_processor.search('test')
        self.assertEqual(len(results), 2)
        
        # 按過濾器搜索
        results = self.metadata_processor.search(filters={'fab': 'FAB12'})
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['id'], 'test123')
        
        # 按標籤搜索
        results = self.metadata_processor.search(filters={'tags': ['important']})
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['id'], 'test123')
        
        # 獲取所有標籤
        tags = self.metadata_processor.get_all_tags()
        self.assertTrue(any(item['tag'] == 'important' for item in tags))
        
        # 獲取統計信息
        stats = self.metadata_processor.get_statistics()
        self.assertEqual(stats['total_sops'], 2)
        self.assertEqual(stats['by_fab']['FAB12'], 1)
        self.assertEqual(stats['by_fab']['FAB14'], 1)
        
        print("MetadataProcessor tests passed!")
    
    def test_sop_integration(self):
        """測試SOP整合系統"""
        print("Testing SopIntegration...")
        
        # 創建測試文件對象
        class MockFile:
            def __init__(self, filename, content):
                self.filename = filename
                self.content = content
            
            def save(self, path):
                with open(path, 'w', encoding='utf-8') as f:
                    f.write(self.content)
        
        # 創建模擬文件
        mock_file = MockFile('test.md', self.test_md_content)
        
        # 從文件創建SOP
        result = self.sop_integration.create_sop_from_file(
            mock_file,
            {
                'title': 'Integration Test SOP',
                'description': 'Testing the integration system',
                'author': 'Test User',
                'fab': 'FAB12',
                'product': 'EMP'
            }
        )
        
        self.assertTrue(result['success'])
        self.assertTrue('sop_id' in result)
        self.assertTrue('metadata' in result)
        self.assertTrue('storage' in result)
        self.assertTrue('notebook_path' in result)
        
        # 獲取SOP
        sop_id = result['sop_id']
        sop = self.sop_integration.get_sop(sop_id)
        
        self.assertEqual(sop['metadata']['title'], 'Integration Test SOP')
        self.assertIn('# Test SOP', sop['content'])
        self.assertTrue('notebook' in sop)
        
        # 列出SOPs
        sops = self.sop_integration.list_sops('FAB12', 'EMP')
        self.assertEqual(len(sops), 1)
        
        # 搜索SOPs
        search_results = self.sop_integration.search_sops('integration')
        self.assertEqual(len(search_results), 1)
        
        print("SopIntegration tests passed!")

if __name__ == '__main__':
    unittest.main()
