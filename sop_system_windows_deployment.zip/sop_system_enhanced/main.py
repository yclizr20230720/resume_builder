from backend.app import app

if __name__ == '__main__':
    # 啟動Flask應用，使用不同的端口避免衝突
    app.run(host='0.0.0.0', port=5001, debug=True)
