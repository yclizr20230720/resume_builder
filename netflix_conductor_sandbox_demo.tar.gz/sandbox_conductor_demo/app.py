import os
import json
import time
import uuid
from flask import Flask, render_template, request, jsonify

# 創建 Flask 應用
app = Flask(__name__)

# 存儲工作流定義和執行狀態的內存數據庫
workflows = {}
executions = {}

# 初始化五階段工作流定義
def init_workflows():
    # 階段1：需求收集與驗證
    stage1_workflow = {
        "name": "it_ops_stage1_workflow",
        "description": "需求收集與驗證階段",
        "version": 1,
        "tasks": [
            {
                "name": "email_teams_integration",
                "taskReferenceName": "email_teams_integration",
                "type": "SIMPLE",
                "inputParameters": {
                    "change_request": "${workflow.input.change_request}"
                }
            },
            {
                "name": "itsr_form_parser",
                "taskReferenceName": "itsr_form_parser",
                "type": "SIMPLE",
                "inputParameters": {
                    "change_request": "${workflow.input.change_request}"
                }
            },
            {
                "name": "requirements_validation",
                "taskReferenceName": "requirements_validation",
                "type": "SIMPLE",
                "inputParameters": {
                    "change_request": "${workflow.input.change_request}",
                    "email_data": "${email_teams_integration.output}",
                    "itsr_data": "${itsr_form_parser.output}"
                }
            }
        ],
        "outputParameters": {
            "validated_requirements": "${requirements_validation.output.validated_requirements}",
            "validation_status": "${requirements_validation.output.validation_status}"
        }
    }
    
    # 階段2：請求與變更範圍驗證
    stage2_workflow = {
        "name": "it_ops_stage2_workflow",
        "description": "請求與變更範圍驗證階段",
        "version": 1,
        "tasks": [
            {
                "name": "system_impact_analysis",
                "taskReferenceName": "system_impact_analysis",
                "type": "SIMPLE",
                "inputParameters": {
                    "validated_requirements": "${workflow.input.validated_requirements}"
                }
            },
            {
                "name": "dependency_checker",
                "taskReferenceName": "dependency_checker",
                "type": "SIMPLE",
                "inputParameters": {
                    "validated_requirements": "${workflow.input.validated_requirements}",
                    "impact_analysis": "${system_impact_analysis.output.impact_analysis}"
                }
            },
            {
                "name": "risk_assessment",
                "taskReferenceName": "risk_assessment",
                "type": "SIMPLE",
                "inputParameters": {
                    "validated_requirements": "${workflow.input.validated_requirements}",
                    "impact_analysis": "${system_impact_analysis.output.impact_analysis}",
                    "dependencies": "${dependency_checker.output.dependencies}"
                }
            }
        ],
        "outputParameters": {
            "impact_analysis": "${system_impact_analysis.output.impact_analysis}",
            "dependencies": "${dependency_checker.output.dependencies}",
            "risk_score": "${risk_assessment.output.risk_score}",
            "risk_assessment": "${risk_assessment.output.risk_assessment}"
        }
    }
    
    # 階段3：所有者分配與操作渠道選擇
    stage3_workflow = {
        "name": "it_ops_stage3_workflow",
        "description": "所有者分配與操作渠道選擇階段",
        "version": 1,
        "tasks": [
            {
                "name": "resource_allocation",
                "taskReferenceName": "resource_allocation",
                "type": "SIMPLE",
                "inputParameters": {
                    "validated_requirements": "${workflow.input.validated_requirements}",
                    "impact_analysis": "${workflow.input.impact_analysis}",
                    "risk_assessment": "${workflow.input.risk_assessment}"
                }
            },
            {
                "name": "deployment_method_selector",
                "taskReferenceName": "deployment_method_selector",
                "type": "SIMPLE",
                "inputParameters": {
                    "validated_requirements": "${workflow.input.validated_requirements}",
                    "impact_analysis": "${workflow.input.impact_analysis}",
                    "risk_assessment": "${workflow.input.risk_assessment}"
                }
            },
            {
                "name": "notification",
                "taskReferenceName": "notification",
                "type": "SIMPLE",
                "inputParameters": {
                    "assigned_resources": "${resource_allocation.output.assigned_resources}",
                    "deployment_method": "${deployment_method_selector.output.deployment_method}"
                }
            }
        ],
        "outputParameters": {
            "assigned_resources": "${resource_allocation.output.assigned_resources}",
            "deployment_method": "${deployment_method_selector.output.deployment_method}",
            "notification_status": "${notification.output.notification_status}"
        }
    }
    
    # 階段4：變更審批與執行
    stage4_workflow = {
        "name": "it_ops_stage4_workflow",
        "description": "變更審批與執行階段",
        "version": 1,
        "tasks": [
            {
                "name": "change_ticket_generator",
                "taskReferenceName": "change_ticket_generator",
                "type": "SIMPLE",
                "inputParameters": {
                    "validated_requirements": "${workflow.input.validated_requirements}",
                    "impact_analysis": "${workflow.input.impact_analysis}",
                    "risk_assessment": "${workflow.input.risk_assessment}",
                    "assigned_resources": "${workflow.input.assigned_resources}",
                    "deployment_method": "${workflow.input.deployment_method}"
                }
            },
            {
                "name": "pr_creation",
                "taskReferenceName": "pr_creation",
                "type": "SIMPLE",
                "inputParameters": {
                    "validated_requirements": "${workflow.input.validated_requirements}",
                    "change_ticket": "${change_ticket_generator.output.change_ticket}"
                }
            },
            {
                "name": "approval_workflow",
                "taskReferenceName": "approval_workflow",
                "type": "SIMPLE",
                "inputParameters": {
                    "change_ticket": "${change_ticket_generator.output.change_ticket}",
                    "pull_request": "${pr_creation.output.pull_request}"
                }
            },
            {
                "name": "execution",
                "taskReferenceName": "execution",
                "type": "SIMPLE",
                "inputParameters": {
                    "validated_requirements": "${workflow.input.validated_requirements}",
                    "deployment_method": "${workflow.input.deployment_method}",
                    "approval_status": "${approval_workflow.output.approval_status}"
                }
            }
        ],
        "outputParameters": {
            "change_ticket": "${change_ticket_generator.output.change_ticket}",
            "pull_request": "${pr_creation.output.pull_request}",
            "approval_status": "${approval_workflow.output.approval_status}",
            "execution_status": "${execution.output.execution_status}",
            "deployment_details": "${execution.output.deployment_details}"
        }
    }
    
    # 階段5：後檢查與報告
    stage5_workflow = {
        "name": "it_ops_stage5_workflow",
        "description": "後檢查與報告階段",
        "version": 1,
        "tasks": [
            {
                "name": "deployment_verification",
                "taskReferenceName": "deployment_verification",
                "type": "SIMPLE",
                "inputParameters": {
                    "deployment_details": "${workflow.input.deployment_details}"
                }
            },
            {
                "name": "report_generator",
                "taskReferenceName": "report_generator",
                "type": "SIMPLE",
                "inputParameters": {
                    "validated_requirements": "${workflow.input.validated_requirements}",
                    "deployment_details": "${workflow.input.deployment_details}",
                    "verification_results": "${deployment_verification.output.verification_results}"
                }
            },
            {
                "name": "workflow_completion",
                "taskReferenceName": "workflow_completion",
                "type": "SIMPLE",
                "inputParameters": {
                    "change_ticket": "${workflow.input.change_ticket}",
                    "verification_results": "${deployment_verification.output.verification_results}",
                    "report": "${report_generator.output.report}"
                }
            }
        ],
        "outputParameters": {
            "verification_results": "${deployment_verification.output.verification_results}",
            "report": "${report_generator.output.report}",
            "completion_status": "${workflow_completion.output.completion_status}"
        }
    }
    
    # 主工作流：整合五個階段
    main_workflow = {
        "name": "it_ops_main_workflow",
        "description": "IT 運維自動化部署五階段工作流",
        "version": 1,
        "tasks": [
            {
                "name": "stage1_workflow",
                "taskReferenceName": "stage1",
                "type": "SUB_WORKFLOW",
                "inputParameters": {
                    "change_request": "${workflow.input.change_request}"
                },
                "subWorkflowParam": {
                    "name": "it_ops_stage1_workflow",
                    "version": 1
                }
            },
            {
                "name": "stage2_workflow",
                "taskReferenceName": "stage2",
                "type": "SUB_WORKFLOW",
                "inputParameters": {
                    "validated_requirements": "${stage1.output.validated_requirements}"
                },
                "subWorkflowParam": {
                    "name": "it_ops_stage2_workflow",
                    "version": 1
                }
            },
            {
                "name": "stage3_workflow",
                "taskReferenceName": "stage3",
                "type": "SUB_WORKFLOW",
                "inputParameters": {
                    "validated_requirements": "${stage1.output.validated_requirements}",
                    "impact_analysis": "${stage2.output.impact_analysis}",
                    "risk_assessment": "${stage2.output.risk_assessment}"
                },
                "subWorkflowParam": {
                    "name": "it_ops_stage3_workflow",
                    "version": 1
                }
            },
            {
                "name": "stage4_workflow",
                "taskReferenceName": "stage4",
                "type": "SUB_WORKFLOW",
                "inputParameters": {
                    "validated_requirements": "${stage1.output.validated_requirements}",
                    "impact_analysis": "${stage2.output.impact_analysis}",
                    "risk_assessment": "${stage2.output.risk_assessment}",
                    "assigned_resources": "${stage3.output.assigned_resources}",
                    "deployment_method": "${stage3.output.deployment_method}"
                },
                "subWorkflowParam": {
                    "name": "it_ops_stage4_workflow",
                    "version": 1
                }
            },
            {
                "name": "stage5_workflow",
                "taskReferenceName": "stage5",
                "type": "SUB_WORKFLOW",
                "inputParameters": {
                    "validated_requirements": "${stage1.output.validated_requirements}",
                    "deployment_details": "${stage4.output.deployment_details}",
                    "change_ticket": "${stage4.output.change_ticket}"
                },
                "subWorkflowParam": {
                    "name": "it_ops_stage5_workflow",
                    "version": 1
                }
            }
        ],
        "outputParameters": {
            "validation_status": "${stage1.output.validation_status}",
            "risk_score": "${stage2.output.risk_score}",
            "assigned_resources": "${stage3.output.assigned_resources}",
            "deployment_method": "${stage3.output.deployment_method}",
            "approval_status": "${stage4.output.approval_status}",
            "execution_status": "${stage4.output.execution_status}",
            "verification_results": "${stage5.output.verification_results}",
            "report": "${stage5.output.report}",
            "completion_status": "${stage5.output.completion_status}"
        }
    }
    
    # 註冊所有工作流
    workflows["it_ops_stage1_workflow"] = stage1_workflow
    workflows["it_ops_stage2_workflow"] = stage2_workflow
    workflows["it_ops_stage3_workflow"] = stage3_workflow
    workflows["it_ops_stage4_workflow"] = stage4_workflow
    workflows["it_ops_stage5_workflow"] = stage5_workflow
    workflows["it_ops_main_workflow"] = main_workflow

# 任務處理器
class TaskProcessor:
    @staticmethod
    def process_email_teams_integration(task_input):
        # 模擬從郵件和Teams收集信息
        time.sleep(1)  # 模擬處理時間
        return {
            "email_data": {
                "subject": "系統更新請求",
                "sender": task_input["change_request"]["requester"],
                "content": f"請求更新{task_input['change_request']['system_name']}系統",
                "attachments": ["系統更新說明.docx"]
            }
        }
    
    @staticmethod
    def process_itsr_form_parser(task_input):
        # 模擬解析ITSR表單
        time.sleep(1)  # 模擬處理時間
        return {
            "itsr_data": {
                "form_id": "ITSR-" + str(uuid.uuid4())[:8],
                "system_name": task_input["change_request"]["system_name"],
                "change_type": task_input["change_request"]["change_type"],
                "description": task_input["change_request"]["change_description"],
                "components": task_input["change_request"]["components"],
                "priority": task_input["change_request"]["priority"]
            }
        }
    
    @staticmethod
    def process_requirements_validation(task_input):
        # 模擬需求驗證
        time.sleep(2)  # 模擬處理時間
        return {
            "validated_requirements": {
                "request_id": "REQ-" + str(uuid.uuid4())[:8],
                "system_name": task_input["change_request"]["system_name"],
                "environment": task_input["change_request"]["environment"],
                "change_type": task_input["change_request"]["change_type"],
                "description": task_input["change_request"]["change_description"],
                "components": task_input["change_request"]["components"],
                "requester": task_input["change_request"]["requester"],
                "priority": task_input["change_request"]["priority"],
                "is_complete": True,
                "is_valid": True
            },
            "validation_status": "VALID"
        }
    
    @staticmethod
    def process_system_impact_analysis(task_input):
        # 模擬系統影響分析
        time.sleep(2)  # 模擬處理時間
        return {
            "impact_analysis": {
                "affected_systems": ["用戶界面", "API服務", "數據庫"],
                "impact_level": "中等",
                "estimated_downtime": "5分鐘",
                "affected_users": "所有前端用戶",
                "rollback_plan": "回滾到上一個版本的部署包"
            }
        }
    
    @staticmethod
    def process_dependency_checker(task_input):
        # 模擬依賴關係檢查
        time.sleep(1)  # 模擬處理時間
        return {
            "dependencies": {
                "software_dependencies": ["Node.js v14+", "PostgreSQL 12+"],
                "service_dependencies": ["認證服務", "日誌服務"],
                "infrastructure_dependencies": ["負載均衡器", "CDN"],
                "dependency_status": "ALL_AVAILABLE"
            }
        }
    
    @staticmethod
    def process_risk_assessment(task_input):
        # 模擬風險評估
        time.sleep(2)  # 模擬處理時間
        return {
            "risk_score": 35,  # 0-100，越高風險越大
            "risk_assessment": {
                "risk_level": "中等",
                "potential_issues": ["服務短暫中斷", "用戶體驗變化"],
                "mitigation_strategies": ["分階段部署", "提前通知用戶"],
                "recommendation": "在非高峰時段進行部署"
            }
        }
    
    @staticmethod
    def process_resource_allocation(task_input):
        # 模擬資源分配
        time.sleep(1)  # 模擬處理時間
        return {
            "assigned_resources": {
                "primary_owner": "李工程師",
                "secondary_owner": "王工程師",
                "qa_tester": "張測試",
                "approver": "陳經理",
                "team": "前端開發團隊"
            }
        }
    
    @staticmethod
    def process_deployment_method_selector(task_input):
        # 模擬部署方法選擇
        time.sleep(1)  # 模擬處理時間
        risk_score = task_input.get("risk_assessment", {}).get("risk_score", 50)
        
        if risk_score < 30:
            method = "GitOps"
        elif risk_score < 70:
            method = "Ansible"
        else:
            method = "Manual"
            
        return {
            "deployment_method": {
                "method": method,
                "tools": ["Jenkins", "Ansible", "Git"],
                "environment": task_input["validated_requirements"]["environment"],
                "deployment_steps": ["準備", "部署", "驗證", "回滾(如需要)"]
            }
        }
    
    @staticmethod
    def process_notification(task_input):
        # 模擬通知
        time.sleep(1)  # 模擬處理時間
        return {
            "notification_status": {
                "notified_users": [
                    task_input["assigned_resources"]["primary_owner"],
                    task_input["assigned_resources"]["secondary_owner"],
                    task_input["assigned_resources"]["qa_tester"],
                    task_input["assigned_resources"]["approver"]
                ],
                "notification_method": "Email",
                "notification_time": time.time(),
                "status": "SENT"
            }
        }
    
    @staticmethod
    def process_change_ticket_generator(task_input):
        # 模擬變更票據生成
        time.sleep(1)  # 模擬處理時間
        return {
            "change_ticket": {
                "ticket_id": "CHG-" + str(uuid.uuid4())[:8],
                "title": f"更新{task_input['validated_requirements']['system_name']}系統",
                "description": task_input["validated_requirements"]["description"],
                "requester": task_input["validated_requirements"]["requester"],
                "assigned_to": task_input["assigned_resources"]["primary_owner"],
                "priority": task_input["validated_requirements"]["priority"],
                "status": "PENDING_APPROVAL",
                "created_at": time.time()
            }
        }
    
    @staticmethod
    def process_pr_creation(task_input):
        # 模擬PR創建
        time.sleep(2)  # 模擬處理時間
        return {
            "pull_request": {
                "pr_id": "PR-" + str(uuid.uuid4())[:8],
                "title": f"更新{task_input['validated_requirements']['system_name']}系統",
                "description": task_input["validated_requirements"]["description"],
                "source_branch": "feature/system-update",
                "target_branch": "main",
                "creator": task_input["validated_requirements"]["requester"],
                "reviewers": [task_input["change_ticket"]["assigned_to"]],
                "status": "OPEN",
                "created_at": time.time()
            }
        }
    
    @staticmethod
    def process_approval_workflow(task_input):
        # 模擬審批流程
        time.sleep(3)  # 模擬處理時間
        return {
            "approval_status": {
                "status": "APPROVED",
                "approver": "陳經理",
                "approval_time": time.time(),
                "comments": "變更已審核並批准"
            }
        }
    
    @staticmethod
    def process_execution(task_input):
        # 模擬執行部署
        time.sleep(3)  # 模擬處理時間
        
        if task_input["approval_status"]["status"] != "APPROVED":
            return {
                "execution_status": "FAILED",
                "error": "未獲得審批，無法執行部署"
            }
        
        method = task_input["deployment_method"]["method"]
        
        if method == "GitOps":
            execution_details = {
                "pipeline": "GitOps CI/CD Pipeline",
                "commit_id": "abc123",
                "artifacts": ["frontend-v1.2.3.zip", "api-v2.1.0.jar"]
            }
        elif method == "Ansible":
            execution_details = {
                "playbook": "deploy-system-update.yml",
                "inventory": "production-servers",
                "tags": ["update", "frontend", "api"]
            }
        else:  # Manual
            execution_details = {
                "operator": "李工程師",
                "steps_performed": ["備份", "停止服務", "更新文件", "重啟服務"],
                "manual_notes": "按照部署文檔執行了所有步驟"
            }
            
        return {
            "execution_status": "SUCCESS",
            "deployment_details": {
                "deployment_id": "DEP-" + str(uuid.uuid4())[:8],
                "method": method,
                "start_time": time.time() - 180,  # 3分鐘前
                "end_time": time.time(),
                "status": "COMPLETED",
                "execution_details": execution_details
            }
        }
    
    @staticmethod
    def process_deployment_verification(task_input):
        # 模擬部署驗證
        time.sleep(2)  # 模擬處理時間
        return {
            "verification_results": {
                "status": "PASSED",
                "tests_run": 15,
                "tests_passed": 15,
                "performance_check": "正常",
                "availability_check": "100%",
                "verification_time": time.time()
            }
        }
    
    @staticmethod
    def process_report_generator(task_input):
        # 模擬報告生成
        time.sleep(2)  # 模擬處理時間
        return {
            "report": {
                "report_id": "RPT-" + str(uuid.uuid4())[:8],
                "title": f"{task_input['validated_requirements']['system_name']}系統更新報告",
                "summary": "系統更新已成功完成",
                "details": {
                    "system": task_input["validated_requirements"]["system_name"],
                    "environment": task_input["validated_requirements"]["environment"],
                    "components_updated": task_input["validated_requirements"]["components"],
                    "deployment_method": task_input["deployment_details"]["method"],
                    "deployment_time": task_input["deployment_details"]["end_time"],
                    "verification_results": task_input["verification_results"]
                },
                "generated_at": time.time()
            }
        }
    
    @staticmethod
    def process_workflow_completion(task_input):
        # 模擬工作流完成
        time.sleep(1)  # 模擬處理時間
        return {
            "completion_status": {
                "status": "COMPLETED",
                "change_ticket_status": "CLOSED",
                "completion_time": time.time(),
                "notes": "所有任務已成功完成，變更已實施並驗證"
            }
        }

# 工作流執行引擎
class WorkflowEngine:
    @staticmethod
    def execute_task(task_name, task_input):
        # 根據任務名稱調用相應的處理器
        processors = {
            "email_teams_integration": TaskProcessor.process_email_teams_integration,
            "itsr_form_parser": TaskProcessor.process_itsr_form_parser,
            "requirements_validation": TaskProcessor.process_requirements_validation,
            "system_impact_analysis": TaskProcessor.process_system_impact_analysis,
            "dependency_checker": TaskProcessor.process_dependency_checker,
            "risk_assessment": TaskProcessor.process_risk_assessment,
            "resource_allocation": TaskProcessor.process_resource_allocation,
            "deployment_method_selector": TaskProcessor.process_deployment_method_selector,
            "notification": TaskProcessor.process_notification,
            "change_ticket_generator": TaskProcessor.process_change_ticket_generator,
            "pr_creation": TaskProcessor.process_pr_creation,
            "approval_workflow": TaskProcessor.process_approval_workflow,
            "execution": TaskProcessor.process_execution,
            "deployment_verification": TaskProcessor.process_deployment_verification,
            "report_generator": TaskProcessor.process_report_generator,
            "workflow_completion": TaskProcessor.process_workflow_completion
        }
        
        if task_name in processors:
            return processors[task_name](task_input)
        else:
            return {"error": f"未知任務: {task_name}"}
    
    @staticmethod
    def execute_workflow(workflow_name, workflow_input):
        if workflow_name not in workflows:
            return {"error": f"未知工作流: {workflow_name}"}
        
        workflow = workflows[workflow_name]
        execution_id = str(uuid.uuid4())
        
        # 創建執行記錄
        execution = {
            "workflow_name": workflow_name,
            "execution_id": execution_id,
            "status": "RUNNING",
            "start_time": time.time(),
            "end_time": None,
            "input": workflow_input,
            "output": {},
            "tasks": {}
        }
        
        executions[execution_id] = execution
        
        # 啟動異步執行
        WorkflowEngine.execute_workflow_async(execution_id, workflow, workflow_input)
        
        return {"execution_id": execution_id}
    
    @staticmethod
    def execute_workflow_async(execution_id, workflow, workflow_input):
        # 在實際系統中，這應該是一個異步任務
        # 這裡我們使用一個簡單的模擬
        execution = executions[execution_id]
        
        try:
            # 執行工作流中的每個任務
            task_outputs = {}
            
            for task in workflow["tasks"]:
                task_ref = task["taskReferenceName"]
                
                # 更新任務狀態為SCHEDULED
                execution["tasks"][task_ref] = {
                    "name": task["name"],
                    "type": task["type"],
                    "status": "SCHEDULED",
                    "start_time": None,
                    "end_time": None,
                    "input": {},
                    "output": {}
                }
                
                # 準備任務輸入
                task_input = {}
                for key, value in task.get("inputParameters", {}).items():
                    if isinstance(value, str) and value.startswith("${workflow.input."):
                        input_key = value[16:-1]  # 提取 ${workflow.input.xxx} 中的 xxx
                        if input_key in workflow_input:
                            task_input[key] = workflow_input[input_key]
                    elif isinstance(value, str) and "${" in value:
                        # 處理引用其他任務輸出的情況
                        for ref, output in task_outputs.items():
                            if f"${{{ref}." in value:
                                output_key = value[len(f"${{{ref}.output.") : -1]
                                if output_key in output:
                                    task_input[key] = output[output_key]
                    else:
                        task_input[key] = value
                
                # 更新任務狀態為RUNNING
                execution["tasks"][task_ref]["status"] = "RUNNING"
                execution["tasks"][task_ref]["start_time"] = time.time()
                execution["tasks"][task_ref]["input"] = task_input
                
                # 執行任務
                if task["type"] == "SIMPLE":
                    task_output = WorkflowEngine.execute_task(task["name"], task_input)
                    task_outputs[task_ref] = task_output
                    
                    # 更新任務狀態為COMPLETED
                    execution["tasks"][task_ref]["status"] = "COMPLETED"
                    execution["tasks"][task_ref]["end_time"] = time.time()
                    execution["tasks"][task_ref]["output"] = task_output
                    
                elif task["type"] == "SUB_WORKFLOW":
                    sub_workflow_name = task["subWorkflowParam"]["name"]
                    sub_workflow = workflows[sub_workflow_name]
                    
                    # 執行子工作流
                    sub_execution_id = str(uuid.uuid4())
                    sub_execution = {
                        "workflow_name": sub_workflow_name,
                        "execution_id": sub_execution_id,
                        "status": "RUNNING",
                        "start_time": time.time(),
                        "end_time": None,
                        "input": task_input,
                        "output": {},
                        "tasks": {}
                    }
                    
                    executions[sub_execution_id] = sub_execution
                    
                    # 執行子工作流中的每個任務
                    sub_task_outputs = {}
                    
                    for sub_task in sub_workflow["tasks"]:
                        sub_task_ref = sub_task["taskReferenceName"]
                        
                        # 更新子任務狀態為SCHEDULED
                        sub_execution["tasks"][sub_task_ref] = {
                            "name": sub_task["name"],
                            "type": sub_task["type"],
                            "status": "SCHEDULED",
                            "start_time": None,
                            "end_time": None,
                            "input": {},
                            "output": {}
                        }
                        
                        # 準備子任務輸入
                        sub_task_input = {}
                        for key, value in sub_task.get("inputParameters", {}).items():
                            if isinstance(value, str) and value.startswith("${workflow.input."):
                                input_key = value[16:-1]  # 提取 ${workflow.input.xxx} 中的 xxx
                                if input_key in task_input:
                                    sub_task_input[key] = task_input[input_key]
                            elif isinstance(value, str) and "${" in value:
                                # 處理引用其他任務輸出的情況
                                for ref, output in sub_task_outputs.items():
                                    if f"${{{ref}." in value:
                                        output_key = value[len(f"${{{ref}.output.") : -1]
                                        if output_key in output:
                                            sub_task_input[key] = output[output_key]
                            else:
                                sub_task_input[key] = value
                        
                        # 更新子任務狀態為RUNNING
                        sub_execution["tasks"][sub_task_ref]["status"] = "RUNNING"
                        sub_execution["tasks"][sub_task_ref]["start_time"] = time.time()
                        sub_execution["tasks"][sub_task_ref]["input"] = sub_task_input
                        
                        # 執行子任務
                        sub_task_output = WorkflowEngine.execute_task(sub_task["name"], sub_task_input)
                        sub_task_outputs[sub_task_ref] = sub_task_output
                        
                        # 更新子任務狀態為COMPLETED
                        sub_execution["tasks"][sub_task_ref]["status"] = "COMPLETED"
                        sub_execution["tasks"][sub_task_ref]["end_time"] = time.time()
                        sub_execution["tasks"][sub_task_ref]["output"] = sub_task_output
                    
                    # 準備子工作流輸出
                    sub_workflow_output = {}
                    for key, value in sub_workflow.get("outputParameters", {}).items():
                        if isinstance(value, str) and "${" in value:
                            for ref, output in sub_task_outputs.items():
                                if f"${{{ref}.output." in value:
                                    output_key = value[len(f"${{{ref}.output.") : -1]
                                    if output_key in output:
                                        sub_workflow_output[key] = output[output_key]
                    
                    # 更新子工作流狀態為COMPLETED
                    sub_execution["status"] = "COMPLETED"
                    sub_execution["end_time"] = time.time()
                    sub_execution["output"] = sub_workflow_output
                    
                    # 將子工作流輸出作為任務輸出
                    task_outputs[task_ref] = sub_workflow_output
                    
                    # 更新任務狀態為COMPLETED
                    execution["tasks"][task_ref]["status"] = "COMPLETED"
                    execution["tasks"][task_ref]["end_time"] = time.time()
                    execution["tasks"][task_ref]["output"] = sub_workflow_output
            
            # 準備工作流輸出
            workflow_output = {}
            for key, value in workflow.get("outputParameters", {}).items():
                if isinstance(value, str) and "${" in value:
                    for ref, output in task_outputs.items():
                        if f"${{{ref}.output." in value:
                            output_key = value[len(f"${{{ref}.output.") : -1]
                            if output_key in output:
                                workflow_output[key] = output[output_key]
            
            # 更新工作流狀態為COMPLETED
            execution["status"] = "COMPLETED"
            execution["end_time"] = time.time()
            execution["output"] = workflow_output
            
        except Exception as e:
            # 更新工作流狀態為FAILED
            execution["status"] = "FAILED"
            execution["end_time"] = time.time()
            execution["error"] = str(e)

# 初始化工作流定義
init_workflows()

# 路由
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/workflow/metadata/<workflow_name>', methods=['GET'])
def get_workflow_metadata(workflow_name):
    if workflow_name in workflows:
        return jsonify(workflows[workflow_name])
    else:
        return jsonify({"error": f"未知工作流: {workflow_name}"}), 404

@app.route('/api/workflow/execute/<workflow_name>', methods=['POST'])
def execute_workflow(workflow_name):
    workflow_input = request.json
    result = WorkflowEngine.execute_workflow(workflow_name, workflow_input)
    return jsonify(result)

@app.route('/api/workflow/execution/<execution_id>', methods=['GET'])
def get_workflow_execution(execution_id):
    if execution_id in executions:
        return jsonify(executions[execution_id])
    else:
        return jsonify({"error": f"未知執行 ID: {execution_id}"}), 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
